"""Module for reading and saving single particle data."""
