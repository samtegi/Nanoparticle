from PySide6 import QtGui

from . import icons
from . import images

# Set the icon theme
QtGui.QIcon.setThemeName("spcal")
