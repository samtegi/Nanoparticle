# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.5.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x019\
[\
Icon Theme]\x0aName\
=spcal\x0aComment=I\
cons from KDE th\
eme Breeze\x0aDirec\
tories=16x16,24x\
24,32x32,16x16@2\
,24x24@2,32x32@2\
\x0a\x0a[16x16]\x0aSize=1\
6\x0aType=Fixed\x0a\x0a[1\
6x16@2]\x0aSize=16\x0a\
Scale=2\x0aType=Fix\
ed\x0a\x0a[24x24]\x0aSize\
=24\x0aType=Fixed\x0a\x0a\
[24x24@2]\x0aSize=2\
4\x0aScale=2\x0aType=F\
ixed\x0a\x0a[32x32]\x0aSi\
ze=32\x0aType=Fixed\
\x0a\x0a[32x32@2]\x0aSize\
=32\x0aScale=2\x0aType\
=Fixed\x0a\x0a\
\x00\x00\x04\xf7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 7.5 3 C 5.5\
67 3 4 4.7909 4 \
7 L 4 8 L 4 10 C\
 4 12.2091 5.567\
 14 7.5 14 C 9.4\
33 14 11 12.2091\
 11 10 L 11 8 L \
11 7 C 11 4.7909\
 9.433 3 7.5 3 z\
 M 15.5 3 C 13.5\
67 3 12 4.7909 1\
2 7 L 12 8 L 12 \
10 C 12 12.2091 \
13.567 14 15.5 1\
4 C 17.433 14 19\
 12.2091 19 10 L\
 19 8 L 19 7 C 1\
9 4.7909 17.433 \
3 15.5 3 z M 7.5\
 4 C 8.88071 4 1\
0 5.3432 10 7 L \
10 10 C 10 11.65\
69 8.88071 13 7.\
5 13 C 6.11929 1\
3 5 11.6569 5 10\
 L 5 7 C 5 5.343\
2 6.11929 4 7.5 \
4 z M 15.5 4 C 1\
6.88071 4 18 5.3\
431 18 7 L 18 10\
 C 18 11.6569 16\
.88071 13 15.5 1\
3 C 14.11929 13 \
13 11.6569 13 10\
 L 13 7 C 13 5.3\
431 14.11929 4 1\
5.5 4 z M 3 13 L\
 3 14 L 4 14 L 4\
 13 L 3 13 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a    <p\
ath style=\x22fill:\
currentColor;fil\
l-opacity:1;stro\
ke:none\x22 d=\x22M 15\
 15 L 15 17 L 13\
 17 L 13 18 L 15\
 18 L 15 20 L 16\
 20 L 16 18 L 18\
 18 L 18 17 L 16\
 17 L 16 15 L 15\
 15 z \x22 class=\x22C\
olorScheme-Highl\
ight\x22/>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x03\x08\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 9 3 C 7.3\
4315 3 6 4.3431 \
6 6 L 6 8 L 4 8 \
L 4 9 L 6 9 L 6 \
10 L 6 19 L 7 19\
 L 7 9 L 8 9 L 9\
 9 L 9 8 L 8 8 L\
 7 8 L 7 6 C 7 4\
.89543 7.89543 4\
 9 4 L 10 4 L 10\
 3 L 9 3 z M 12.\
742188 13 L 12 1\
3.732422 L 14.29\
2969 16 L 12 18.\
267578 L 12.7421\
88 19 L 15.03515\
6 16.732422 L 17\
.257812 18.93164\
1 L 18 18.199219\
 L 15.775391 16 \
L 18 13.800781 L\
 17.257812 13.06\
8359 L 15.035156\
 15.267578 L 12.\
742188 13 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x02\xa6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <defs>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
            .Col\
orScheme-Text {\x0a\
                \
color:#232629;\x0a \
           }\x0a   \
     </style>\x0a  \
</defs>\x0a  <g tra\
nsform=\x22translat\
e(1,1)\x22>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 d=\x22m14 1\
1c-2.215995 0-4 \
1.784005-4 4s1.7\
84005 4 4 4 4-1.\
784005 4-4-1.784\
005-4-4-4m0 1c1.\
661995 0 3 1.338\
005 3 3s-1.33800\
5 3-3 3-3-1.3380\
05-3-3 1.338005-\
3 3-3m-1 1v3h2v-\
1h-1v-2h-1m-9-10\
v16h6v-1h-5v-14h\
8v4h4v3h1v-4.007\
8125l-3.992188-3\
.9921875-0.00781\
2 0.0097656v-0.0\
097656h-9z\x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x02\xab\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 3 C 6.\
568 3 3 6.568 3 \
11 C 3 15.432 6.\
568 19 11 19 C 1\
5.432 19 19 15.4\
32 19 11 C 19 6.\
568 15.432 3 11 \
3 z M 11 4 C 14.\
878 4 18 7.122 1\
8 11 C 18 14.878\
 14.878 18 11 18\
 C 7.122 18 4 14\
.878 4 11 C 4 7.\
122 7.122 4 11 4\
 z M 10 6 L 10 8\
 L 12 8 L 12 6 L\
 10 6 z M 10 9 L\
 10 16 L 12 16 L\
 12 9 L 10 9 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x06{\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
5 L 4 16 L 4 17 \
L 3 17 L 3 18 L \
4 18 L 4 19 L 5 \
19 L 5 18 L 19 1\
8 L 19 17 L 5 17\
 L 5 16 L 5.0078\
125 16 L 6 16 L \
8 16 L 8 15.9921\
88 L 8.0078125 1\
6 L 10.007812 14\
 L 11.599609 14 \
L 13.599609 16 L\
 17.099609 16 L \
19 16 L 19 15 L \
17.099609 15 L 1\
4.013672 15 L 12\
.013672 13 L 12 \
13 L 11.007812 1\
3 L 10.599609 13\
 L 9.59375 13 L \
7.59375 15 L 6 1\
5 L 5.0078125 15\
 L 5 15 L 5 11 L\
 10 11 L 10 10.9\
92188 L 10.00781\
2 11 L 11.003906\
 10.003906 L 11 \
10 L 10.296875 9\
.296875 L 9.5937\
5 10 L 5 10 L 5 \
3 L 4 3 z M 11 1\
0 L 13 10 L 13 9\
 L 12 9 L 12 8 L\
 11 8 L 11 10 z \
M 11 4 L 11 6 L \
12 6 L 12 5 L 13\
 5 L 13 4 L 11 4\
 z M 15 4 L 15 5\
 L 16 5 L 16 6 L\
 17 6 L 17 4 L 1\
5 4 z M 14 5.593\
75 L 13.292969 6\
.3007812 L 12.29\
6875 7.296875 L \
13.003906 8.0039\
062 L 14 7.00781\
25 L 14.996094 8\
.0039062 L 15.70\
3125 7.296875 L \
14 5.59375 z M 1\
6 8 L 16 9 L 15 \
9 L 15 10 L 17 1\
0 L 17 8 L 16 8 \
z M 19 8 L 18 9 \
L 19 9 L 19 8 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a   \
 <path style=\x22fi\
ll:currentColor;\
fill-opacity:0.5\
;stroke:none\x22 d=\
\x22M 14 7 L 12.003\
906 9 L 13 9 L 1\
3 10 L 11.005859\
 10 L 10.007812 \
11 L 5 11 L 5 15\
 L 7.5996094 15 \
L 9.5996094 13 L\
 12.007812 13 L \
14 14.992188 L 1\
9 15 L 19 9 L 17\
 9 L 17 10 L 15 \
10 L 15 9 L 16 9\
 L 14 7 z M 10 1\
4 L 8 16 L 5 16 \
L 5 17 L 19 17 L\
 19 16 L 13.5996\
09 16 L 11.59960\
9 14 L 10 14 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02\x14\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <style type\
=\x22text/css\x22 id=\x22\
current-color-sc\
heme\x22>\x0a        .\
ColorScheme-Nega\
tiveText {\x0a     \
       color:#da\
4453;\x0a        }\x0a\
    </style>\x0a  <\
g transform=\x22tra\
nslate(1,1)\x22>\x0a  \
  <path d=\x22M11 3\
a8 8 0 0 0-8 8 8\
 8 0 0 0 8 8 8 8\
 0 0 0 8-8 8 8 0\
 0 0-8-8M7.707 7\
L11 10.294l3.293\
-3.293.707.707-3\
.293 3.293L15 14\
.294l-.707.707L1\
1 11.708l-3.293 \
3.293L7 14.294l3\
.293-3.293L7 7.7\
08l.707-.707\x22 cl\
ass=\x22ColorScheme\
-NegativeText\x22 f\
ill=\x22currentColo\
r\x22/>\x0a  </g>\x0a</sv\
g>\x0a\
\x00\x00\x03H\
(\
\xb5/\xfd`\x1c\x0e\xf5\x19\x00\xc6\xa4l# m\xf5\
\xc9\x0f\xdd@\xe5\x13\xea\xf7\xc9\x0fM\x00L\xe1\xbb\x5c\
\x94{$\x9c|\x92\x92\xaekp\xa2\x05\x08\x87`\x11\
h\x00b\x00^\x00\x14\xb1\x1d\xb1\x9f9\xbevrc\
7^\x9f\xf3\xc5w\xdf\xe8?\x969\xb0\xe6\x91\x96\x0d\
p\x80\xc0TM\xb0f\x9a$h\x1d\x97\x13\xb1\xa0\xfa\
0\xbb\x00\x06\x97#\x92\xaa\x835\x8e\xeb\x91$\xcb\x16\
_^f\xcd\x84B\x90T\x89b\x992\xe7l\x09\x88\
4M\x0a\x98\xc2\xcc\xaeD\x15\xe5\x9e\xc4I$\x12E\
)\x88\x5c\x97\x835\x16dzL6\xa2\xb0\x98\xac0\
\xaf)\xf4~\xa6\xff@\xc9P\x84\x0f\x85\x1e\xe6\xfd\x1c\
W\x0b\x82(\x851S\xda4\x805\x155Q\xb4m\
\x84\xba\xacjE@\x1e*u\x22\x10U\xb5\xacK\x82\
DD\xcf.\xa1[|\x99\xcc\xe7\xef\x9eC\xd6t\xc5\
\xb2wA\xaa\xf48UC\xe5\xd4\xd6\x1a\xa3[\xb7\xd8\
\xcbK\x7fJ7\x1f\xdc\xb7\xb4\x84\xeeyY<\x85\x05\
\xdem\xffI\xe7m\xe5\xf2\xf2\xc6\xff\xc5]\x0bL\xa4\
\xear\x1e\x03M\xd0\x02\xf5r&\xd6<*\x0a\xb2 \
Num\xc4(Le\x7f\xb1\xd6\xe6\xf7\x95zmY\
\xe9R;\xc2\x86\xd5\xe7k\x87B\xd0/\x0e|\xcf\x9b\
\x8d\x96\x0e?\xads\xd2\xda\x90\xec\x0d\xfa|s\xd3\x97\
\x8ewC\xc2'\xd2\x7f\xfa\x91\xf2\xfb\xab/\x1e\x00\x06\
\x11\x85\xa50\x0d\x0c\x8b\x05\x86\x82t7\xfd\xf7\xd9\xb5\
l\x87\xd1I)\xb7'toq\xee\xedn\xbb\xbc\xbf\
;\x86/\x01aq\xc0\x98U\xbd\x96w\xfd\xde9\xec\
\xb6\xb0\x8aK\xa2\x22\x85\xf9\x85\xdc\x95\xec\x91\xa1\xb89\
\x97\xfd\xb7\x0d[D\x9a(T+G\xc1~tq\xca\
}\xb1\xb5}\xf0q;^\xf9\xe2;t\xf3\x03\x80\xb0\
\xa0\x11Mf\xa40hA\x92B\x961pFH\xa6\
\xc8\xe4\x01r\x86\xcf\xf8\xb0\x9eX\x13\xfb\x80\xef\x06o\
\x89M\xf3\xdaf\xd9G\x10\xd3fu\x96D_\x8c!\
w\x82\xac\x1b\x91\x97\x13\xc6\x02\x0e\xd4=R4\x84`\
\x0a\x86\x8a\x82\xa0#?`\x80_\x01\x8e\xf7y\xb2\xf6\
\xf6\x88\xd2\xa9\x8a\x22K(\xb6e\x90c\x8c\x22\xb3\x22\
B\xc8$\xae}?)[\xe0\x9c\x15Yu\xb9o\xd4\
+\x08u\x8f\xc2\xbb\xe3\xe8y\x0a\xc7\x5c\xa6\x95?\x22\
\x06V\x0d\x09}\xcb\x84\x8a0p\xd0\x1e\x96\xe0\x12\x13\
\xfdB\xd3\xda\x0e\x16\x1cEL7\xc2k\xc4\x06\x18<\
\x08|\x0e\x9b\x03\x97Y\x93\xe9\x1a\xc0\x96\x09\xd9*g\
\xcf\x07\xa6\xbc\x0cys\x03\xb4\x0e\xe0\xf1(PV\xc9\
\xbb\x95\xd6C\x0b0\xf5\x81\x8f\xeb:: )\x19@\
\x1e\xd4\xb6\x00&\x22P\x22\xa7\x03\x16\x06\xd6\xc1\x1d\xf5\
\x86m\xc4\xa7\xa2\xd7\xdb-1\xd5\x1b\x98m\x09\xd84\
jr\x15`\x9a\xe5\x18E\x04\x18\xf8\x22\x04-&\xc0\
t\x9a\xfb4G\xcaT\xaf\xbc\xcdHW\x82\x99\x16&\
\xb59\xb0\x90\x98d\x92=\x0c\xb9e\x0c?\x80\x16\x1b\
\xa7\x22\x19^\xa3\xc89h*\xe4\xceE\x19\x12\x02\xb3\
\xaa\xbc\xb8\x0a\xe4\xcd\x84P\xb6k\x19\xf8\xecr\xd3@\
\xc1\x09k\x05\xb0?\xc0$\x00\x81\x066\x17\xa6\xcc\x17\
J\x06D*\x8e7\x16\x1d\x80\xbb\x87\x0e\x90w\xe0\x87\
\xf90 `\xf2\x8d\x96=\x955k(\xfb\x03\x1f\x00\
\xbac\x80\x02\x9a\x0f\xbd\xcf\xd8X}\x11(\xecu&\
4#\x18\xb7\x02\x88*\
\x00\x00\x03\xb9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11.5 3 C \
10.286139 3 9.28\
09778 3.8559279 \
9.0507812 5 L 3 \
5 L 3 6 L 9.0507\
812 6 C 9.280977\
8 7.1440721 10.2\
86139 8 11.5 8 C\
 12.713861 8 13.\
719022 7.1440721\
 13.949219 6 L 1\
9 6 L 19 5 L 13.\
949219 5 C 13.71\
9022 3.8559279 1\
2.713861 3 11.5 \
3 z M 5.5 14 C 4\
.1149999 14 3 15\
.115 3 16.5 C 3 \
17.885 4.1149999\
 19 5.5 19 C 6.7\
138604 19 7.7190\
223 18.144072 7.\
9492188 17 L 19 \
17 L 19 16 L 7.9\
492188 16 C 7.71\
90223 14.855928 \
6.7138604 14 5.5\
 14 z M 5.5 15 C\
 6.3310001 15 7 \
15.669 7 16.5 C \
7 17.331 6.33100\
01 18 5.5 18 C 4\
.6689999 18 4 17\
.331 4 16.5 C 4 \
15.669 4.6689999\
 15 5.5 15 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02G\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 3 C 6.\
6 3 3 6.6 3 11 C\
 3 15.4 6.6 19 1\
1 19 C 15.4 19 1\
9 15.4 19 11 C 1\
9 6.6 15.4 3 11 \
3 z M 11 4 L 11 \
11 L 18 11 L 18 \
11 C 18 14.9 14.\
9 18 11 18 C 7.1\
22 18 4 14.9 4 1\
1 C 4 7.122 7.12\
2 4 11 4 z \x22 cla\
ss=\x22ColorScheme-\
Text\x22/>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x02x\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 5\
 L 5 5 L 5 4 L 1\
7 4 L 17 5 L 18 \
5 L 18 3 L 17 3 \
L 5 3 L 4 3 z M \
11 5 L 5 11.1835\
94 L 5.7929688 1\
2 L 11 6.6328125\
 L 16.207031 12 \
L 17 11.183594 L\
 11 5 z M 8 13 L\
 8 19 L 9 19 L 1\
3 19 L 14 19 L 1\
4 13 L 13 13 L 1\
3 18 L 9 18 L 9 \
13 L 8 13 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x04\xcc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 17.564453\
 2.7558594 L 14.\
298828 8.5742188\
 L 11.882812 7.1\
386719 L 10.8613\
28 8.8574219 L 1\
6.511719 12.2167\
97 L 17.533203 1\
0.496094 L 15.15\
8203 9.0839844 L\
 18.435547 3.244\
1406 L 17.564453\
 2.7558594 z M 7\
 6 A 1 1 0 0 0 6\
 7 A 1 1 0 0 0 7\
 8 A 1 1 0 0 0 8\
 7 A 1 1 0 0 0 7\
 6 z M 3.5 7 A 0\
.5 0.5 0 0 0 3 7\
.5 A 0.5 0.5 0 0\
 0 3.5 8 A 0.5 0\
.5 0 0 0 4 7.5 A\
 0.5 0.5 0 0 0 3\
.5 7 z M 5 9 A 1\
 1 0 0 0 4 10 A \
1 1 0 0 0 5 11 A\
 1 1 0 0 0 6 10 \
A 1 1 0 0 0 5 9 \
z M 10 10 C 8.88\
15125 11.564268 \
6.8355055 12.810\
894 3 13 L 3 14 \
C 5.1137135 17.3\
71692 8 19 12 19\
 L 13 19 C 14.31\
1249 17.412805 1\
5.357513 15.9676\
19 16 14 L 16 13\
 L 11 10 L 10 10\
 z M 10.529297 1\
1.101562 L 14.85\
7422 13.699219 C\
 14.284594 15.24\
586 13.385404 16\
.602833 12.27343\
8 17.96875 C 8.9\
999995 18 6.0527\
68 16.540538 4.3\
261719 13.830078\
 C 7.4443879 13.\
51946 9.3457156 \
12.545306 10.529\
297 11.101562 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x05Z\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 18.292969\
 3 L 3 18.292969\
 L 3.7070312 19 \
L 19 3.7070312 L\
 18.292969 3 z M\
 11 6 A 10 9.999\
9781 0 0 0 2.287\
1094 11.119141 C\
 2.4663699 11.42\
0241 2.7209984 1\
1.668644 3.02734\
38 11.839844 A 9\
 8.99998 0 0 1 1\
1 7 A 4 4 0 0 0 \
7 11 A 4 4 0 0 0\
 7.3574219 12.64\
2578 L 8.1308594\
 11.869141 A 3 3\
 0 0 1 8 11 A 3 \
3 0 0 1 11 8 A 3\
 3 0 0 1 11.8691\
41 8.1308594 L 1\
2.640625 7.35937\
5 A 4 4 0 0 0 11\
.34375 7.0175781\
 A 9 8.99998 0 0\
 1 12.796875 7.2\
03125 L 13.64062\
5 6.359375 A 10 \
9.9999781 0 0 0 \
11 6 z M 16.4042\
97 7.5957031 L 1\
5.675781 8.32421\
88 A 9 8.99998 0\
 0 1 18.974609 1\
1.837891 C 19.28\
2742 11.665091 1\
9.539718 11.4154\
28 19.71875 11.1\
11328 A 10 9.999\
9781 0 0 0 16.40\
4297 7.5957031 z\
 M 11 9 A 2 2 0 \
0 0 9 11 L 11 9 \
z M 14.642578 9.\
3574219 L 13.869\
141 10.130859 A \
3 3 0 0 1 14 11 \
A 3 3 0 0 1 11 1\
4 A 3 3 0 0 1 10\
.130859 13.86914\
1 L 9.3574219 14\
.642578 A 4 4 0 \
0 0 11 15 A 4 4 \
0 0 0 15 11 A 4 \
4 0 0 0 14.64257\
8 9.3574219 z M \
13 11 L 11 13 A \
2 2 0 0 0 13 11 \
z M 1 13 C 0.333\
33333 19 0.66666\
667 16 1 13 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xfa\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 3 L 3 4\
 L 3 19 L 4 19 L\
 15 19 L 12 16 L\
 15 13 L 17 13 L\
 16 12 L 14 10 L\
 10 14 L 9 13 L \
4.1484375 17.851\
562 L 4 18 L 4 4\
 L 18 4 L 18 12 \
L 19 12 L 19 4 L\
 19 3 L 4 3 L 3 \
3 z M 7 5 C 5.89\
2 5 5 5.892 5 7 \
C 5 8.108 5.892 \
9 7 9 C 8.108 9 \
9 8.108 9 7 C 9 \
5.892 8.108 5 7 \
5 z M 16 14 L 16\
 16 L 14 16 L 14\
 17 L 16 17 L 16\
 19 L 17 19 L 17\
 17 L 19 17 L 19\
 16 L 17 16 L 17\
 14 L 16 14 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xb6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 3 L 3 4\
 L 3 6 L 4 6 L 4\
 4 L 6 4 L 6 3 L\
 4 3 L 3 3 z M 1\
6 3 L 16 4 L 18 \
4 L 18 6 L 19 6 \
L 19 4 L 19 3 L \
18 3 L 16 3 z M \
5 5 L 5 17 L 17 \
17 L 17 5 L 5 5 \
z M 6 6 L 16 6 L\
 16 16 L 6 16 L \
6 6 z M 3 16 L 3\
 18 L 3 19 L 6 1\
9 L 6 18 L 4 18 \
L 4 16 L 3 16 z \
M 18 16 L 18 18 \
L 16 18 L 16 19 \
L 19 19 L 19 16 \
L 18 16 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x02\x05\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22opacity:1;fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 d=\x22M\
 3,4 3,16 6,20 6\
,17 6,16 19,16 1\
9,4 3,4 Z M 4,5 \
18,5 18,15 4,15 \
4,5 Z m 6,1 0,1 \
2,0 0,-1 -2,0 z \
m 0,2 0,6 2,0 0,\
-6 -2,0 z\x22 class\
=\x22ColorScheme-Te\
xt\x22/>\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x04\xc8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 2 2.99804\
69 L 2 3 L 2 4 L\
 2 19 L 3 19 L 1\
1 19 L 11 18 L 6\
 18 L 6 12 L 11 \
12 L 11 11 L 6 1\
1 L 5 11 L 5 18 \
L 3 18 L 3 4 L 6\
 4 L 6 8 L 6 9 L\
 14 9 L 14 8 L 1\
4 4 L 14.292969 \
4 L 17 6.7070312\
 L 17 7 L 17 10 \
L 18 10 L 18 7 L\
 18 6.3007812 L \
17.992188 6.3007\
812 L 18 6.29101\
56 L 14.707031 2\
.9980469 L 14.69\
9219 3.0078125 L\
 14.699219 2.998\
0469 L 14 2.9980\
469 L 2 2.998046\
9 z M 7 4 L 10.9\
00391 4 L 10.900\
391 8 L 7 8 L 7 \
4 z M 18 11 L 17\
.003906 11.99414\
1 L 17 11.994141\
 L 12 16.992188 \
L 12.007812 17.0\
01953 L 12.00390\
6 18.005859 L 12\
 18.005859 L 12 \
18.996094 L 12 1\
9.005859 L 14 19\
.005859 L 14.005\
859 18.996094 L \
14.009766 18.996\
094 L 14.019531 \
18.996094 L 14.0\
13672 18.986328 \
L 15 18 L 19 14.\
003906 L 18.2949\
22 13.294922 L 1\
3.304688 18.2812\
5 L 12.710938 17\
.689453 L 17.703\
125 12.701172 L \
18.294922 13.294\
922 L 19 13.9980\
47 L 20 12.99804\
7 L 18 11 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x03J\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:currentC\
olor\x22 d=\x22M 19 5 \
L 9.6679688 5.00\
58594 L 6.5 14.5\
 L 4.3339844 11 \
L 3 11 L 3 12 L \
4 12 L 6.5 17 L \
10.441406 6 L 19\
 6 L 19 5 z M 14\
 8 C 11.790861 8\
 10 9.790861 10 \
12 C 10 14.20913\
9 11.790861 16 1\
4 16 C 15.149118\
 15.9982 16.2419\
64 15.502302 17 \
14.638672 L 17 1\
6 L 18 16 L 18 1\
2 L 18 8 L 17 8 \
L 17 9.3613281 C\
 16.241964 8.497\
6979 15.149118 8\
.0017906 14 8 z \
M 14 9 C 15.6568\
54 9 17 10.34314\
6 17 12 C 17 13.\
656854 15.656854\
 15 14 15 C 12.3\
43146 15 11 13.6\
56854 11 12 C 11\
 10.343146 12.34\
3146 9 14 9 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xdb\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:currentC\
olor\x22 d=\x22M 11 3 \
A 8 3 0 0 0 3 6 \
L 3 16 A 8 3 0 0\
 0 11 19 A 8 3 0\
 0 0 19 16 L 19 \
6 A 8 3 0 0 0 11\
 3 z M 11 4 A 7 \
2 0 0 1 18 6 A 7\
 2 0 0 1 11 8 A \
7 2 0 0 1 4 6 A \
7 2 0 0 1 11 4 z\
 M 18 7.45 L 18 \
11 A 7 2 0 0 1 1\
1 13 A 7 2 0 0 1\
 4 11 L 4 7.45 A\
 8 3 0 0 0 11 9 \
A 8 3 0 0 0 18 7\
.45 z M 18 12.45\
 L 18 16 A 7 2 0\
 0 1 11 18 A 7 2\
 0 0 1 4 16 L 4 \
12.45 A 8 3 0 0 \
0 11 14 A 8 3 0 \
0 0 18 12.45 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02\x8d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 18\
 17 L 18 16 L 17\
 16 L 16 16 L 16\
 15 L 15 15 L 14\
 15 L 14 14 L 13\
 14 L 13 15 L 12\
 15 L 12 14 L 11\
 14 L 11 7 L 10 \
7 L 10 3 L 9 3 L\
 9 5 L 8 5 L 8 8\
 L 7 8 L 7 10 L \
6 10 L 6 13 L 5 \
13 L 5 3 L 4 3 z\
 \x22 class=\x22ColorS\
cheme-Text\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x02\x98\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 6 \
18 L 19 18 L 19 \
17 L 19 8 L 18 8\
 L 18 9 L 17 9 L\
 17 8 L 16 8 L 1\
6 7 L 15 7 L 15 \
8 L 14 8 L 14 6 \
L 13 6 L 13 9 L \
12 9 L 12 7 L 11\
 7 L 11 5 L 10 5\
 L 10 3 L 9 3 L \
9 4 L 8 4 L 8 5 \
L 7 5 L 7 6 L 6 \
6 L 6 7 L 5 7 L \
5 3 L 4 3 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x04V\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 6 A 10\
 9.999975 0 0 0 \
2.3144531 11.070\
312 C 2.4995621 \
11.361743 2.7600\
802 11.597238 3.\
0664062 11.75976\
6 A 9 8.999978 0\
 0 1 11 7 A 4 4 \
0 0 0 7 11 A 4 4\
 0 0 0 11 15 A 4\
 4 0 0 0 15 11 A\
 4 4 0 0 0 11.34\
375 7.0175781 A \
9 8.999978 0 0 1\
 18.931641 11.76\
1719 C 19.241063\
 11.598077 19.50\
3624 11.359298 1\
9.689453 11.0644\
53 A 10 9.999975\
 0 0 0 11 6 z M \
11 8 A 3 3 0 0 1\
 14 11 A 3 3 0 0\
 1 11 14 A 3 3 0\
 0 1 8 11 A 3 3 \
0 0 1 11 8 z M 1\
1 9 C 9.892 9 9 \
9.892 9 11 C 9 1\
2.108 9.892 13 1\
1 13 C 12.108 13\
 13 12.108 13 11\
 C 13 10.79519 1\
2.960983 10.6017\
95 12.904297 10.\
416016 C 12.7464\
15 10.759733 12.\
404317 11 12 11 \
C 11.446 11 11 1\
0.554 11 10 C 11\
 9.595683 11.240\
267 9.2535881 11\
.583984 9.095703\
1 C 11.398205 9.\
0390231 11.20481\
 9 11 9 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x03A\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 2.99804\
69 L 3 3 L 3 4 L\
 3 19 L 4 19 L 1\
9 19 L 19 18 L 1\
9 7 L 19 6.30078\
12 L 18.992188 6\
.3007812 L 19 6.\
2910156 L 15.707\
031 2.9980469 L \
15.699219 3.0078\
125 L 15.699219 \
2.9980469 L 15 2\
.9980469 L 3 2.9\
980469 z M 4 4 L\
 7 4 L 7 8 L 7 9\
 L 15 9 L 15 8 L\
 15 4 L 15.29296\
9 4 L 18 6.70703\
12 L 18 7 L 18 1\
8 L 16 18 L 16 1\
1 L 15 11 L 7 11\
 L 6 11 L 6 18 L\
 4 18 L 4 4 z M \
8 4 L 11.900391 \
4 L 11.900391 8 \
L 8 8 L 8 4 z M \
7 12 L 15 12 L 1\
5 18 L 7 18 L 7 \
12 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x02\xae\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 id=\x22svg6\x22\
 version=\x221.1\x22 v\
iewBox=\x220 0 24 2\
4\x22 width=\x2224\x22 he\
ight=\x2224\x22>\x0a  <st\
yle id=\x22current-\
color-scheme\x22 ty\
pe=\x22text/css\x22>.C\
olorScheme-Text \
{\x0a            co\
lor:#232629;\x0a   \
     }</style>\x0a \
 <g transform=\x22t\
ranslate(1,1)\x22>\x0a\
    <path id=\x22pa\
th4\x22 class=\x22Colo\
rScheme-Text\x22 d=\
\x22m9.300781 3-3.5\
 3.5 3.5 3.5 0.7\
07031-0.707031-2\
.292969-2.292969\
h3.785154c3.047 \
0 5.5 2.453 5.5 \
5.5s-2.453 5.5-5\
.5 5.5h-1.5v1h1.\
5c3.601 0 6.5-2.\
899 6.5-6.5s-2.8\
99-6.5-6.5-6.5h-\
3.785154l2.29296\
9-2.292969-0.707\
031-0.707031\x22 fi\
ll=\x22currentColor\
\x22/>\x0a    <rect id\
=\x22rect837\x22 class\
=\x22ColorScheme-Te\
xt\x22 x=\x224\x22 y=\x223\x22 \
width=\x221\x22 height\
=\x227\x22 fill=\x22curre\
ntColor\x22 fill-ru\
le=\x22evenodd\x22/>\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x01\xa2\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color\x22 class=\x22Co\
lorScheme-Text\x22 \
d=\x22M 3 7 L 3 9 L\
 13 9 L 13 7 L 3\
 7 z\x22 transform=\
\x22translate(3 3)\x22\
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x02P\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 3 L 3 1\
7 L 7 17 L 7 19 \
L 17 19 L 17 10 \
L 13 6 L 12 6 L \
9 3 L 3 3 Z M 4 \
4 L 8 4 L 8 6 L \
7 6 L 7 16 L 4 1\
6 L 4 4 Z M 8 7 \
L 12 7 L 12 11 L\
 16 11 L 16 18 L\
 8 18 L 8 7 Z\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x02\x80\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
9 L 9 19 L 9 18 \
L 5 18 L 5 4 L 1\
3 4 L 13 8 L 17 \
8 L 17 11 L 18 1\
1 L 18 7 L 14 3 \
L 14 3 L 14 3 L \
5 3 L 4 3 z M 10\
 12 L 10 19 L 18\
 19 L 18 13 L 15\
 13 L 14 12 L 14\
 12 L 14 12 L 10\
 12 z M 13.1 14 \
L 17 14 L 17 18 \
L 11 18 L 11 15 \
L 12 15 L 13.1 1\
4 z \x22 class=\x22Col\
orScheme-Text\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x04\xf2\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22m7.01172 3c\
-.57735 1-.87813\
1 1-.300781 2l3.\
541016 6.140625-\
2.058594 3.52734\
4c-.445257-.4114\
53-1.036498-.667\
969-1.693359-.66\
7969-1.385 0-2.5\
 1.115-2.5 2.5 0\
 1.385 1.115 2.5\
 2.5 2.5 1.385 0\
 2.5-1.115 2.5-2\
.5 0-.167103-.01\
785-.330523-.048\
828-.488281l1.16\
2109-2.01367c.78\
0419-.001.878798\
-.774603 1.33398\
5-.785156l1.6035\
15 2.78125c-.033\
193.163037-.0507\
81.332734-.05078\
1.505859 0 1.385\
 1.115 2.5 2.5 2\
.5 1.385 0 2.5-1\
.115 2.5-2.5 0-1\
.385-1.115-2.5-2\
.5-2.5-.653333 0\
-1.241072.254586\
-1.685547.662109\
l-2.054687-3.521\
484 3.541015-6.1\
40625c.57735-1 .\
276569-1-.300781\
-2l-3.994141 6.8\
47656-3.99414-6.\
847656m3.988281 \
8c.277 0 .5.223.\
5.5 0 .277-.223.\
5-.5.5-.277 0-.5\
-.223-.5-.5 0-.2\
77.223-.5.5-.5zm\
-4.5 4c.831 0 1.\
5.669 1.5 1.5 0 \
.831-.669 1.5-1.\
5 1.5-.831 0-1.5\
-.669-1.5-1.5 0-\
.831.669-1.5 1.5\
-1.5m9 0c.831 0 \
1.5.669 1.5 1.5 \
0 .831-.669 1.5-\
1.5 1.5-.831 0-1\
.5-.669-1.5-1.5 \
0-.831.669-1.5 1\
.5-1.5\x22 class=\x22C\
olorScheme-Text\x22\
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x02y\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 5 \
17 L 5 3 L 4 3 z\
 M 17.566406 3.7\
519531 L 13.6328\
12 10.632812 L 6\
.7519531 14.5664\
06 L 7.2480469 1\
5.433594 L 14.36\
7188 11.367188 L\
 18.433594 4.248\
0469 L 17.566406\
 3.7519531 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02\xdc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 5 3 L 4 4\
 L 4 5 L 4 5.304\
6875 L 9 12.3671\
88 L 9 16 L 9 16\
.039062 L 12.990\
234 19 L 13 19 L\
 13 12.367188 L \
18 5.3046875 L 1\
8 4 L 17 3 L 5 3\
 z M 5 4 L 17 4 \
L 17 4.9882812 L\
 12.035156 12 L \
12 12 L 12 12.04\
8828 L 12 13 L 1\
2 17.019531 L 10\
 15.535156 L 10 \
13 L 10 12.04882\
8 L 10 12 L 9.96\
48438 12 L 5 4.9\
882812 L 5 4 z M\
 6 5 L 8 8 L 8 6\
 L 10 5 L 6 5 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x05\x1f\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 4 3 L 4 9 L\
 4 10 L 4 15 L 4\
 16 L 4 17 L 3 1\
7 L 3 18 L 4 18 \
L 4 19 L 5 19 L \
5 18 L 18.292969\
 18 L 19 18 L 19\
 17.292969 L 19 \
17 L 18.707031 1\
7 L 17.292969 17\
 L 5 17 L 5 15.4\
31641 L 5 15.423\
828 L 5 15 L 5 1\
2.423828 L 5 11.\
423828 L 5 11 L \
5 10 L 5 9 L 5 6\
 L 5 5.9921875 L\
 5 5 L 5 3 L 4 3\
 z M 17 3 L 17 4\
 L 18 4 L 18 3 L\
 17 3 z M 18 4 L\
 18 5 L 19 5 L 1\
9 4 L 18 4 z M 1\
8 5 L 17 5 L 17 \
6 L 18 6 L 18 5 \
z M 17 5 L 17 4 \
L 16 4 L 16 5 L \
17 5 z M 6 4 L 6\
 5 L 7 5 L 7 4 L\
 6 4 z M 8 4 L 8\
 5 L 9 5 L 9 4 L\
 8 4 z M 6 6 L 6\
 7 L 7 7 L 7 6 L\
 6 6 z M 8 6 L 8\
 7 L 9 7 L 9 6 L\
 8 6 z M 11 7 L \
11 8 L 12 8 L 12\
 7 L 11 7 z M 13\
 7 L 13 8 L 14 8\
 L 14 7 L 13 7 z\
 M 11 9 L 11 10 \
L 12 10 L 12 9 L\
 11 9 z M 13 9 L\
 13 10 L 14 10 L\
 14 9 L 13 9 z M\
 7 13 L 7 14 L 8\
 14 L 8 13 L 7 1\
3 z M 8 14 L 8 1\
5 L 9 15 L 9 14 \
L 8 14 z M 8 15 \
L 7 15 L 7 16 L \
8 16 L 8 15 z M \
7 15 L 7 14 L 6 \
14 L 6 15 L 7 15\
 z \x22 class=\x22Colo\
rScheme-Text\x22/>\x0a\
  </g>\x0a</svg>\x0a\
\x00\x00\x02\x8b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 7 3 L 7 5\
 L 5 5 L 4 5 L 4\
 19 L 5 19 L 18 \
19 L 18 18 L 18 \
5 L 17 5 L 15 5 \
L 15 3 L 7 3 z M\
 5 6 L 6 6 L 6 8\
 L 16 8 L 16 6 L\
 17 6 L 17 18 L \
5 18 L 5 6 z M 7\
 9 L 7 10 L 15 1\
0 L 15 9 L 7 9 z\
 M 7 12 L 7 13 L\
 13 13 L 13 12 L\
 7 12 z M 7 15 L\
 7 16 L 10 16 L \
10 15 L 7 15 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02}\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 11 16 L 1\
6.293 16 L 14 18\
.293 L 14.707 19\
 L 18.207 15.5 L\
 14.707 12 L 14 \
12.707 L 16.293 \
15 L 11 15 L 11 \
16 Z M 5 18 L 5 \
4 L 13 4 L 13 8 \
L 17 8 L 17 13 L\
 18 13 L 18 7 L \
14 3 L 4 3 L 4 1\
9 L 13 19 L 13 1\
8 L 5 18 Z\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x03S\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 5 \
17 L 5 3 L 4 3 z\
 M 6.4101562 3.7\
128906 L 5.58984\
38 4.2871094 L 1\
1.0625 12.103516\
 L 6.7519531 14.\
566406 L 7.24804\
69 15.433594 L 1\
1.638672 12.9257\
81 L 12.685547 1\
4.421875 L 18.84\
1797 16.474609 L\
 19.158203 15.52\
5391 L 13.314453\
 13.578125 L 12.\
509766 12.427734\
 L 14.367188 11.\
367188 L 18.4335\
94 4.2480469 L 1\
7.566406 3.75195\
31 L 13.632812 1\
0.632812 L 11.93\
3594 11.603516 L\
 6.4101562 3.712\
8906 z \x22 class=\x22\
ColorScheme-Text\
\x22/>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x02\x81\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 8 3 L 8 9\
 L 9 9 L 9 4 L 1\
3 4 L 13 9 L 14 \
9 L 14 3 L 13 3 \
L 9 3 L 8 3 z M \
5.7929688 10 L 5\
 10.816406 L 11 \
17 L 17 10.81640\
6 L 16.207031 10\
 L 11 15.367188 \
L 5.7929688 10 z\
 M 4 17 L 4 19 L\
 5 19 L 17 19 L \
18 19 L 18 17 L \
17 17 L 17 18 L \
5 18 L 5 17 L 4 \
17 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x02P\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 3 L 3 1\
7 L 7 17 L 7 19 \
L 17 19 L 17 10 \
L 13 6 L 12 6 L \
9 3 L 3 3 Z M 4 \
4 L 8 4 L 8 6 L \
7 6 L 7 16 L 4 1\
6 L 4 4 Z M 8 7 \
L 12 7 L 12 11 L\
 16 11 L 16 18 L\
 8 18 L 8 7 Z\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x029\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <style id=\x22cu\
rrent-color-sche\
me\x22 type=\x22text/c\
ss\x22>\x0a        .Co\
lorScheme-Text {\
\x0a            col\
or:#232629;\x0a    \
    }\x0a    </styl\
e>\x0a  <g transfor\
m=\x22translate(1,1\
)\x22>\x0a    <path cl\
ass=\x22ColorScheme\
-Text\x22 d=\x22m7.910\
2 3-4.9102 14h1.\
6582l1.625-4.437\
5h5.4336l0.89258\
 2.4375h1.6543l-\
4.1739-12h-2.179\
7zm1.1055 1.9375\
 2.1797 6.3438h-\
4.3906zm10.277 7\
.6758-4.5918 4.5\
918-1.1465-1.146\
5-0.70703 0.7070\
3 1.8594 1.8477 \
5.293-5.293-0.70\
703-0.70703z\x22 st\
yle=\x22fill:curren\
tColor\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x01\xe6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 10 4 L 10\
 11 L 3 11 L 3 1\
2 L 10 12 L 10 1\
9 L 11 19 L 11 1\
2 L 18 12 L 18 1\
1 L 11 11 L 11 4\
 L 10 4 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x05a\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 4 3 L 4 9 L\
 4 10 L 4 15 L 4\
 16 L 4 17 L 3 1\
7 L 3 18 L 4 18 \
L 4 19 L 5 19 L \
5 18 L 18.292969\
 18 L 19 18 L 19\
 17.292969 L 19 \
17 L 18.707031 1\
7 L 17.292969 17\
 L 5 17 L 5 15.4\
31641 L 5 15.423\
828 L 5 15 L 5 1\
2.423828 L 5 11.\
423828 L 5 11 L \
5 10 L 5 9 L 5 6\
 L 5 5.9921875 L\
 5 5 L 5 3 L 4 3\
 z M 15.048828 4\
.2304688 A 2.218\
6046 2.2186046 0\
 0 0 12.830078 6\
.4492188 A 2.218\
6046 2.2186046 0\
 0 0 15.048828 8\
.6679688 A 2.218\
6046 2.2186046 0\
 0 0 17.267578 6\
.4492188 A 2.218\
6046 2.2186046 0\
 0 0 15.048828 4\
.2304688 z M 7.9\
941406 7.7636719\
 A 0.8063584 0.8\
063584 0 0 0 7.1\
875 8.5703125 A \
0.8063584 0.8063\
584 0 0 0 7.9941\
406 9.3769531 A \
0.8063584 0.8063\
584 0 0 0 8.7988\
281 8.5703125 A \
0.8063584 0.8063\
584 0 0 0 7.9941\
406 7.7636719 z \
M 11.904297 11.1\
69922 A 1.470944\
9 1.4709449 0 0 \
0 10.433594 12.6\
40625 A 1.470944\
9 1.4709449 0 0 \
0 11.904297 14.1\
11328 A 1.470944\
9 1.4709449 0 0 \
0 13.375 12.6406\
25 A 1.4709449 1\
.4709449 0 0 0 1\
1.904297 11.1699\
22 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x01\x98\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:#da4453\x22\
 d=\x22M 10 4 L 10 \
14 L 12 14 L 12 \
4 L 10 4 z M 10 \
16 L 10 18 L 12 \
18 L 12 16 L 10 \
16 z \x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x0a(\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0a<svg width=\x2232\x22\
 version=\x221.1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 height=\x2232\x22 xm\
lns:xlink=\x22http:\
//www.w3.org/199\
9/xlink\x22 xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22>\x0a <defs id\
=\x22defs5455\x22>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4143\x22\
>\x0a   <stop style\
=\x22stop-color:#19\
7cf1\x22 id=\x22stop41\
45\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-color:#20b\
cfa\x22 id=\x22stop414\
7\x22/>\x0a  </linearG\
radient>\x0a  <line\
arGradient inksc\
ape:collect=\x22alw\
ays\x22 xlink:href=\
\x22#linearGradient\
4143\x22 id=\x22linear\
Gradient4149\x22 y1\
=\x22545.79797\x22 y2=\
\x22517.79797\x22 x2=\x22\
0\x22 gradientUnits\
=\x22userSpaceOnUse\
\x22 gradientTransf\
orm=\x22matrix(0.92\
857108 0 0 0.928\
57057 28.612354 \
37.986142)\x22/>\x0a  \
<linearGradient \
inkscape:collect\
=\x22always\x22 id=\x22li\
nearGradient4290\
\x22>\x0a   <stop styl\
e=\x22stop-color:#7\
cbaf8\x22 id=\x22stop4\
292\x22/>\x0a   <stop \
offset=\x221\x22 style\
=\x22stop-color:#f4\
fcff\x22 id=\x22stop42\
94\x22/>\x0a  </linear\
Gradient>\x0a  <lin\
earGradient inks\
cape:collect=\x22al\
ways\x22 xlink:href\
=\x22#linearGradien\
t4290\x22 id=\x22linea\
rGradient4144\x22 y\
1=\x2229.999973\x22 y2\
=\x222\x22 x2=\x220\x22 grad\
ientUnits=\x22userS\
paceOnUse\x22/>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4227\x22\
>\x0a   <stop style\
=\x22stop-color:#29\
2c2f\x22 id=\x22stop42\
29\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-opacity:0\x22\
 id=\x22stop4231\x22/>\
\x0a  </linearGradi\
ent>\x0a  <linearGr\
adient inkscape:\
collect=\x22always\x22\
 xlink:href=\x22#li\
nearGradient4227\
\x22 id=\x22linearGrad\
ient4191\x22 y1=\x229\x22\
 x1=\x229.00001\x22 y2\
=\x2223\x22 x2=\x2223.000\
04\x22 gradientUnit\
s=\x22userSpaceOnUs\
e\x22/>\x0a </defs>\x0a <\
metadata id=\x22met\
adata5458\x22/>\x0a <g\
 inkscape:label=\
\x22Capa 1\x22 inkscap\
e:groupmode=\x22lay\
er\x22 id=\x22layer1\x22 \
transform=\x22matri\
x(1 0 0 1 -384.5\
7143 -515.798)\x22>\
\x0a  <rect width=\x22\
26\x22 x=\x22387.57144\
\x22 y=\x22518.79797\x22 \
rx=\x2212.999993\x22 h\
eight=\x2226\x22 style\
=\x22fill:url(#line\
arGradient4149)\x22\
 id=\x22rect4130\x22/>\
\x0a  <path style=\x22\
fill:url(#linear\
Gradient4191);op\
acity:0.2;fill-r\
ule:evenodd\x22 id=\
\x22path4184\x22 d=\x22M \
17 9 L 15 11 L 1\
7 13 L 15 23 L 2\
3 31 L 26 31 L 2\
9 31 L 31 31 L 3\
1 27 L 31 23 L 1\
7 9 z \x22 transfor\
m=\x22matrix(1 0 0 \
1 384.57143 515.\
798)\x22/>\x0a  <path \
inkscape:connect\
or-curvature=\x220\x22\
 style=\x22fill:url\
(#linearGradient\
4144)\x22 id=\x22rect4\
133\x22 d=\x22M 16,2 C\
 8.4128491,2 2.2\
891329,7.9794391\
 2.0253906,15.5 \
2.0195214,15.667\
36 2,15.831158 2\
,16 c 0,7.756003\
 6.2439968,14 14\
,14 7.756003,0 1\
4,-6.243997 14,-\
14 0,-0.168842 -\
0.01952,-0.33264\
 -0.02539,-0.5 C\
 29.710867,7.979\
4391 23.587151,2\
 16,2 Z m 0,1 C \
23.201993,3 29,8\
.7980074 29,16 2\
9,23.201993 23.2\
01993,29 16,29 8\
.7980074,29 3,23\
.201993 3,16 3,8\
.7980074 8.79800\
74,3 16,3 Z m -1\
,6 0,2 2,0 0,-2 \
z m 0,4 0,10 2,0\
 0,-10 z\x22 transf\
orm=\x22matrix(1 0 \
0 1 384.57143 51\
5.798)\x22/>\x0a </g>\x0a\
</svg>\x0a\
\x00\x00\x02&\
<\
svg viewBox=\x220 0\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style\x0a        t\
ype=\x22text/css\x22\x0a \
       id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-NegativeT\
ext {\x0a          \
  color:#da4453;\
\x0a        }\x0a    <\
/style>\x0a    <pat\
h d=\x22M16 4A12 12\
 0 0 0 4 16a12 1\
2 0 0 0 12 12 12\
 12 0 0 0 12-12A\
12 12 0 0 0 16 4\
m-5.293 6L16 15.\
293 21.293 10s.7\
27.716.707.707L1\
6.707 16 22 21.2\
93s-.701.706-.70\
7.707L16 16.707 \
10.707 22c.001-.\
005-.707-.707-.7\
07-.707L15.293 1\
6 10 10.707c.02.\
001.707-.707.707\
-.707\x22 class=\x22Co\
lorScheme-Negati\
veText\x22 fill=\x22cu\
rrentColor\x22/>\x0a</\
svg>\x0a\
\x00\x00\x05k\
(\
\xb5/\xfd`=\x1f\x0d+\x00f\xb7\xa2#\x00q\xf4\
\x95\x5c\xa8x\xe8\x81\x85\xb0\xf6\xa0\x1e7;\xca\xf9\x87\
U(\xa4i\x9a\xdc\xc9\xbbg\xe1L\xfa\xff\xab?\xbc\
\xa3\x00\x99\x00\x8e\x00wBM\x8f\x03g\xe6l\x8d\x09\
\xe3.\x80\x0cj\xbap`\xec\xc00\xe1\xf0\xbf\xfb\xe6\
\xbb\xf5\xe4q\xc0\x1e\x5c\xbe\x9c9\x96I\xa1\xa2\xa1\xc7\
\x9c\x0c}\x86\x04E\x16G\xe3\xee\xafY\xee\x96.U\
k\xef5\xcf\x1bk\xed\xc3\x8a\xabT*O\xa6\x02*\
\xa9\x92\xa6\xc9d\xc2z\x03\xdaWS\x18\xb3\xe6\xdd7\
\xd5\x96\xf4DG\xba\xc1\xb9\x89P\x93\x8b(\x0dJ\xd3\
8({K\x98\x83\xb3\xa3\x92\xd6Z\x00\x91\x8d\xea\x01\
p\x80\xc0&\x899Z\x9a\xa2\x9b\xa5\xbb\xab\xc5js\
\xa8\xb0`ND\x82\xf2\x84%\xbd\x98\xbbg\x8e4A\
\x15\xa57V4\xb1 <\x02\xb2f\xfcd\xf6\x1e:\
g\xce\xd6\xd5\xf3L\x11Bw\x8c\x1f\x070\x87\x9a\xa2\
\x097\xca\xb4+\xa6+\x0bIB\xe3K\xa1\xa0tU\
mH\xb2\x88T\x7fT\xba\xf8\xa2\xc5\xc2W\x1d|\x92\
9\x7f\x81[\xd2P\xbe\xd4\x03uuk-\xe2\xdb7\
_\xb8Z\xea,\x94\x0b\xc6\xa7\xd2U\x8f\x10\xb81_\
2\xbf\xbaO\xf8\x8e\xae\xf9\xcd\xd7\xb3\x16\xce\xeaj\xc3\
u\xc5\x07A\xe0\x01\x03\xccy$\xfbRj\xf5\xe8\xdc\
4\xcd\xe3@G\x1bj\x16\x83D\x11\xb4)\x1ah\x82\
\xb3\xc6\x94\xc6TiJS.\xbby\x14\xe8\xc8\x9d@\
\x07;\x0c\x85\xb3B\xe7\xccV\x08#\xef\xab\x8b\xd0~\
c\x1e\x94N}\xba\xd8\x18i\x9f32>\x84\xb4\xba\
\x1f\xb0@\xd4\xbe\x13\xe6T\xd2\xa5v\xa4ztn\x1e\
u~\xb4\xf0=\x9a\x9282\xbcFH\xfd\xc1\xa9e\
\xd5\xef\xb0j\xf8\xf4S\xfd\x15Gm\xe9O\xf9R?\
\x0b\x7f\xe2'>5^\x09\x1f\xcd\xd0b<uz\xbd\
bm\xeb\xb4XcP\x7frb\xe0\x5c\xdf!\xae\xf4\
\xbe\x9f\x8fAe\x9eV\xe2\x9a?SIi\xfd\xaa_\
|\xde<\x22|,\xdf\xbf\xea\xb8fI]\xfa3\x03\
\x00\x07\x91\x8d\xaay\xd0\xf7P\x1d \xb0!\xe2\x1f\x83\
}\xfa\x9c}\x95\xa9\xee\x9e~\x84N\xa9\x00\x81/\xa7\
\xa3\x942o\xa5\x83\xb1\xb5f\xa1\xc1\xff\xf3g\xfe\x1b\
\x13\xeb\xabOB\x8f\x0b\x06\x04\x8f*@dB\x84G\
K\xe9\xed1V\xf7\xb0\xba'\xbfEF\x9d;.\x1b\
\xc2\x972El\x85P\xca\xf8\xf2\xb6\xa25\x9f\x99\xbf\
\x9cYxQ\x97\xcc\x9a8\x98\xa3\xa3\x8b\x9c\x11\xce\xda\
\xc8T8\xa0\xf7\x8dd\xa3@\x11\x86\xb8Hv\x86*\
L\xc0]\x12\x81\xb4\xe4m\x9dnZ\xca\xc0\xe9\x9em\
\x8d\x81\x12\xfa;\x0f\x81K\xa8\xf1Dh\x10\x95\x88\x04\
\x91$I!\xc3\x01!\x11A\x8c9\xe8\xae\x03\xf2X\
\x0e\xc20\x8ae \x88A\x18\x84\x08\x88\xc5\x14A\x02\
E\x04\x22\x222\x12\x8e\xa4\xd6\x01\x9a\x02\xfe\x89\x97\xdc\
y\x10}\xb3\xf7\xb6}`U^2\x17o\x16}6\
k\xe5\xd2\xea\xaf\x9c#\xfc\xf7\xc0)\xe2\xd9-\xc5'\
Y\x92)f\x81)\x83%k\x9c\x13\xdc\x06]\x1d\xa4\
\xc7\xf4/\xc2\x19\xf8[\xfcu\xaby'\xf8\x01\x92\xe0\
\xc36}\xd3`\xf3V1F\x5cO\xce\xe5\x82l\xcc\
\x06\xef\xac\x1c\x1fX\xc9\x0c\x96\xd3\xd7^\x83\x9c\x9dg\
E\x90\xa3\x19Q\xaay2lJ\xc6\xb5\x1c\x877\x87\
\x8e(\xda\x0e{^\x01\xefPF[n\x8f\x99\xae\xb9\
>gl\x07\x1e\xeaVu\x194\xe0\x100V`\x83\
\x03\xc4\xf1\x06\xd2G3\xba.\xad\xd6\xe2t\x5cW\x18\
\x1e\xc2\x04\xaa$L\x04\xa3-\xeaQ\xaf\xc1\x9dp\x81\
o\xa3\x95mv\xb4(\xa5}\xe4mv\xf0\x00rf\
\x8d\x04\x13\xbc\x96\xfe\x01\x89gG\xc3F\xd6\xf6b\x05\
\xf9\xfaf\xdb\xe3\x972\x80W\x1fi,+\x83\xc5\x0a\
\xbfD\xa0|J\xfe\xe8\x10\x8a'\xb2\xa5\x8ai\x0d\x19\
\xa7\xbc\xc2<\xa3NyN\x92\xdf\x90\xb3\x9c\xb9\x95b\
\xc4\xea:\x83\xebR`8\x052Y\x92\xc6\x98\x98s\
\x0a\x81\x19q\xa5\x19\xecP\xab\xcbC\x8f(\x10\xf9\xe8\
,gKar\xfa\x95\xc5\xc9S\x8bU\x04\x05\x81d\
\xba\xe0\xb0\x0a\x22\x01L\x1c\x09\xe5e\xc9\xb4\xb1\x05\xf7\
\xe3\x09\x80WQ_Z\xcaW\xd6>\xa4\xd1\xd3\xf1\x0c\
\xf0}xH\xe4\x8a\xdfg\xdb%hx\xb6\x0c\x0f7\
\x11\x17\x97_\xe5L\xa2\xe8\xe1$\xb4\xaaP\xb5\x85\x84\
\x16<\xc7\xec\xb4k\x0a\xd8\xe1\xa3H\xc9\x90\xcf\x97\xa3\
\xfb\x92\xaa\x8bN\x89l\xdb\xd2a\xb70\x02S\xe9T\
\xa6\xc4\xf50\xa8\xb4F\xb9,\xb7Uu\x88\x84^\xce\
\x99\xc2\x94Ss6+\xa8\xbe\xe4\x92\xdctA\xc0T\
\x16\x84\xa5v\xd7\xbcE\xf8\x8c4\xf7N)\xdb'Y\
\x96\x98\xde\xa72r\xa7\xceN\x1a\xc3\xd2\xf1\x0b\xd7\x83\
\x08\xdai\xcb\x12\xd7\xc8K1\x08\x12Gi\xa21\xd1\
\xef_\x1bW\x0d>$\xb4\xf9\xe7\x02.\x0cR\xf3V\
MP\x86\xca\xf0U6\x08\x9e&\x9a\xa4I/7\xa3\
\xc3\xee\xc3\xea\x00\x9b\x84\x85m\xe6\x1a\x9cR\xd3x\xe6\
J\xcf\x1f^}\x8c{\xe1*\xab\x18<\x7f\xa2\xdc\x0e\
\x06)\x8b\xcc\x83b\xa3\x91\xea#\x0e\x04\xdb\x90=\xbd\
\x07t\x1aJ\xe7\x92C\x0d\xferc\x917Jm\x5c\
\xdd\xb8g\xd5L4r\x1dT\x9b\xe9\x5c]\xddv\x04\
k\xe6\xde\x8a\x91O\x04\xb07\xc0\x0b\x12\xdcv\xa7\xa6\
\xca\xd3\x05\x8c\xad\x1b~f\xe7\x05eP\x90\xa8#3\
\x0a%\xca\x8e89\xd4)\x10\x9f\x9e\x8a\xb6/>\xd3\
\x04\x9d\x9e\x0b\xbe\xcc,\x0f\x8c\x14t,\xf5\xc2\xdfw\
wd>H\xb8\xfa@\x91\xa9\x02\
\x00\x00\x02\xd8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M18.5 6A3.5 \
3.5 0 0 0 15.041\
02 9H4V10H15.04A\
3.5 3.5 0 0 0 18\
.5 13 3.5 3.5 0 \
0 0 21.958984 10\
H28V9H21.961A3.5\
 3.5 0 0 0 18.5 \
6M7.5 19A3.5 3.5\
 0 0 0 4 22.5 3.\
5 3.5 0 0 0 7.5 \
26 3.5 3.5 0 0 0\
 10.960938 23H28\
V22H10.959A3.5 3\
.5 0 0 0 7.5 19m\
0 1A2.5 2.5 0 0 \
1 10 22.5 2.5 2.\
5 0 0 1 7.5 25 2\
.5 2.5 0 0 1 5 2\
2.5 2.5 2.5 0 0 \
1 7.5 20\x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x09\xce\
<\
svg viewBox=\x220 0\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22 xmlns\
:xlink=\x22http://w\
ww.w3.org/1999/x\
link\x22><radialGra\
dient id=\x22a\x22 cx=\
\x229.875001\x22 cy=\x221\
5.125\x22 gradientT\
ransform=\x22matrix\
(0 2.1428571 -2.\
1428571 0 42.410\
717 -11.160717)\x22\
 gradientUnits=\x22\
userSpaceOnUse\x22 \
r=\x2214\x22><stop off\
set=\x220\x22 stop-col\
or=\x22#fc9\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#feb01b\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22b\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410717\
 -11.160717)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#f9917f\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#fa3033\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22c\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410717\
 -11.160717)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#7dd89b\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#0ddb6e\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22d\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410716\
 -10.160716)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#81c6d6\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#279dd8\x22\
/></radialGradie\
nt><g stroke-lin\
ejoin=\x22round\x22 tr\
ansform=\x22matrix(\
1 0 0 .97753584 \
0 .35179)\x22><path\
 d=\x22m16 2c-7.731\
9865 0-14 6.2680\
135-14 14 .00046\
75 5.001251 2.66\
87898 9.622422 7\
 12.123047l7.000\
25-11.123495 7-1\
2.123047-.00025-\
.999552c-2.12814\
2-1.229214-4.542\
368-1.8765552-7-\
1.876953z\x22 fill=\
\x22url(#c)\x22/><path\
 d=\x22m3.8769531 9\
c-1.229214 2.128\
142-1.8765552 4.\
542368-1.8769531\
 7 0 7.731986 6.\
2680135 14 14 14\
 4.727485-.00044\
2 9.115362-2.384\
659 11.693622-6.\
303849.0184-.036\
29-.02708-.95997\
7-.02708-.959977\
z\x22 fill=\x22url(#b)\
\x22/><path d=\x22m12.\
376953 2.4785156\
a14 14 0 0 0 -10\
.376953 13.52148\
44 14 14 0 0 0 1\
4 14 14 14 0 0 0\
 3.623047-.47851\
6z\x22 fill=\x22url(#a\
)\x22/><path d=\x22m24\
.660156 5-5.9296\
87 10.269531v1l1\
0.267578 5.92773\
5c.661413-1.6529\
54 1.001473-3.41\
6895 1.001953-5.\
197266v-1c-.0000\
24-4.291269-1.96\
8109-8.345496-5.\
339844-11z\x22 fill\
=\x22url(#d)\x22/><pat\
h d=\x22m23 3.87695\
31-7 12.1230469.\
433594.25 6.5664\
06-11.3730469zm-\
4.269531 11.3925\
779v1l10.267578 \
5.927735c.661413\
-1.652954 1.0014\
73-3.416895 1.00\
1953-5.197266-.0\
00001-.153617-.0\
2037-.304075-.02\
539-.457031-.062\
49 1.594793-.382\
645 3.170022-.97\
6562 4.654297zm-\
16.710938.261719\
c-.00605.16139-.\
0093.322872-.009\
77.484375 0 7.73\
1986 6.2680128 1\
4 14.000001 14 5\
.187498 0 9.5315\
54-2.900934 11.7\
0226-6.355763l-.\
0184.03629-.0270\
8-.959977c-2.521\
952 3.714717-6.8\
47794 6.278974-1\
1.656776 6.27945\
-7.5312342-.0001\
44-13.712857-5.9\
58252-13.990235-\
13.484375z\x22 fill\
-opacity=\x22.14902\
\x22/></g></svg>\
\x00\x00\x02b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a\x09d=\
\x22M 4 4 L 4 8 L 5\
 8 L 5 5 L 8 5 L\
 8 4 L 4 4 z M 2\
4 4 L 24 5 L 27 \
5 L 27 8 L 28 8 \
L 28 4 L 24 4 z \
M 6 6 L 6 26 L 2\
6 26 L 26 6 L 6 \
6 z M 7 7 L 25 7\
 L 25 25 L 7 25 \
L 7 7 z M 4 24 L\
 4 28 L 8 28 L 8\
 27 L 5 27 L 5 2\
4 L 4 24 z M 27 \
24 L 27 27 L 24 \
27 L 24 28 L 28 \
28 L 28 24 L 27 \
24 z \x22\x0a\x09class=\x22C\
olorScheme-Text\x22\
\x0a    />  \x0a</svg>\
\x0a\
\x00\x00\x04^\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 4 4 L\
 4 28 L 15 28 L \
15 27 L 10 27 L \
10 20 L 18 20 L \
18 19 L 9 19 L 9\
 27 L 5 27 L 5 5\
 L 10 5 L 10 13 \
L 21 13 L 21 5 L\
 21.585938 5 L 2\
7 10.414062 L 27\
 16 L 28 16 L 28\
 10 L 22 4 L 10 \
4 L 4 4 z M 11 5\
 L 17 5 L 17 12 \
L 11 12 L 11 5 z\
 M 24.398438 16 \
L 19.287109 21.1\
11328 L 16 24.39\
8438 L 16 28 L 1\
9.601562 28 L 28\
 19.601562 L 24.\
398438 16 z M 22\
.349609 19.49023\
4 L 24.509766 21\
.650391 L 21.335\
938 24.824219 L \
21.335938 24.150\
391 L 20.322266 \
24.173828 L 19.2\
87109 24.173828 \
L 19.287109 23.1\
36719 L 19.28710\
9 22.552734 L 22\
.349609 19.49023\
4 z M 18.273438 \
23.564453 L 18.2\
73438 25.185547 \
L 20.300781 25.1\
85547 L 20.32226\
6 25.839844 L 19\
.240234 26.91992\
2 L 17.800781 26\
.919922 L 17.080\
078 26.199219 L \
17.080078 24.757\
812 L 18.273438 \
23.564453 z \x22\x0a  \
   id=\x22path76\x22 \x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x05\x9d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     class=\x22\
ColorScheme-High\
light\x22\x0a     />\x0a \
<path \x0a     styl\
e=\x22fill-opacity:\
0.33;fill-rule:e\
venodd\x22\x0a     d=\x22\
m 2,3 0,7 9,0 L \
13,8 30,8 30,5 1\
6,5 14,3 2,3 Z\x22\x0a\
     />\x0a <path \x0a\
     style=\x22fill\
:#ffffff;fill-op\
acity:0.2;fill-r\
ule:evenodd\x22\x0a   \
  d=\x22M 14 3 L 15\
 6 L 30 6 L 30 5\
 L 16 5 L 14 3 z\
 M 13 8 L 11 10 \
L 1 10 L 1 11 L \
12 11 L 13 8 z \x22\
\x0a     />\x0a <path \
\x0a     style=\x22fil\
l-opacity:0.2;fi\
ll-rule:evenodd\x22\
\x0a     d=\x22M 13 8 \
L 11 9 L 2 9 L 2\
 10 L 11 10 L 13\
 8 z M 1 28 L 1 \
29 L 31 29 L 31 \
28 L 1 28 z \x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a <path \x0a    \
 style=\x22fill:cur\
rentColor;fill-o\
pacity:0.6;strok\
e:none\x22 \x0a     d=\
\x22M 22,14 15,14.0\
04 12.559,20.695\
 11.004,18 h -1 \
v 1 h 0.428 l 2.\
133,3.693 3.02,-\
7.693 h 6.42 z m\
 -4,2 c -1.662,0\
 -3,1.338 -3,3 0\
,1.662 1.338,3 3\
,3 0.773,0 1.469\
,-0.298 2,-0.775\
 V 22 h 1 v -6 h\
 -1 v 0.775 C 19\
.469,16.298 18.7\
73,16 18,16 m 0,\
1 c 1.108,0 2,0.\
892 2,2 0,1.108 \
-0.892,2 -2,2 -1\
.108,0 -2,-0.892\
 -2,-2 0,-1.108 \
0.892,-2 2,-2\x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x05\xac\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     class=\x22\
ColorScheme-High\
light\x22\x0a     />\x0a \
<path \x0a     styl\
e=\x22fill-opacity:\
0.33;fill-rule:e\
venodd\x22\x0a     d=\x22\
m 2,3 0,7 9,0 L \
13,8 30,8 30,5 1\
6,5 14,3 2,3 Z\x22\x0a\
     />\x0a <path \x0a\
     style=\x22fill\
:#ffffff;fill-op\
acity:0.2;fill-r\
ule:evenodd\x22\x0a   \
  d=\x22M 14 3 L 15\
 6 L 30 6 L 30 5\
 L 16 5 L 14 3 z\
 M 13 8 L 11 10 \
L 1 10 L 1 11 L \
12 11 L 13 8 z \x22\
\x0a     />\x0a <path \
\x0a     style=\x22fil\
l-opacity:0.2;fi\
ll-rule:evenodd\x22\
\x0a     d=\x22M 13 8 \
L 11 9 L 2 9 L 2\
 10 L 11 10 L 13\
 8 z M 1 28 L 1 \
29 L 31 29 L 31 \
28 L 1 28 z \x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a <path \x0a    \
 style=\x22fill:cur\
rentColor;fill-o\
pacity:0.6;strok\
e:none\x22 \x0a     d=\
\x22m 16.00143,12 a\
 6,2 0 0 0 -6,2 \
v 8 a 6,2 0 0 0 \
6,2 6,2 0 0 0 6,\
-2 v -8 a 6,2 0 \
0 0 -6,-2 m 0,1 \
a 5,1 0 0 1 5,1 \
5,1 0 0 1 -5,1 5\
,1 0 0 1 -5,-1 5\
,1 0 0 1 5,-1 m \
-5,2.10156 a 6,2\
 0 0 0 5,0.89844\
 6,2 0 0 0 5,-0.\
89648 v 2.896 a \
5,1 0 0 1 -5,1 5\
,1 0 0 1 -5,-1 z\
 m 0,4 a 6,2 0 0\
 0 5,0.89844 6,2\
 0 0 0 5,-0.8964\
8 v 2.896 a 5,1 \
0 0 1 -5,1 5,1 0\
 0 1 -5,-1 z\x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a</svg>\x0a\
\x00\x00\x02\x99\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 4 4 L\
 4 28 L 9 28 L 2\
3 28 L 28 28 L 2\
8 10 L 27 9 L 23\
 5 L 22 4 L 21 4\
 L 10 4 L 4 4 z \
M 5 5 L 10 5 L 1\
0 13 L 21 13 L 2\
1 5 L 21.585938 \
5 L 27 10.414062\
 L 27 27 L 23 27\
 L 23 19 L 9 19 \
L 9 27 L 5 27 L \
5 5 z M 11 5 L 1\
7 5 L 17 12 L 11\
 12 L 11 5 z M 1\
0 20 L 22 20 L 2\
2 27 L 10 27 L 1\
0 20 z \x22\x0a     id\
=\x22path60\x22 \x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02\xc6\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 32 32\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <style i\
d=\x22current-color\
-scheme\x22 type=\x22t\
ext/css\x22>.ColorS\
cheme-Text {\x0a   \
         color:#\
232629;\x0a        \
}</style>\x0a    <r\
ect id=\x22rect837\x22\
 class=\x22ColorSch\
eme-Text\x22 x=\x225\x22 \
y=\x224\x22 width=\x221\x22 \
height=\x229\x22 fill=\
\x22currentColor\x22 f\
ill-rule=\x22evenod\
d\x22/>\x0a    <path i\
d=\x22path840\x22 clas\
s=\x22ColorScheme-T\
ext\x22 d=\x22m11.5 3.\
7929688-0.353516\
 0.3535156-4.353\
5152 4.3535156 4\
.3535152 4.35351\
6 0.353516 0.353\
515 0.707031-0.7\
07031-0.353515-0\
.353516-3.146484\
8-3.146484h8.292\
9688c4.986 0 9 4\
.014 9 9s-4.014 \
9-9 9h-1v1h1c5.5\
4 0 10-4.46 10-1\
0s-4.46-10-10-10\
h-8.2929688l3.14\
64848-3.1464844 \
0.353515-0.35351\
56-0.707031-0.70\
70312z\x22 fill=\x22cu\
rrentColor\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\xc1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 6 4 L 6 28 L 1\
3 28 L 13 27 L 7\
 27 L 7 5 L 18 5\
 L 18 12 L 25 12\
 L 25 16 L 26 16\
 L 26 11 L 19 4 \
L 18 4 L 6 4 z M\
 14 16 L 14 17 L\
 14 20 L 14 21 L\
 14 27 L 14 28 L\
 26 28 L 26 27 L\
 26 20 L 26 19 L\
 26 18 L 21 18 L\
 19 16 L 19 16 L\
 19 16 L 15 16 L\
 14 16 z M 15 17\
 L 18.6 17 L 19.\
6 18 L 19 18 L 1\
9 18 L 19 18 L 1\
7 20 L 15 20 L 1\
5 17 z M 15 21 L\
 25 21 L 25 27 L\
 15 27 L 15 21 z\
 \x22\x0a     class=\x22C\
olorScheme-Text\x22\
\x0a     />\x0a</svg>\x0a\
\
\x00\x00\x034\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 6.292\
9688 4 L 5 5.292\
9688 L 5 7.83203\
12 C 5.055 7.872\
0313 13 18.5 13 \
18.5 L 13 23.509\
766 L 19 28.0117\
19 L 19 18.50195\
3 L 27 7.8339844\
 L 27 5.2949219 \
L 25.707031 4.00\
19531 L 6.292968\
8 4 z M 6.707031\
2 5 L 25.292969 \
5 L 26 5.7070312\
 L 26 7.5019531 \
L 18 18.167969 L\
 18 26.009766 C \
16.84 25.142766 \
15.285 23.975766\
 14 23.009766 L \
14 18.167969 L 6\
 7.5019531 L 6 5\
.7070312 L 6.707\
0312 5 z M 7 6 L\
 12 12.5 C 11.98\
5 12.505 12 9 12\
 9 L 15 6 L 7 6 \
z \x22\x0a     id=\x22pat\
h64\x22 \x0a     class\
=\x22ColorScheme-Te\
xt\x22\x0a     />\x0a</sv\
g>\x0a\
\x00\x00\x02]\
<\
!DOCTYPE svg>\x0a<s\
vg version=\x221.1\x22\
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22 viewBox=\x220 0\
 32 32\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 7 5 L 18 \
5 L 18 12 L 25 1\
2 L 25 19 L 26 1\
9 L 26 11 L 19 4\
 L 6 4 L 6 28 L \
19 28 L 19 27 L \
7 27 L 7 5 Z M 1\
6.9961 22.5 L 16\
.9961 23.5 L 25.\
0859 23.5 L 21.2\
93 27.293 L 22 2\
8 L 27 23 L 22 1\
8 L 21.293 18.70\
7 L 25.0859 22.5\
 L 16.9961 22.5 \
Z\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xca\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:#eb0a42\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     />\x0a <pa\
th \x0a     style=\x22\
fill-opacity:0.3\
3;fill-rule:even\
odd\x22\x0a     d=\x22m 2\
,3 0,7 9,0 L 13,\
8 30,8 30,5 16,5\
 14,3 2,3 Z\x22\x0a   \
  />\x0a <path \x0a   \
  style=\x22fill:#f\
fffff;fill-opaci\
ty:0.2;fill-rule\
:evenodd\x22\x0a     d\
=\x22M 14 3 L 15 6 \
L 30 6 L 30 5 L \
16 5 L 14 3 z M \
13 8 L 11 10 L 1\
 10 L 1 11 L 12 \
11 L 13 8 z \x22\x0a  \
   />\x0a <path \x0a  \
   style=\x22fill-o\
pacity:0.2;fill-\
rule:evenodd\x22\x0a  \
   d=\x22M 13 8 L 1\
1 9 L 2 9 L 2 10\
 L 11 10 L 13 8 \
z M 1 28 L 1 29 \
L 31 29 L 31 28 \
L 1 28 z \x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a <path \x0a     st\
yle=\x22fill:curren\
tColor;fill-opac\
ity:0.6;stroke:n\
one\x22 \x0a     d=\x22M \
16 13 C 15.4 13 \
15 13.4 15 14 C \
15 14.5 15.4 20 \
16 20 C 16.5 20 \
17 14.5 17 14 C \
17 13.4 16.5 13 \
16 13 z M 16 21 \
A 1 1 0 0 0 15 2\
2 A 1 1 0 0 0 16\
 23 A 1 1 0 0 0 \
17 22 A 1 1 0 0 \
0 16 21 z \x22\x0a    \
 class=\x22ColorSch\
eme-Text\x22\x0a     /\
>\x0a</svg>\x0a\
\x00\x00\x04{\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a  <path\
 \x0a        style=\
\x22fill:currentCol\
or;fill-opacity:\
1;stroke:none\x22\x0a \
       d=\x22M 5.5 \
2 C 4.119 2 3 3.\
119 3 4.5 L 3 7.\
5 C 3 8.881 4.11\
9 10 5.5 10 C 6.\
881 10 8 8.881 8\
 7.5 L 8 4.5 C 8\
 3.119 6.881 2 5\
.5 2 z M 11.5 2 \
C 10.119 2 9 3.1\
19 9 4.5 L 9 7.5\
 C 9 8.881 10.11\
9 10 11.5 10 C 1\
2.881 10 14 8.88\
1 14 7.5 L 14 4.\
5 C 14 3.119 12.\
881 2 11.5 2 z M\
 5.5 3 C 6.328 3\
 7 3.672 7 4.5 L\
 7 7.5 C 7 8.328\
 6.328 9 5.5 9 C\
 4.672 9 4 8.328\
 4 7.5 L 4 4.5 C\
 4 3.672 4.672 3\
 5.5 3 z M 11.5 \
3 C 12.328 3 13 \
3.672 13 4.5 L 1\
3 7.5 C 13 8.328\
 12.328 9 11.5 9\
 C 10.672 9 10 8\
.328 10 7.5 L 10\
 4.5 C 10 3.672 \
10.672 3 11.5 3 \
z M 2 9 L 2 10 L\
 3 10 L 3 9 L 2 \
9 z \x22\x0a        cl\
ass=\x22ColorScheme\
-Text\x22\x0a        /\
>\x0a  <path\x0a     s\
tyle=\x22fill:curre\
ntColor;fill-opa\
city:1;stroke:no\
ne\x22\x0a     d=\x22m 11\
,9 0,2 -2,0 0,1 \
2,0 0,2 1,0 0,-2\
 2,0 0,-1 -2,0 0\
,-2 z\x22\x0a     clas\
s=\x22ColorScheme-H\
ighlight\x22\x0a      \
/>\x0a</svg>\x0a\
\x00\x00\x03\x00\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 7 2 C 5.895 2 \
5 2.895 5 4 L 5 \
7 L 3 7 L 3 8 L \
5 8 L 5 14 L 6 1\
4 L 6 8 L 8 8 L \
8 7 L 6 7 L 6 4 \
C 6 3.448 6.448 \
3 7 3 L 9 3 L 9 \
2 L 8 2 L 7 2 z \
M 9.4707031 9.75\
97656 L 8.763671\
9 10.466797 L 10\
.177734 11.88085\
9 L 8.7636719 13\
.294922 L 9.4707\
031 14.001953 L \
10.884766 12.587\
891 L 12.298828 \
14.001953 L 13.0\
05859 13.294922 \
L 11.591797 11.8\
80859 L 13.00585\
9 10.466797 L 12\
.298828 9.759765\
6 L 10.884766 11\
.173828 L 9.4707\
031 9.7597656 z \
\x22\x0a     class=\x22Co\
lorScheme-Text\x22\x0a\
     />\x0a</svg>\x0a\
\x00\x00\x02}\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <d\
efs>\x0a        <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a   \
 </defs>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22\x0a        \
  d=\x22m9.0000002 \
9v3h1.9999998v-1\
h-1v-2zm0.999999\
8-1c-1.6619998 0\
-2.9999998 1.338\
-2.9999998 3s1.3\
38 3 2.9999998 3\
c1.662 0 3-1.338\
 3-3s-1.338-3-3-\
3zm0 1a2 2 0 0 1\
 2 2 2 2 0 0 1-2\
 2 2 2 0 0 1-1.9\
999998-2 2 2 0 0\
 1 1.9999998-2zm\
-7-7v12h4v-1h-3v\
-10h5v3h3v2h1v-3\
l-3-3h-1z\x22\x0a     \
     class=\x22Colo\
rScheme-Text\x22\x0a  \
  />\x0a</svg>\x0a\
\x00\x00\x01\xef\
<\
svg viewBox=\x220 0\
 16 16\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style type=\x22tex\
t/css\x22 id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-Text {\x0a  \
          color:\
#232629;\x0a       \
 }\x0a    </style>\x0a\
    <g class=\x22Co\
lorScheme-Text\x22 \
fill=\x22currentCol\
or\x22 fill-rule=\x22e\
venodd\x22>\x0a       \
 <path d=\x22m8 2a6\
 6 0 0 0 -6 6 6 \
6 0 0 0 6 6 6 6 \
0 0 0 6-6 6 6 0 \
0 0 -6-6zm0 1a5 \
5 0 0 1 5 5 5 5 \
0 0 1 -5 5 5 5 0\
 0 1 -5-5 5 5 0 \
0 1 5-5z\x22/>\x0a    \
    <path d=\x22m7 \
4h2v2h-2z\x22/>\x0a   \
     <path d=\x22m7\
 7h2v5h-2z\x22/>\x0a  \
  </g>\x0a</svg>\x0a\
\x00\x00\x04\xdf\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22m 2,2 0,5.\
9960938 0,1 L 2,\
14 l 12,0 0,-1 -\
11,0 0,-1 3.0058\
59,0 0,-0.0078 0\
.0078,0.0078 2,-\
2 1.591797,0 2,2\
 2.40039,0 0,-1 \
-1.986328,0 -2,-\
2 -1.414062,0 -1\
.00586,0 -2,2 L \
3,11 3,8.9960938\
 l 2,0 0,-0.0078\
1 0.0078,0.00781\
 L 6.003906,8 7,\
8 8,8 8,7 7,7 7,\
6 6,6 6,7.996093\
8 5.296875,7.292\
9688 4.59375,7.9\
960938 3,7.99609\
38 3,2 2,2 Z M 6\
,2 6,3 6,4 7,4 7\
,3 8,3 8,2 6,2 Z\
 m 4,0 0,1 1,0 0\
,1 1,0 0,-2 -1,0\
 -1,0 z M 9,3.58\
98438 7.296875,5\
.2929688 8.00390\
6,6 9,5.0039062 \
9.996094,6 10.70\
3125,5.2929688 9\
,3.5898438 Z M 1\
1,6 l 0,1 -1,0 0\
,1 2,0 0,-1 0,-1\
 -1,0 z m 3,0 -1\
,1 1,0 0,-1 z\x22\x0a \
    class=\x22Color\
Scheme-Text\x22/>\x0a \
<path \x0a     styl\
e=\x22fill:currentC\
olor;fill-opacit\
y:0.5;stroke:non\
e\x22 \x0a     d=\x22M 9 \
5 L 7.0039062 7 \
L 8 7 L 8 8 L 6.\
0058594 8 L 5.00\
78125 9 L 1.9980\
469 9 L 1.998046\
9 13 L 6.9980469\
 13 L 8.9980469 \
12.992188 L 13.9\
98047 13 L 13.99\
8047 7 L 11.9980\
47 7 L 11.998047\
 8 L 9.9980469 8\
 L 9.9980469 7 L\
 10.998047 7 L 9\
 5 z \x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a</svg>\x0a\
\x00\x00\x02r\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-NegativeTex\
t {\x0a        colo\
r:#da4453;\x0a     \
 }\x0a      </style\
>\x0a  </defs>\x0a  <p\
ath\x0a     style=\x22\
fill:currentColo\
r;fill-opacity:1\
;stroke:none\x22 \x0a \
    class=\x22Color\
Scheme-NegativeT\
ext\x22\x0a    d=\x22M 8,\
2 A 6,6 0 0 0 2,\
8 6,6 0 0 0 8,14\
 6,6 0 0 0 14,8 \
6,6 0 0 0 8,2 Z \
M 5.70703,5 8,7.\
29297 10.29297,5\
 11,5.70703 8.70\
703,8 11,10.2929\
7 10.29297,11 8,\
8.70703 5.70703,\
11 5,10.29297 7.\
29297,8 5,5.7070\
3 5.70703,5 Z\x22\x0a \
       />\x0a</svg>\
\x0a\
\x00\x00\x06\x98\
(\
\xb5/\xfd`\xb1#u4\x00\x9aB(\x0c(\xe0N\
\x88\x1e\x1b)l'\x01\x99\xd8O\x8a\xcf\xe0\x02(b\
n|\xc4\x0a\x8a\x85\xa2C\xbb\xe1+b\xc1\x14n0\
\xc3|\x14C\x08\x01\xbe\x00\xb7\x00\xb0\x00\x0b\x12@@\
0\xaf\xbb\xde\xba_J8\xac\xa7NUR\x19G\xd8\
*\x8d\xc5\x17\x01\x9bt\x9e\x13\xa7\x8b!\xbc)\xcd\x85\
\xa2',aJ\x03\xc1\x07\x1e\x0f9\x18\xfd\xb62\xf4\
K\xf5\x19\xd5\xea\xbb\xefb*\x81\x84\x04\xcc\xfei\xbd\
\xf367\xb0^\x0c\x0b\x13\x14A\x10\x0cc\xac)H\
\xddSD+\xd5\x1a\xd3\x18C)u\xf7X\x8f\xc7\xc3\
\xb9\x19\x80\x9e\xf4\x84%\x09\xdbw@\xbb~\xb6Va\
|9\xa3\xf7\xf4\xd2G\xcf\xd8\xcb<\x19\xaf(7\x18\
\x0c\x83`\xec\xbdP\x1a{\x11zJ\x92\x84\xe1q\xe8\
\x04\x83C\x01\x05OJ\xf3\x13\x8e\xea\x9d\xea\xd6\x892\
\xd5\x02\x09\x13\x94\xe6\x99\xa0\x8b\xed\xf4\x89\xc2\x96+\xcd\
\x84!\x9d\xdf\x91D\x12\xa4@\x22\xb26\x17]!\xe1\
\x8d\x1e\xed\xbc~/\x95r\xfa|\xa90o\xaf1\xee\
\xdc\xc2\xf6\xa0\x9c\xcc\xce\xdb\x22\xb4\x969\x0c6w\xfb\
\xb5\xe3\xe0k\x9d;\x19\xb3\xd6-\x00\xa5QJ|\xce\
1\xf0\xd6\x8as\xcdg\xe45W\x9a\x06y=az\
\x10!\xbf\xd6\x1b\x9a&<{z\xe8\xd6\xcc \xd7w\
\x07J)\xf7\xa0\x5c\xd9I\xe5\xa2\x0e&\xee\xb9\x84k\
\xb2\xd7\xc0\x00\x08P\x1a\xa7\x81rD_\xa8\xc9Xt\
\xbed\x12]\xb1\xa4Q\xea\xe2\x5cS\xd9\x99\xbc\xb6\xd8\
\x951\xb5\xf3\x97a\x98\x84\xc3G\x1bb\x12\xe5!\x8a\
\xa0\x1d\x81\x81\xa4\xcf\xcf\x88l&1@\x82\x1cv\x95\
2v\x10\xf6*\xcdn`EM\x18,dL\x01a\
m\xce=O\xfeH\x8d\xd4\x9e>\xe7\xc6\xfd\x0b\x90\x04\
A\xaa\x14\x9d\xcb\x16%|\x91\xe7Xk\x8e.\xa94\
\x10\x0b\xe5z\x12\xc6\x17^G\xd5\xc9\xcf\x03/\xb4\x02\
\xa5\xdb\x8b\x07\xfa\x05\x8bp\xf1P\x13\xf4hJ\xf3\xc0\
\xb7.\xf4_\xa8q\xa1\xfc\xb0\xb7S\xcd\x1f\xe1\xbd\xed\
WP`W\x9a\xc8\x86p\xcc\x7f3V\xfcS\x19\xf7\
\xa5:i\xe7/\x93\x98\x91\xba\xe7\x8dI\x146\x9fk\
\xce\xe7\x05BG\xea#\xaa\xf6\xa3g\xcd\xc5\x97\xf3\x9d\
\xb9\xf9p\xda\xf6.\xdfM\xfb\xde\xa7G\xe8\xf0\xa9\xf4\
F]\xb5N\x94\xce|\x15\xba'\xaf\xa3\x0a\x97MV\
6\xedS&\xa9}\xc5\x8cM2\x85\xbd\xd3\x19\x8cn\
g\x0c\x0e\x8fC3\x89\xc9@\xb6\x87\x05\xd0\x81\x02\xd7\
\x12x{\xb2-\xda\xe62\xd9r\xe9\xd4#\x02\xf9p\
\x00\x12P\xd4\xc5%\xa5\x5c\x9c\xc2\xe5\x9es\xd7\x98/\
\xeejy\xb3\xcd\xe6\x04\x1a\x1a\x02\xca\xde\xc3\x01i\x80\
\xbd\xfc\x9b\xb2'\x17C\xbc\xb9\xdc\xcd\xd5\xe0{\xec=\
L\xe2a\xd2\x06D\x14\xd9\xfascWGnX\x95\
\xf14-,\xbaJ\xa2$\xfa\x12=aKb\x13\xc9\
\xe0\x92H\xe9 B&\x09\xc0\x987\x80\x8a\x01Ev\
Q\xfa\x96\xe9\x04\xfc\xae\x91\x9bqE*\x17\x17W\xa3\
J-\xce\xa5\x8b\xd39U\x1a\x9c\x8c\xcf-\x19\xa9\x82\
\x8e\xb9\xd5\xd4\x22\xa3dl\x91M\xc2\x18\x99\x00\x08\x94\
w\x952v\xf4\xa63\x81\xa0\xa81=D5%\x92\
$\x05\x85\xd2p!\x09!\xceA\xe7r\x1b\x22Q\x12\
\xe2`\x12c\x10\xa3\x881\x84\x18B\x0c5\x82\x22\x81\
\x88\xc8\x08E\x12\xa4\xa4\x0e\x8a\x0d3\xf8\x0e\xce\x83H\
<\xe5Bi\xde\x06PD\x0ed_\x12Q\xacU\x16\
\x94\xa8\xbb\x9dT\xe1t/\x16\xdc\x8d\xb7\xfb\xb1\xc8\xfb\
\x0a\xa6\x1b\xc6\xb1\x1a\xe1\xd2\x22?Fw\xed\x86]\xae\
\xc0c/\x1d\x0d!\xc1\x8d\x921rt\x1c\x95\x84?\
/\x9c\xfb8\xcd\xcd\xbeO\x08:8\xf7{\x96Zq\
\xc7\x074.\xe9\xd1\xec\xf2x\x86\xf6s.\xfd\xd6\xee\
m\xcd?\xde7\xb0\xff\xd0\xbfQ\x01\xb8{\x8cQ\x0c\
\x09\x8e\xdclr\xee\x13\xc54\xc0\x16\xc9\xda\x0bH\xee\
\xb3\x22\xd65F\xbc\xfa\x83Y\xb4\x8f\x10}\xb0\x06D\
\xca\xe9\xa19\x95(\x907\xfc31h\xb3r\x88S\
\xa3\x86%\xad\x99F0\xed`/\xf2t\xe6>\x0c2\
B\x14\x1c\xa2\x80Rv\xf4<\xd9\x02\xd0U\x5ct \
g%\x82|\xfd\x82\xc2\xe1\x82\x03x\xd1\x80\xfd;\xe9\
\xb7\xfb\xa5\x5c\xaa[G\x17\xf21;t\xcbcX\x14\
\xcc\x18a\xa9>X\x02\xe0\xa2\xa9f\xd4Q\xa9\xc1\x00\
!!N\x90EY\xa2*\x05z\x95\x92\x92IaA\
e\x15\xc1J\xe7\xf5J\xf1\x1a*\x82\xe4A\xd2\x1f\xa2\
~I\x8b\xda \xe9J\x8b\x92\xef48\x1a\xf1+\xf9\
%S\x9f\xfb\x1e\xf4\xb5)\x9d\xbf'D>\x881\x10\
5q\x10\xe8tNWy\xe08\x1fB\xc8\xc4\xff\x85\
#!\x7f^G\x97.I\xb59}\x5c\x08\xee9\xf8\
\x83\x83E\xd9\xfaA\xd8\x98\xd4\xb7\x05b\x06\x8b\x03`\
\xae)P\xfc\x01<\xd8\xef\x89\x88\xcc\x91\x9d:l=\
\xdd,/`\x0et\x1f@\x05\x8a\x00q\xee\x8b\x98O\
\x8e\xc0wC=vRDU\xe0\xb3\xd3\xa5}\xe7m\
\x8c\xe3<}w\xac\xb7\xe2\xe9\xfb\xd9\xba0\xe1\xb7\xa3\
\x03\xa6\xbe\xca\xa0\xaa2P\xf7\x9a\x1b\xfd(5\x5c[\
\xd8oa\xc6\xe9\x16\xb9g\xa7\xc5\x1d\x9aNx\x048\
r\xf0Z\xdc\x8dN{\x8f\x87LV`U\xb0G\xb0\
|\xc0Y&\xe5\x5c\x99\x07c\x87\x5c\xf6\x0fA\xe1\xb1\
q\x02\x8bu\x96d\x01wL:<|\xb2\xf4\xda~\
W\xcd\xber\x83\xe0\xd6-}\x80b\x9d%Yn\xb3\
@\x173\xda\xfc\xd5\x9a@\x8f\x92\x0bT(\x04\x94\x0f\
\x16k\x1b6K,\x16\x1aN\x10\x9a\xd2\xf3\xbc\xbat\
\xbf\x8c)\x02\x12FW^\x90\xb6\xf0\xd6H\xa2E\xd6\
D,5\x9f\x07\x94y\x22\xcf\xa1\xad\xdc\x13\xf8\xb1{\
\xfd,\x01\x09\xa1\x02\x0eQ\xa1\xedKv\x94\xc9\x14\x85\
U}\x06\xe5q\xb4M\xecp\x01N\xa9\xa8F\x01=\
\xd2r{\xc80\xea\x22%;kXK7\x92)4\
\x90\x03\xfexF!\xe6x\x19\xdc\xd6,\xa6kI\xd2\
\xbe\xe4\x00-\x06\x8eA=v\xc9\x06`\xe7G\xb5\xce\
\xd3\xb6\x99\xc0\xb2\xa1hX\xa2 \xfbK\xaf\xdc\xe6\x9f\
\x8beP<\xfe\xb5:R}\xfc\x22\xd4\x83\x7f\xe9i\
\xa3[)\x09K6\x0b8l\x1c\x1b5(,\xe3\xe4\
\xb5L\x98\xd2>\xaa\xd7\xd6KM\xc3\xda0\x80\x8d=\
\xaf\xbf\xe0A\xbeR\xc2\xfd@j\xb1X\x1d\x9e\xc4\x5c\
a\xf8!h\x91^\xcd{q\xc4\xc3>A:&1\
\xfd\xc7}P\xad\xeaZ~\xf4\x10\xc5l\xaa>\xffr\
\x80\xe6\x96@=\x1ahh`\xb1-\xd1\xcc\x1aD\x9f\
w\x14f\xf9)\xcb\x08\xfcR\xaf\x9b\x90\xd3\xcf\xb78\
*\xb2@\xbfp0!i4ih\x9f\xfb\x15\x97\x9f\
\x0a1\xff\x9c\xa5\x0a\x91\xc2\xc4;\x0d+\xc7\xae.C\
C\xba\xea\x03]\xb1\x0a\
\x00\x00\x03\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 10 2.5 C 9.0\
680195 2.5 8.284\
4627 3.1373007 8\
.0625 4 L 2 4 L \
2 5 L 8.0625 5 C\
 8.2844627 5.862\
6993 9.0680195 6\
.5 10 6.5 C 10.9\
31981 6.5 11.715\
537 5.8626993 11\
.9375 5 L 14 5 L\
 14 4 L 11.9375 \
4 C 11.715537 3.\
1373007 10.93198\
1 2.5 10 2.5 z M\
 5 9.5 C 4.06801\
91 9.5 3.2844626\
 10.137301 3.062\
5 11 L 2 11 L 2 \
12 L 3.0625 12 C\
 3.2844626 12.86\
2699 4.0680191 1\
3.5 5 13.5 C 5.9\
319809 13.5 6.71\
55374 12.862699 \
6.9375 12 L 7 12\
 L 9 12 L 14 12 \
L 14 11 L 9 11 L\
 7 11 L 6.9375 1\
1 C 6.7155374 10\
.137301 5.931980\
9 9.5 5 9.5 z M \
5 10.5 C 5.55228\
 10.5 6 10.94772\
 6 11.5 C 6 12.0\
5228 5.55228 12.\
5 5 12.5 C 4.447\
72 12.5 4 12.052\
28 4 11.5 C 4 10\
.94772 4.44772 1\
0.5 5 10.5 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02 \
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 8 2 A 6.000001\
9 6.0000148 0 0 \
0 2 8 A 6.000001\
9 6.0000148 0 0 \
0 8 14 A 6.00000\
19 6.0000148 0 0\
 0 14 8 A 6.0000\
019 6.0000148 0 \
0 0 8 2 z M 8 3 \
L 8 8 L 13 8 A 5\
 5 0 0 1 8 13 A \
5 5 0 0 1 3 8 A \
5 5 0 0 1 8 3 z \
\x22\x0a     class=\x22Co\
lorScheme-Text\x22\x0a\
     />\x0a</svg>\x0a\
\x00\x00\x02-\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 4 L 3 \
4 L 3 3 L 13 3 L\
 13 4 L 14 4 L 1\
4 2 L 2 2 z M 8 \
4 L 3 9.1679688 \
L 3.8046875 10 L\
 8 5.6621094 L 1\
2.195312 10 L 13\
 9.1679688 L 8 4\
 z M 6 10 L 6 14\
 L 7 14 L 10 14 \
L 10 10 L 9 10 L\
 9 13 L 7 13 L 7\
 10 L 6 10 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x058\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2.5 2 C 2.2238\
576 2 2 2.223857\
6 2 2.5 C 2 2.77\
61424 2.2238576 \
3 2.5 3 C 2.7761\
424 3 3 2.776142\
4 3 2.5 C 3 2.22\
38576 2.7761424 \
2 2.5 2 z M 5.5 \
2 C 5.2238576 2 \
5 2.2238576 5 2.\
5 C 5 2.7761424 \
5.2238576 3 5.5 \
3 C 5.7761424 3 \
6 2.7761424 6 2.\
5 C 6 2.2238576 \
5.7761424 2 5.5 \
2 z M 13.160156 \
2 L 9.7382812 6.\
3105469 C 9.0627\
65 6.0537156 8.2\
111082 5.9824498\
 7 6 C 5.6442244\
 7.2930815 4.750\
7597 7.7091991 2\
 8 L 2 9 C 4.113\
7135 12.371692 5\
.4745763 14 9 14\
 L 10 14 C 11.07\
3961 12.616195 1\
1.627119 11.6101\
69 12 10 L 12 9 \
C 11.558507 8.00\
93924 11.158004 \
7.334604 10.6738\
28 6.8789062 L 1\
4 2.6601562 L 13\
.160156 2 z M 4 \
4 C 3.4477153 4 \
3 4.4477153 3 5 \
C 3 5.5522847 3.\
4477153 6 4 6 C \
4.5522847 6 5 5.\
5522847 5 5 C 5 \
4.4477153 4.5522\
847 4 4 4 z M 7.\
5292969 7.101562\
5 C 9.6322903 7.\
2655765 10.16858\
5 8.0162663 10.8\
57422 9.6992188 \
C 10.284594 11.2\
4586 10.385403 1\
1.602833 9.27343\
75 12.96875 C 6.\
1355922 12.69491\
5 5.052768 11.54\
0538 3.3261719 8\
.8300781 C 5.122\
354 8.7567482 6.\
1084274 8.104628\
5 7.5292969 7.10\
15625 z \x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x04\xe7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 13.314453 2 L \
2 13.294922 L 2.\
7148438 14 L 14 \
2.6972656 L 13.3\
14453 2 z M 8 3 \
A 8.9999916 9.00\
0003 0 0 0 0.123\
04688 7.6679688 \
C 0.25199187 8.0\
317035 0.4804856\
2 8.3445563 0.77\
929688 8.5761719\
 A 7.9999926 8.0\
000028 0 0 1 8 4\
 A 3.9999993 4.0\
000007 0 0 0 4 8\
 A 3.9999993 4.0\
000007 0 0 0 4.1\
054688 8.8945312\
 L 5 8 A 2.99999\
93 3.0000005 0 0\
 1 8 5 L 8.89257\
81 4.1074219 A 3\
.9999993 4.00000\
07 0 0 0 8.34960\
94 4.0175781 A 7\
.9999926 8.00000\
28 0 0 1 8.92773\
44 4.0722656 L 9\
.8066406 3.19335\
94 A 8.9999916 9\
.000003 0 0 0 8 \
3 z M 13.835938 \
5.1640625 L 13.1\
21094 5.8789062 \
A 7.9999926 8.00\
00028 0 0 1 15.2\
20703 8.5761719 \
C 15.522218 8.34\
24607 15.752612 \
8.0261216 15.880\
859 7.6582031 A \
8.9999916 9.0000\
03 0 0 0 13.8359\
38 5.1640625 z M\
 11.894531 7.105\
4688 L 11 8 A 2.\
9999993 3.000000\
5 0 0 1 8 11 L 7\
.1074219 11.8925\
78 A 3.9999993 4\
.0000007 0 0 0 8\
 12 A 3.9999993 \
4.0000007 0 0 0 \
12 8 A 3.9999993\
 4.0000007 0 0 0\
 11.894531 7.105\
4688 z \x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02\xbe\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 13.281\
25 L 2 14 L 8 14\
 L 8 10 L 7.6562\
5 10.34375 L 6.3\
125 9 L 6.28125 \
9 L 3 12.28125 L\
 3 3 L 13 3 L 13\
 8 L 14 8 L 14 2\
 L 2 2 z M 6 4 C\
 4.8954305 4 4 4\
.8954305 4 6 C 4\
 7.1045695 4.895\
4305 8 6 8 C 7.1\
045695 8 8 7.104\
5695 8 6 C 8 4.8\
954305 7.1045695\
 4 6 4 z M 11 9 \
L 11 11 L 9 11 L\
 9 12 L 11 12 L \
11 14 L 12 14 L \
12 12 L 14 12 L \
14 11 L 12 11 L \
12 9 L 11 9 z \x22\x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x02\x82\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 2 2 L 2 5 L \
3 5 L 3 3 L 5 3 \
L 5 2 L 3 2 L 2 \
2 z M 11 2 L 11 \
3 L 13 3 L 13 5 \
L 14 5 L 14 2 L \
13 2 L 11 2 z M \
4 4 L 4 12 L 12 \
12 L 12 4 L 4 4 \
z M 5 5 L 11 5 L\
 11 11 L 5 11 L \
5 5 z M 2 11 L 2\
 14 L 3 14 L 5 1\
4 L 5 13 L 3 13 \
L 3 11 L 2 11 z \
M 13 11 L 13 13 \
L 11 13 L 11 14 \
L 14 14 L 14 13 \
L 14 11 L 13 11 \
z \x22\x0a     class=\x22\
ColorScheme-Text\
\x22\x0a     />\x0a</svg>\
\x0a\
\x00\x00\x02\x11\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a    <\
path \x0a        st\
yle=\x22fill:curren\
tColor;fill-opac\
ity:1;stroke:non\
e\x22 \x0a          d=\
\x22M 2 2 L 2 12 L \
5 15 L 5 12 L 14\
 12 L 14 2 L 2 2\
 z M 3 3 L 13 3 \
L 13 11 L 3 11 L\
 3 3 z M 7 4 L 7\
 5 L 9 5 L 9 4 L\
 7 4 z M 7 6 L 7\
 10 L 9 10 L 9 6\
 L 7 6 z \x22\x0a     \
     id=\x22rect416\
3\x22 \x0a          cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03\x95\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 14 L 3\
 14 L 4 14 L 7 1\
4 L 7 13 L 6 13 \
L 5 13 L 5 10 L \
6 10 L 7 10 L 8 \
10 L 8 9 L 7 9 L\
 5 9 L 3.96875 9\
 L 3.96875 13 L \
3 13 L 3 3 L 4 3\
 L 5 3 L 5 6 L 5\
 7 L 7 7 L 11 7 \
L 11 6 L 11 3 L \
11.28125 3 L 13 \
4.71875 L 13 5 L\
 13 7 L 14 7 L 1\
4 4.28125 L 11.7\
1875 2 L 11.6875\
 2 L 11 2 L 4 2 \
L 3 2 L 2 2 z M \
6 3 L 7.90625 3 \
L 7.90625 6 L 6 \
6 L 6 3 z M 12 8\
 L 11 9 L 10 10 \
L 8 12 L 8 13 L \
8 14 L 10 14 L 1\
1 13 L 12 12 L 1\
3 11 L 14 10 L 1\
2 8 z M 11.68945\
3 9.6894531 L 12\
.28125 10.28125 \
L 10.59375 11.96\
875 L 10.59375 1\
1.984375 L 9.312\
5 13.28125 L 8.7\
1875 12.6875 L 1\
1.689453 9.68945\
31 z \x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22\x0a     />\x0a</s\
vg>\x0a\
\x00\x00\x04\xa6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629\x0a      }\
\x0a      </style>\x0a\
  </defs>\x0a    <p\
ath\x0a       style\
=\x22fill:currentCo\
lor\x22\x0a       d=\x22M\
 13.996094 3.654\
2969 L 6.9960938\
 3.6582031 L 4.5\
546875 10.349609\
 L 3 7.6542969 L\
 2 7.6542969 L 2\
 8.6542969 L 2.4\
277344 8.6542969\
 L 4.5605469 12.\
347656 L 7.58007\
81 4.6542969 L 1\
4.001953 4.65429\
69 L 13.996094 3\
.6542969 z M 9.9\
960938 5.6542969\
 C 8.3340937 5.6\
542969 6.9960938\
 6.9922969 6.996\
0938 8.6542969 C\
 6.9960938 10.31\
6297 8.3340938 1\
1.654297 9.99609\
38 11.654297 C 1\
0.769094 11.6542\
97 11.465094 11.\
355906 11.996094\
 10.878906 L 11.\
996094 11.654297\
 L 12.996094 11.\
654297 L 12.9960\
94 5.6542969 L 1\
1.996094 5.65429\
69 L 11.996094 6\
.4296875 C 11.46\
5094 5.9526875 1\
0.769094 5.65429\
69 9.9960938 5.6\
542969 z M 9.996\
0938 6.6542969 C\
 11.104094 6.654\
2969 11.996094 7\
.5462969 11.9960\
94 8.6542969 C 1\
1.996094 9.76229\
69 11.104094 10.\
654297 9.9960938\
 10.654297 C 8.8\
880937 10.654297\
 7.9960938 9.762\
2969 7.9960938 8\
.6542969 C 7.996\
0938 7.5462969 8\
.8880937 6.65429\
69 9.9960938 6.6\
542969 z \x22\x0a     \
  class=\x22ColorSc\
heme-Text\x22 />\x0a</\
svg>\x0a\
\x00\x00\x02\xbe\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629\x0a      }\
\x0a      </style>\x0a\
  </defs>\x0a    <p\
ath\x0a       style\
=\x22fill:currentCo\
lor\x22\x0a       d=\x22M\
 8 2 A 6 2 0 0 0\
 2 4 L 2 12 A 6 \
2 0 0 0 8 14 A 6\
 2 0 0 0 14 12 L\
 14 4 A 6 2 0 0 \
0 8 2 z M 8 3 A \
5 1 0 0 1 13 4 A\
 5 1 0 0 1 8 5 A\
 5 1 0 0 1 3 4 A\
 5 1 0 0 1 8 3 z\
 M 3 5.1015625 A\
 6 2 0 0 0 8 6 A\
 6 2 0 0 0 13 5.\
1035156 L 13 8 A\
 5 1 0 0 1 8 9 A\
 5 1 0 0 1 3 8 L\
 3 5.1015625 z M\
 3 9.1015625 A 6\
 2 0 0 0 8 10 A \
6 2 0 0 0 13 9.1\
035156 L 13 12 A\
 5 1 0 0 1 8 13 \
A 5 1 0 0 1 3 12\
 L 3 9.1015625 z\
 \x22\x0a       class=\
\x22ColorScheme-Tex\
t\x22 />\x0a</svg>\x0a\
\x00\x00\x01\xd7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22m 2,2 0,11 0,1\
 1,0 11,0 0,-1 -\
1,0 0,-1 -1,0 0,\
-1 0,-1 -1,0 0,1\
 -1,0 0,-1 L 9,1\
0 9,6 8,6 8,3 7,\
3 7,2 6,2 6,4 5,\
4 5,6 4,6 4,9 3,\
9 3,2 Z\x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02\x13\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 2 2 L 2 14 L\
 3 14 L 14 14 L \
14 13 L 13 13 L \
13 11 L 13 8 L 1\
2 8 L 12 6 L 11 \
6 L 11 9 L 10 9 \
L 10 7 L 9 7 L 9\
 5 L 8 5 L 8 2 L\
 7 2 L 7 4 L 6 4\
 L 6 6 L 5 6 L 5\
 7 L 4 7 L 4 8 L\
 3 8 L 3 2 L 2 2\
 z \x22\x0a     class=\
\x22ColorScheme-Tex\
t\x22\x0a     />\x0a</svg\
>\x0a\
\x00\x00\x05\xa7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a  <g\x0a\
     transform=\x22\
translate(-421.7\
1429,-531.79074)\
\x22>\x0a    <g\x0a      \
 transform=\x22matr\
ix(0.75,0,0,0.74\
999813,421.46429\
,-241.22897)\x22>\x0a \
     <path\x0a     \
    style=\x22fill:\
currentColor;fil\
l-opacity:1;stro\
ke:none\x22 \x0a      \
   d=\x22M 8 3 A 8.\
9999925 9.000002\
3 0 0 0 0.123046\
88 7.6679688 C 0\
.2519919 8.03171\
78 0.48048563 8.\
3445725 0.779296\
88 8.5761719 A 7\
.9999935 8.00000\
21 0 0 1 8 4 A 3\
.9999996 4.00000\
04 0 0 0 4 8 A 3\
.9999996 4.00000\
04 0 0 0 8 12 A \
3.9999996 4.0000\
004 0 0 0 12 8 A\
 3.9999996 4.000\
0004 0 0 0 8.349\
6094 4.0175781 A\
 7.9999935 8.000\
0021 0 0 1 15.22\
0703 8.5761719 C\
 15.522218 8.342\
4725 15.752612 8\
.0260772 15.8808\
59 7.6582031 A 8\
.9999925 9.00000\
23 0 0 0 8 3 z M\
 8 5 A 2.9999996\
 3.0000002 0 0 1\
 11 8 A 2.999999\
6 3.0000002 0 0 \
1 8 11 A 2.99999\
96 3.0000002 0 0\
 1 5 8 A 2.99999\
96 3.0000002 0 0\
 1 8 5 z M 8 6 A\
 1.9999999 2.000\
0003 0 0 0 6 8 A\
 1.9999999 2.000\
0003 0 0 0 8 10 \
A 1.9999999 2.00\
00003 0 0 0 10 8\
 A 1.9999999 2.0\
000003 0 0 0 9.9\
101562 7.4121094\
 A 0.9999999 1 0\
 0 1 9 8 A 0.999\
9999 1 0 0 1 8 7\
 A 0.9999999 1 0\
 0 1 8.5898438 6\
.0898438 A 1.999\
9999 2.0000003 0\
 0 0 8 6 z \x22\x0a   \
      transform=\
\x22matrix(1.333333\
3,0,0,1.3333367,\
0.33333333,1030.\
6955)\x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22\x0a         id\
=\x22rect4170\x22 />\x0a \
   </g>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x02\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 14 L 3\
 14 L 4 14 L 10 \
14 L 11 14 L 12 \
14 L 14 14 L 14 \
4.28125 L 11.718\
75 2 L 11.6875 2\
 L 11 2 L 4 2 L \
3 2 L 2 2 z M 3 \
3 L 4 3 L 5 3 L \
5 6 L 5 7 L 11 7\
 L 11 6 L 11 3 L\
 11.28125 3 L 13\
 4.71875 L 13 5 \
L 13 13 L 12 13 \
L 12 9 L 11 9 L \
5 9 L 3.96875 9 \
L 3.96875 13 L 3\
 13 L 3 3 z M 6 \
3 L 7.90625 3 L \
7.90625 6 L 6 6 \
L 6 3 z M 5 10 L\
 6 10 L 10 10 L \
11 10 L 11 13 L \
10 13 L 6 13 L 5\
 13 L 5 10 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02y\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 16 16\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <style i\
d=\x22current-color\
-scheme\x22 type=\x22t\
ext/css\x22>.ColorS\
cheme-Text {\x0a   \
         color:#\
232629;\x0a        \
}</style>\x0a    <p\
ath id=\x22path4\x22 c\
lass=\x22ColorSchem\
e-Text\x22 d=\x22m7.5 \
2-3.5 3.5 3.5 3.\
5 0.71875-0.7187\
5-2.3125-2.28125\
h3.59375c1.93299\
8 0 3.5 1.566998\
4 3.5 3.5 0 1.93\
3002-1.567002 3.\
5-3.5 3.5h-1.5v1\
h1.5c2.485283 0 \
4.5-2.014748 4.5\
-4.5 0-2.4852521\
-2.014717-4.5-4.\
5-4.5h-3.59375l2\
.3125-2.28125z\x22 \
fill=\x22currentCol\
or\x22/>\x0a    <rect \
id=\x22rect837\x22 cla\
ss=\x22ColorScheme-\
Text\x22 x=\x222\x22 y=\x222\
\x22 width=\x221\x22 heig\
ht=\x227\x22 fill=\x22cur\
rentColor\x22 fill-\
rule=\x22evenodd\x22/>\
\x0a</svg>\x0a\
\x00\x00\x01i\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 3,7 3,9 13,9 1\
3,7 3,7 Z\x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02\x16\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
2 L 6 12 L 6 14 \
L 14 14 L 14 7 L\
 11 4 L 10 4 L 8\
 2 L 3 2 Z M 4 3\
 L 7 3 L 7 4 L 6\
 4 L 6 11 L 4 11\
 L 4 3 Z M 7 5 L\
 10 5 L 10 8 L 1\
3 8 L 13 13 L 7 \
13 L 7 5 Z\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\x0e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 3 2 L 3 \
14 L 6 14 L 6 13\
 L 4 13 L 4 3 L \
9 3 L 9 6 L 12 6\
 L 12 8 L 13 8 L\
 13 5 L 10 2 L 9\
 2 L 3 2 z M 7 8\
 L 7 14 L 13 14 \
L 13 9 L 11 9 L \
10 8 L 7 8 z M 8\
 10 L 12 10 L 12\
 13 L 8 13 L 8 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22/>\x0a</svg>\x0a\
\x00\x00\x06\xa9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 5 2 C 4.567 2.\
75 4.34825 2.75 \
4.78125 3.5 L 7.\
40625 8 L 5.9062\
5 10.21875 C 5.6\
3425 10.08075 5.\
325 10 5 10 C 3.\
895 10 3 10.895 \
3 12 C 3 13.105 \
3.895 14 5 14 C \
6.105 14 7 13.10\
5 7 12 C 7 11.59\
5 6.86325 11.221\
25 6.65625 10.90\
625 C 6.65125 10\
.89825 6.66125 1\
0.882 6.65625 10\
.875 L 7.09375 1\
0.25 C 7.89575 1\
0.225 8.008 9.65\
725 8.5 9.65625 \
C 8.511 9.65625 \
8.52025 9.65525 \
8.53125 9.65625 \
L 8.5625 9.71875\
 L 9.34375 10.87\
5 L 9.34375 10.9\
0625 C 9.13775 1\
1.22125 8.998046\
9 11.595 8.99804\
69 12 C 8.998046\
9 13.105 9.89304\
69 14 10.998047 \
14 C 12.103047 1\
4 12.998047 13.1\
05 12.998047 12 \
C 12.998047 10.8\
95 12.103047 10 \
10.998047 10 C 1\
0.673047 10 10.3\
6475 10.08075 10\
.09375 10.21875 \
L 8.59375 8 C 8.\
59375 8 11.22875\
 3.492 11.21875 \
3.5 C 11.65175 2\
.75 11.431047 2.\
75 10.998047 2 L\
 7.9980469 7.125\
 L 5 2 z M 7.998\
0469 8 L 8 8 C 8\
.276 8 8.5 8.224\
 8.5 8.5 C 8.5 8\
.754 8.3075 8.96\
8 8.0625 9 L 7.9\
375 9 C 7.6925 8\
.968 7.4980469 8\
.754 7.4980469 8\
.5 C 7.4980469 8\
.224 7.7220469 8\
 7.9980469 8 z M\
 4.9980469 11 C \
5.5500469 11 5.9\
980469 11.448 5.\
9980469 12 C 5.9\
980469 12.552 5.\
5500469 13 4.998\
0469 13 C 4.4460\
469 13 3.9980469\
 12.552 3.998046\
9 12 C 3.9980469\
 11.448 4.446046\
9 11 4.9980469 1\
1 z M 10.998047 \
11 C 11.550047 1\
1 11.998047 11.4\
48 11.998047 12 \
C 11.998047 12.5\
52 11.550047 13 \
10.998047 13 C 1\
0.446047 13 9.99\
80469 12.552 9.9\
980469 12 C 9.99\
80469 11.448 10.\
446047 11 10.998\
047 11 z \x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02?\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 3 2 L 2 3 L \
2 4 L 2 4.3125 L\
 6 9.96875 L 6 1\
0 L 6 12 L 10 14\
 L 10 10 L 10 9.\
96875 L 14 4.312\
5 L 14 3 L 13 2 \
L 9 2 L 7.25 2 L\
 3 2 z M 3 3 L 7\
.25 3 L 9 3 L 13\
 3 L 13 4 L 9 9.\
625 L 9 10 L 9 1\
1 L 9 12 L 7 11 \
L 7 10 L 7 9.625\
 L 3 4 L 3 3 z \x22\
\x0a     class=\x22Col\
orScheme-Text\x22\x0a \
    />\x0a</svg>\x0a\
\x00\x00\x03\xc7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 13 L 2\
 14 L 3 14 L 14 \
14 L 14 13 L 3 1\
3 L 3 2 L 2 2 z \
M 4 2 L 4 3 L 5 \
3 L 5 2 L 4 2 z \
M 6 2 L 6 3 L 7 \
3 L 7 2 L 6 2 z \
M 12 3 L 12 4 L \
13 4 L 13 3 L 12\
 3 z M 13 4 L 13\
 5 L 14 5 L 14 4\
 L 13 4 z M 13 5\
 L 12 5 L 12 6 L\
 13 6 L 13 5 z M\
 12 5 L 12 4 L 1\
1 4 L 11 5 L 12 \
5 z M 4 4 L 4 5 \
L 5 5 L 5 4 L 4 \
4 z M 6 4 L 6 5 \
L 7 5 L 7 4 L 6 \
4 z M 9 7 L 9 8 \
L 10 8 L 10 7 L \
9 7 z M 11 7 L 1\
1 8 L 12 8 L 12 \
7 L 11 7 z M 5 9\
 L 5 10 L 6 10 L\
 6 9 L 5 9 z M 6\
 10 L 6 11 L 7 1\
1 L 7 10 L 6 10 \
z M 6 11 L 5 11 \
L 5 12 L 6 12 L \
6 11 z M 5 11 L \
5 10 L 4 10 L 4 \
11 L 5 11 z M 9 \
9 L 9 10 L 10 10\
 L 10 9 L 9 9 z \
M 11 9 L 11 10 L\
 12 10 L 12 9 L \
11 9 z \x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 5 2 L 5 3 L \
3 3 L 3 14 L 7 1\
4 L 8 14 L 12 14\
 L 13 14 L 13 13\
 L 13 9 L 13 3 L\
 11 3 L 11 2 L 5\
 2 z M 4 4 L 5 4\
 L 5 5 L 11 5 L \
11 4 L 12 4 L 12\
 6 L 12 12 L 12 \
13 L 8 13 L 7 13\
 L 4 13 L 4 12 L\
 4 6 L 4 4 z M 5\
 7 L 5 8 L 10 8 \
L 10 7 L 5 7 z M\
 5 10 L 5 11 L 8\
 11 L 8 10 L 5 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22\x0a     />\x0a</sv\
g>\x0a\
\x00\x00\x02S\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 7 12 L 11\
.0859 12 L 9.464\
84 13.6211 L 10.\
1719 14.3281 L 1\
3 11.5 L 10.1719\
 8.67187 L 9.464\
84 9.37891 L 11.\
0859 11 L 7 11 L\
 7 12 Z M 4 13 L\
 4 3 L 9 3 L 9 6\
 L 12 6 L 12 9 L\
 13 9 L 13 5 L 1\
0 2 L 3 2 L 3 14\
 L 8 14 L 8 13 L\
 4 13 Z\x22/>\x0a</svg\
>\x0a\
\x00\x00\x02]\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 6 2 L 6 3 L 6 \
6 L 7 6 L 7 3 L \
9 3 L 9 6 L 10 6\
 L 10 3 L 10 2 L\
 9 2 L 7 2 L 6 2\
 z M 3.8046875 6\
 L 3 6.8320312 L\
 8 12 L 13 6.832\
0312 L 12.195312\
 6 L 8 10.337891\
 L 3.8046875 6 z\
 M 2 12 L 2 14 L\
 3 14 L 13 14 L \
14 14 L 14 13 L \
14 12 L 13 12 L \
13 13 L 3 13 L 3\
 12 L 2 12 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02\x16\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
2 L 6 12 L 6 14 \
L 14 14 L 14 7 L\
 11 4 L 10 4 L 8\
 2 L 3 2 Z M 4 3\
 L 7 3 L 7 4 L 6\
 4 L 6 11 L 4 11\
 L 4 3 Z M 7 5 L\
 10 5 L 10 8 L 1\
3 8 L 13 13 L 7 \
13 L 7 5 Z\x22/>\x0a</\
svg>\x0a\
\x00\x00\x01\xee\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <s\
tyle id=\x22current\
-color-scheme\x22 t\
ype=\x22text/css\x22>\x0a\
        .ColorSc\
heme-Text {\x0a    \
        color:#2\
32629;\x0a        }\
\x0a    </style>\x0a  \
  <path class=\x22C\
olorScheme-Text\x22\
 d=\x22m6.3828 2-4.\
3828 11h1.3574l1\
.1895-3h6.3262l-\
3.1875-8h-1.3027\
zm0.62305 1.3281\
 2.1211 5.6719h-\
4.1855l2.0645-5.\
6719zm7.6836 5.4\
355-3.3574 3.779\
3-1.625-1.625-0.\
70703 0.70703 2.\
375 2.375 4.0234\
-4.5273-0.70898-\
0.70898z\x22 style=\
\x22fill:currentCol\
or\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xea\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 7 3.0058594 L \
7 8 L 2 8 L 2 8.\
9980469 L 7 8.99\
80469 L 7 14.007\
812 L 8 14.00781\
2 L 8 8.9980469 \
L 13 8.9980469 L\
 13 8 L 8 8 L 8 \
3.0058594 L 7 3.\
0058594 z \x22\x0a    \
 class=\x22ColorSch\
eme-Text\x22\x0a     /\
>\x0a</svg>\x0a\
\x00\x00\x01R\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a       style=\
\x22fill:#da4453\x22\x0a \
      d=\x22m 7,2 0\
,8 2,0 0,-8 -2,0\
 z m 0,10 0,2 2,\
0 0,-2 -2,0 z\x22 \x0a\
       />\x0a</svg>\
\x0a\
\x00\x00\x04\xf7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 7.5 3 C 5.5\
67 3 4 4.7909 4 \
7 L 4 8 L 4 10 C\
 4 12.2091 5.567\
 14 7.5 14 C 9.4\
33 14 11 12.2091\
 11 10 L 11 8 L \
11 7 C 11 4.7909\
 9.433 3 7.5 3 z\
 M 15.5 3 C 13.5\
67 3 12 4.7909 1\
2 7 L 12 8 L 12 \
10 C 12 12.2091 \
13.567 14 15.5 1\
4 C 17.433 14 19\
 12.2091 19 10 L\
 19 8 L 19 7 C 1\
9 4.7909 17.433 \
3 15.5 3 z M 7.5\
 4 C 8.88071 4 1\
0 5.3432 10 7 L \
10 10 C 10 11.65\
69 8.88071 13 7.\
5 13 C 6.11929 1\
3 5 11.6569 5 10\
 L 5 7 C 5 5.343\
2 6.11929 4 7.5 \
4 z M 15.5 4 C 1\
6.88071 4 18 5.3\
431 18 7 L 18 10\
 C 18 11.6569 16\
.88071 13 15.5 1\
3 C 14.11929 13 \
13 11.6569 13 10\
 L 13 7 C 13 5.3\
431 14.11929 4 1\
5.5 4 z M 3 13 L\
 3 14 L 4 14 L 4\
 13 L 3 13 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a    <p\
ath style=\x22fill:\
currentColor;fil\
l-opacity:1;stro\
ke:none\x22 d=\x22M 15\
 15 L 15 17 L 13\
 17 L 13 18 L 15\
 18 L 15 20 L 16\
 20 L 16 18 L 18\
 18 L 18 17 L 16\
 17 L 16 15 L 15\
 15 z \x22 class=\x22C\
olorScheme-Highl\
ight\x22/>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x03\x08\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 9 3 C 7.3\
4315 3 6 4.3431 \
6 6 L 6 8 L 4 8 \
L 4 9 L 6 9 L 6 \
10 L 6 19 L 7 19\
 L 7 9 L 8 9 L 9\
 9 L 9 8 L 8 8 L\
 7 8 L 7 6 C 7 4\
.89543 7.89543 4\
 9 4 L 10 4 L 10\
 3 L 9 3 z M 12.\
742188 13 L 12 1\
3.732422 L 14.29\
2969 16 L 12 18.\
267578 L 12.7421\
88 19 L 15.03515\
6 16.732422 L 17\
.257812 18.93164\
1 L 18 18.199219\
 L 15.775391 16 \
L 18 13.800781 L\
 17.257812 13.06\
8359 L 15.035156\
 15.267578 L 12.\
742188 13 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x02\xa6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <defs>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
            .Col\
orScheme-Text {\x0a\
                \
color:#232629;\x0a \
           }\x0a   \
     </style>\x0a  \
</defs>\x0a  <g tra\
nsform=\x22translat\
e(1,1)\x22>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 d=\x22m14 1\
1c-2.215995 0-4 \
1.784005-4 4s1.7\
84005 4 4 4 4-1.\
784005 4-4-1.784\
005-4-4-4m0 1c1.\
661995 0 3 1.338\
005 3 3s-1.33800\
5 3-3 3-3-1.3380\
05-3-3 1.338005-\
3 3-3m-1 1v3h2v-\
1h-1v-2h-1m-9-10\
v16h6v-1h-5v-14h\
8v4h4v3h1v-4.007\
8125l-3.992188-3\
.9921875-0.00781\
2 0.0097656v-0.0\
097656h-9z\x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x02\xab\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 3 C 6.\
568 3 3 6.568 3 \
11 C 3 15.432 6.\
568 19 11 19 C 1\
5.432 19 19 15.4\
32 19 11 C 19 6.\
568 15.432 3 11 \
3 z M 11 4 C 14.\
878 4 18 7.122 1\
8 11 C 18 14.878\
 14.878 18 11 18\
 C 7.122 18 4 14\
.878 4 11 C 4 7.\
122 7.122 4 11 4\
 z M 10 6 L 10 8\
 L 12 8 L 12 6 L\
 10 6 z M 10 9 L\
 10 16 L 12 16 L\
 12 9 L 10 9 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x06{\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
5 L 4 16 L 4 17 \
L 3 17 L 3 18 L \
4 18 L 4 19 L 5 \
19 L 5 18 L 19 1\
8 L 19 17 L 5 17\
 L 5 16 L 5.0078\
125 16 L 6 16 L \
8 16 L 8 15.9921\
88 L 8.0078125 1\
6 L 10.007812 14\
 L 11.599609 14 \
L 13.599609 16 L\
 17.099609 16 L \
19 16 L 19 15 L \
17.099609 15 L 1\
4.013672 15 L 12\
.013672 13 L 12 \
13 L 11.007812 1\
3 L 10.599609 13\
 L 9.59375 13 L \
7.59375 15 L 6 1\
5 L 5.0078125 15\
 L 5 15 L 5 11 L\
 10 11 L 10 10.9\
92188 L 10.00781\
2 11 L 11.003906\
 10.003906 L 11 \
10 L 10.296875 9\
.296875 L 9.5937\
5 10 L 5 10 L 5 \
3 L 4 3 z M 11 1\
0 L 13 10 L 13 9\
 L 12 9 L 12 8 L\
 11 8 L 11 10 z \
M 11 4 L 11 6 L \
12 6 L 12 5 L 13\
 5 L 13 4 L 11 4\
 z M 15 4 L 15 5\
 L 16 5 L 16 6 L\
 17 6 L 17 4 L 1\
5 4 z M 14 5.593\
75 L 13.292969 6\
.3007812 L 12.29\
6875 7.296875 L \
13.003906 8.0039\
062 L 14 7.00781\
25 L 14.996094 8\
.0039062 L 15.70\
3125 7.296875 L \
14 5.59375 z M 1\
6 8 L 16 9 L 15 \
9 L 15 10 L 17 1\
0 L 17 8 L 16 8 \
z M 19 8 L 18 9 \
L 19 9 L 19 8 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a   \
 <path style=\x22fi\
ll:currentColor;\
fill-opacity:0.5\
;stroke:none\x22 d=\
\x22M 14 7 L 12.003\
906 9 L 13 9 L 1\
3 10 L 11.005859\
 10 L 10.007812 \
11 L 5 11 L 5 15\
 L 7.5996094 15 \
L 9.5996094 13 L\
 12.007812 13 L \
14 14.992188 L 1\
9 15 L 19 9 L 17\
 9 L 17 10 L 15 \
10 L 15 9 L 16 9\
 L 14 7 z M 10 1\
4 L 8 16 L 5 16 \
L 5 17 L 19 17 L\
 19 16 L 13.5996\
09 16 L 11.59960\
9 14 L 10 14 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02\x14\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <style type\
=\x22text/css\x22 id=\x22\
current-color-sc\
heme\x22>\x0a        .\
ColorScheme-Nega\
tiveText {\x0a     \
       color:#da\
4453;\x0a        }\x0a\
    </style>\x0a  <\
g transform=\x22tra\
nslate(1,1)\x22>\x0a  \
  <path d=\x22M11 3\
a8 8 0 0 0-8 8 8\
 8 0 0 0 8 8 8 8\
 0 0 0 8-8 8 8 0\
 0 0-8-8M7.707 7\
L11 10.294l3.293\
-3.293.707.707-3\
.293 3.293L15 14\
.294l-.707.707L1\
1 11.708l-3.293 \
3.293L7 14.294l3\
.293-3.293L7 7.7\
08l.707-.707\x22 cl\
ass=\x22ColorScheme\
-NegativeText\x22 f\
ill=\x22currentColo\
r\x22/>\x0a  </g>\x0a</sv\
g>\x0a\
\x00\x00\x03H\
(\
\xb5/\xfd`\x1c\x0e\xf5\x19\x00\xc6\xa4l# m\xf5\
\xc9\x0f\xdd@\xe5\x13\xea\xf7\xc9\x0fM\x00L\xe1\xbb\x5c\
\x94{$\x9c|\x92\x92\xaekp\xa2\x05\x08\x87`\x11\
h\x00b\x00^\x00\x14\xb1\x1d\xb1\x9f9\xbevrc\
7^\x9f\xf3\xc5w\xdf\xe8?\x969\xb0\xe6\x91\x96\x0d\
p\x80\xc0TM\xb0f\x9a$h\x1d\x97\x13\xb1\xa0\xfa\
0\xbb\x00\x06\x97#\x92\xaa\x835\x8e\xeb\x91$\xcb\x16\
_^f\xcd\x84B\x90T\x89b\x992\xe7l\x09\x88\
4M\x0a\x98\xc2\xcc\xaeD\x15\xe5\x9e\xc4I$\x12E\
)\x88\x5c\x97\x835\x16dzL6\xa2\xb0\x98\xac0\
\xaf)\xf4~\xa6\xff@\xc9P\x84\x0f\x85\x1e\xe6\xfd\x1c\
W\x0b\x82(\x851S\xda4\x805\x155Q\xb4m\
\x84\xba\xacjE@\x1e*u\x22\x10U\xb5\xacK\x82\
DD\xcf.\xa1[|\x99\xcc\xe7\xef\x9eC\xd6t\xc5\
\xb2wA\xaa\xf48UC\xe5\xd4\xd6\x1a\xa3[\xb7\xd8\
\xcbK\x7fJ7\x1f\xdc\xb7\xb4\x84\xeeyY<\x85\x05\
\xdem\xffI\xe7m\xe5\xf2\xf2\xc6\xff\xc5]\x0bL\xa4\
\xear\x1e\x03M\xd0\x02\xf5r&\xd6<*\x0a\xb2 \
Num\xc4(Le\x7f\xb1\xd6\xe6\xf7\x95zmY\
\xe9R;\xc2\x86\xd5\xe7k\x87B\xd0/\x0e|\xcf\x9b\
\x8d\x96\x0e?\xads\xd2\xda\x90\xec\x0d\xfa|s\xd3\x97\
\x8ewC\xc2'\xd2\x7f\xfa\x91\xf2\xfb\xab/\x1e\x00\x06\
\x11\x85\xa50\x0d\x0c\x8b\x05\x86\x82t7\xfd\xf7\xd9\xb5\
l\x87\xd1I)\xb7'toq\xee\xedn\xbb\xbc\xbf\
;\x86/\x01aq\xc0\x98U\xbd\x96w\xfd\xde9\xec\
\xb6\xb0\x8aK\xa2\x22\x85\xf9\x85\xdc\x95\xec\x91\xa1\xb89\
\x97\xfd\xb7\x0d[D\x9a(T+G\xc1~tq\xca\
}\xb1\xb5}\xf0q;^\xf9\xe2;t\xf3\x03\x80\xb0\
\xa0\x11Mf\xa40hA\x92B\x961pFH\xa6\
\xc8\xe4\x01r\x86\xcf\xf8\xb0\x9eX\x13\xfb\x80\xef\x06o\
\x89M\xf3\xdaf\xd9G\x10\xd3fu\x96D_\x8c!\
w\x82\xac\x1b\x91\x97\x13\xc6\x02\x0e\xd4=R4\x84`\
\x0a\x86\x8a\x82\xa0#?`\x80_\x01\x8e\xf7y\xb2\xf6\
\xf6\x88\xd2\xa9\x8a\x22K(\xb6e\x90c\x8c\x22\xb3\x22\
B\xc8$\xae}?)[\xe0\x9c\x15Yu\xb9o\xd4\
+\x08u\x8f\xc2\xbb\xe3\xe8y\x0a\xc7\x5c\xa6\x95?\x22\
\x06V\x0d\x09}\xcb\x84\x8a0p\xd0\x1e\x96\xe0\x12\x13\
\xfdB\xd3\xda\x0e\x16\x1cEL7\xc2k\xc4\x06\x18<\
\x08|\x0e\x9b\x03\x97Y\x93\xe9\x1a\xc0\x96\x09\xd9*g\
\xcf\x07\xa6\xbc\x0cys\x03\xb4\x0e\xe0\xf1(PV\xc9\
\xbb\x95\xd6C\x0b0\xf5\x81\x8f\xeb:: )\x19@\
\x1e\xd4\xb6\x00&\x22P\x22\xa7\x03\x16\x06\xd6\xc1\x1d\xf5\
\x86m\xc4\xa7\xa2\xd7\xdb-1\xd5\x1b\x98m\x09\xd84\
jr\x15`\x9a\xe5\x18E\x04\x18\xf8\x22\x04-&\xc0\
t\x9a\xfb4G\xcaT\xaf\xbc\xcdHW\x82\x99\x16&\
\xb59\xb0\x90\x98d\x92=\x0c\xb9e\x0c?\x80\x16\x1b\
\xa7\x22\x19^\xa3\xc89h*\xe4\xceE\x19\x12\x02\xb3\
\xaa\xbc\xb8\x0a\xe4\xcd\x84P\xb6k\x19\xf8\xecr\xd3@\
\xc1\x09k\x05\xb0?\xc0$\x00\x81\x066\x17\xa6\xcc\x17\
J\x06D*\x8e7\x16\x1d\x80\xbb\x87\x0e\x90w\xe0\x87\
\xf90 `\xf2\x8d\x96=\x955k(\xfb\x03\x1f\x00\
\xbac\x80\x02\x9a\x0f\xbd\xcf\xd8X}\x11(\xecu&\
4#\x18\xb7\x02\x88*\
\x00\x00\x03\xb9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11.5 3 C \
10.286139 3 9.28\
09778 3.8559279 \
9.0507812 5 L 3 \
5 L 3 6 L 9.0507\
812 6 C 9.280977\
8 7.1440721 10.2\
86139 8 11.5 8 C\
 12.713861 8 13.\
719022 7.1440721\
 13.949219 6 L 1\
9 6 L 19 5 L 13.\
949219 5 C 13.71\
9022 3.8559279 1\
2.713861 3 11.5 \
3 z M 5.5 14 C 4\
.1149999 14 3 15\
.115 3 16.5 C 3 \
17.885 4.1149999\
 19 5.5 19 C 6.7\
138604 19 7.7190\
223 18.144072 7.\
9492188 17 L 19 \
17 L 19 16 L 7.9\
492188 16 C 7.71\
90223 14.855928 \
6.7138604 14 5.5\
 14 z M 5.5 15 C\
 6.3310001 15 7 \
15.669 7 16.5 C \
7 17.331 6.33100\
01 18 5.5 18 C 4\
.6689999 18 4 17\
.331 4 16.5 C 4 \
15.669 4.6689999\
 15 5.5 15 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02G\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 3 C 6.\
6 3 3 6.6 3 11 C\
 3 15.4 6.6 19 1\
1 19 C 15.4 19 1\
9 15.4 19 11 C 1\
9 6.6 15.4 3 11 \
3 z M 11 4 L 11 \
11 L 18 11 L 18 \
11 C 18 14.9 14.\
9 18 11 18 C 7.1\
22 18 4 14.9 4 1\
1 C 4 7.122 7.12\
2 4 11 4 z \x22 cla\
ss=\x22ColorScheme-\
Text\x22/>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x02x\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 5\
 L 5 5 L 5 4 L 1\
7 4 L 17 5 L 18 \
5 L 18 3 L 17 3 \
L 5 3 L 4 3 z M \
11 5 L 5 11.1835\
94 L 5.7929688 1\
2 L 11 6.6328125\
 L 16.207031 12 \
L 17 11.183594 L\
 11 5 z M 8 13 L\
 8 19 L 9 19 L 1\
3 19 L 14 19 L 1\
4 13 L 13 13 L 1\
3 18 L 9 18 L 9 \
13 L 8 13 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x04\xcc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 17.564453\
 2.7558594 L 14.\
298828 8.5742188\
 L 11.882812 7.1\
386719 L 10.8613\
28 8.8574219 L 1\
6.511719 12.2167\
97 L 17.533203 1\
0.496094 L 15.15\
8203 9.0839844 L\
 18.435547 3.244\
1406 L 17.564453\
 2.7558594 z M 7\
 6 A 1 1 0 0 0 6\
 7 A 1 1 0 0 0 7\
 8 A 1 1 0 0 0 8\
 7 A 1 1 0 0 0 7\
 6 z M 3.5 7 A 0\
.5 0.5 0 0 0 3 7\
.5 A 0.5 0.5 0 0\
 0 3.5 8 A 0.5 0\
.5 0 0 0 4 7.5 A\
 0.5 0.5 0 0 0 3\
.5 7 z M 5 9 A 1\
 1 0 0 0 4 10 A \
1 1 0 0 0 5 11 A\
 1 1 0 0 0 6 10 \
A 1 1 0 0 0 5 9 \
z M 10 10 C 8.88\
15125 11.564268 \
6.8355055 12.810\
894 3 13 L 3 14 \
C 5.1137135 17.3\
71692 8 19 12 19\
 L 13 19 C 14.31\
1249 17.412805 1\
5.357513 15.9676\
19 16 14 L 16 13\
 L 11 10 L 10 10\
 z M 10.529297 1\
1.101562 L 14.85\
7422 13.699219 C\
 14.284594 15.24\
586 13.385404 16\
.602833 12.27343\
8 17.96875 C 8.9\
999995 18 6.0527\
68 16.540538 4.3\
261719 13.830078\
 C 7.4443879 13.\
51946 9.3457156 \
12.545306 10.529\
297 11.101562 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x05Z\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 18.292969\
 3 L 3 18.292969\
 L 3.7070312 19 \
L 19 3.7070312 L\
 18.292969 3 z M\
 11 6 A 10 9.999\
9781 0 0 0 2.287\
1094 11.119141 C\
 2.4663699 11.42\
0241 2.7209984 1\
1.668644 3.02734\
38 11.839844 A 9\
 8.99998 0 0 1 1\
1 7 A 4 4 0 0 0 \
7 11 A 4 4 0 0 0\
 7.3574219 12.64\
2578 L 8.1308594\
 11.869141 A 3 3\
 0 0 1 8 11 A 3 \
3 0 0 1 11 8 A 3\
 3 0 0 1 11.8691\
41 8.1308594 L 1\
2.640625 7.35937\
5 A 4 4 0 0 0 11\
.34375 7.0175781\
 A 9 8.99998 0 0\
 1 12.796875 7.2\
03125 L 13.64062\
5 6.359375 A 10 \
9.9999781 0 0 0 \
11 6 z M 16.4042\
97 7.5957031 L 1\
5.675781 8.32421\
88 A 9 8.99998 0\
 0 1 18.974609 1\
1.837891 C 19.28\
2742 11.665091 1\
9.539718 11.4154\
28 19.71875 11.1\
11328 A 10 9.999\
9781 0 0 0 16.40\
4297 7.5957031 z\
 M 11 9 A 2 2 0 \
0 0 9 11 L 11 9 \
z M 14.642578 9.\
3574219 L 13.869\
141 10.130859 A \
3 3 0 0 1 14 11 \
A 3 3 0 0 1 11 1\
4 A 3 3 0 0 1 10\
.130859 13.86914\
1 L 9.3574219 14\
.642578 A 4 4 0 \
0 0 11 15 A 4 4 \
0 0 0 15 11 A 4 \
4 0 0 0 14.64257\
8 9.3574219 z M \
13 11 L 11 13 A \
2 2 0 0 0 13 11 \
z M 1 13 C 0.333\
33333 19 0.66666\
667 16 1 13 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xfa\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 3 L 3 4\
 L 3 19 L 4 19 L\
 15 19 L 12 16 L\
 15 13 L 17 13 L\
 16 12 L 14 10 L\
 10 14 L 9 13 L \
4.1484375 17.851\
562 L 4 18 L 4 4\
 L 18 4 L 18 12 \
L 19 12 L 19 4 L\
 19 3 L 4 3 L 3 \
3 z M 7 5 C 5.89\
2 5 5 5.892 5 7 \
C 5 8.108 5.892 \
9 7 9 C 8.108 9 \
9 8.108 9 7 C 9 \
5.892 8.108 5 7 \
5 z M 16 14 L 16\
 16 L 14 16 L 14\
 17 L 16 17 L 16\
 19 L 17 19 L 17\
 17 L 19 17 L 19\
 16 L 17 16 L 17\
 14 L 16 14 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xb6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 3 L 3 4\
 L 3 6 L 4 6 L 4\
 4 L 6 4 L 6 3 L\
 4 3 L 3 3 z M 1\
6 3 L 16 4 L 18 \
4 L 18 6 L 19 6 \
L 19 4 L 19 3 L \
18 3 L 16 3 z M \
5 5 L 5 17 L 17 \
17 L 17 5 L 5 5 \
z M 6 6 L 16 6 L\
 16 16 L 6 16 L \
6 6 z M 3 16 L 3\
 18 L 3 19 L 6 1\
9 L 6 18 L 4 18 \
L 4 16 L 3 16 z \
M 18 16 L 18 18 \
L 16 18 L 16 19 \
L 19 19 L 19 16 \
L 18 16 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x02\x05\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22opacity:1;fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 d=\x22M\
 3,4 3,16 6,20 6\
,17 6,16 19,16 1\
9,4 3,4 Z M 4,5 \
18,5 18,15 4,15 \
4,5 Z m 6,1 0,1 \
2,0 0,-1 -2,0 z \
m 0,2 0,6 2,0 0,\
-6 -2,0 z\x22 class\
=\x22ColorScheme-Te\
xt\x22/>\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x04\xc8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 2 2.99804\
69 L 2 3 L 2 4 L\
 2 19 L 3 19 L 1\
1 19 L 11 18 L 6\
 18 L 6 12 L 11 \
12 L 11 11 L 6 1\
1 L 5 11 L 5 18 \
L 3 18 L 3 4 L 6\
 4 L 6 8 L 6 9 L\
 14 9 L 14 8 L 1\
4 4 L 14.292969 \
4 L 17 6.7070312\
 L 17 7 L 17 10 \
L 18 10 L 18 7 L\
 18 6.3007812 L \
17.992188 6.3007\
812 L 18 6.29101\
56 L 14.707031 2\
.9980469 L 14.69\
9219 3.0078125 L\
 14.699219 2.998\
0469 L 14 2.9980\
469 L 2 2.998046\
9 z M 7 4 L 10.9\
00391 4 L 10.900\
391 8 L 7 8 L 7 \
4 z M 18 11 L 17\
.003906 11.99414\
1 L 17 11.994141\
 L 12 16.992188 \
L 12.007812 17.0\
01953 L 12.00390\
6 18.005859 L 12\
 18.005859 L 12 \
18.996094 L 12 1\
9.005859 L 14 19\
.005859 L 14.005\
859 18.996094 L \
14.009766 18.996\
094 L 14.019531 \
18.996094 L 14.0\
13672 18.986328 \
L 15 18 L 19 14.\
003906 L 18.2949\
22 13.294922 L 1\
3.304688 18.2812\
5 L 12.710938 17\
.689453 L 17.703\
125 12.701172 L \
18.294922 13.294\
922 L 19 13.9980\
47 L 20 12.99804\
7 L 18 11 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x03J\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:currentC\
olor\x22 d=\x22M 19 5 \
L 9.6679688 5.00\
58594 L 6.5 14.5\
 L 4.3339844 11 \
L 3 11 L 3 12 L \
4 12 L 6.5 17 L \
10.441406 6 L 19\
 6 L 19 5 z M 14\
 8 C 11.790861 8\
 10 9.790861 10 \
12 C 10 14.20913\
9 11.790861 16 1\
4 16 C 15.149118\
 15.9982 16.2419\
64 15.502302 17 \
14.638672 L 17 1\
6 L 18 16 L 18 1\
2 L 18 8 L 17 8 \
L 17 9.3613281 C\
 16.241964 8.497\
6979 15.149118 8\
.0017906 14 8 z \
M 14 9 C 15.6568\
54 9 17 10.34314\
6 17 12 C 17 13.\
656854 15.656854\
 15 14 15 C 12.3\
43146 15 11 13.6\
56854 11 12 C 11\
 10.343146 12.34\
3146 9 14 9 z \x22 \
class=\x22ColorSche\
me-Text\x22/>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02\xdb\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:currentC\
olor\x22 d=\x22M 11 3 \
A 8 3 0 0 0 3 6 \
L 3 16 A 8 3 0 0\
 0 11 19 A 8 3 0\
 0 0 19 16 L 19 \
6 A 8 3 0 0 0 11\
 3 z M 11 4 A 7 \
2 0 0 1 18 6 A 7\
 2 0 0 1 11 8 A \
7 2 0 0 1 4 6 A \
7 2 0 0 1 11 4 z\
 M 18 7.45 L 18 \
11 A 7 2 0 0 1 1\
1 13 A 7 2 0 0 1\
 4 11 L 4 7.45 A\
 8 3 0 0 0 11 9 \
A 8 3 0 0 0 18 7\
.45 z M 18 12.45\
 L 18 16 A 7 2 0\
 0 1 11 18 A 7 2\
 0 0 1 4 16 L 4 \
12.45 A 8 3 0 0 \
0 11 14 A 8 3 0 \
0 0 18 12.45 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02\x8d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 18\
 17 L 18 16 L 17\
 16 L 16 16 L 16\
 15 L 15 15 L 14\
 15 L 14 14 L 13\
 14 L 13 15 L 12\
 15 L 12 14 L 11\
 14 L 11 7 L 10 \
7 L 10 3 L 9 3 L\
 9 5 L 8 5 L 8 8\
 L 7 8 L 7 10 L \
6 10 L 6 13 L 5 \
13 L 5 3 L 4 3 z\
 \x22 class=\x22ColorS\
cheme-Text\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x02\x98\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 6 \
18 L 19 18 L 19 \
17 L 19 8 L 18 8\
 L 18 9 L 17 9 L\
 17 8 L 16 8 L 1\
6 7 L 15 7 L 15 \
8 L 14 8 L 14 6 \
L 13 6 L 13 9 L \
12 9 L 12 7 L 11\
 7 L 11 5 L 10 5\
 L 10 3 L 9 3 L \
9 4 L 8 4 L 8 5 \
L 7 5 L 7 6 L 6 \
6 L 6 7 L 5 7 L \
5 3 L 4 3 z \x22 cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x04V\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 11 6 A 10\
 9.999975 0 0 0 \
2.3144531 11.070\
312 C 2.4995621 \
11.361743 2.7600\
802 11.597238 3.\
0664062 11.75976\
6 A 9 8.999978 0\
 0 1 11 7 A 4 4 \
0 0 0 7 11 A 4 4\
 0 0 0 11 15 A 4\
 4 0 0 0 15 11 A\
 4 4 0 0 0 11.34\
375 7.0175781 A \
9 8.999978 0 0 1\
 18.931641 11.76\
1719 C 19.241063\
 11.598077 19.50\
3624 11.359298 1\
9.689453 11.0644\
53 A 10 9.999975\
 0 0 0 11 6 z M \
11 8 A 3 3 0 0 1\
 14 11 A 3 3 0 0\
 1 11 14 A 3 3 0\
 0 1 8 11 A 3 3 \
0 0 1 11 8 z M 1\
1 9 C 9.892 9 9 \
9.892 9 11 C 9 1\
2.108 9.892 13 1\
1 13 C 12.108 13\
 13 12.108 13 11\
 C 13 10.79519 1\
2.960983 10.6017\
95 12.904297 10.\
416016 C 12.7464\
15 10.759733 12.\
404317 11 12 11 \
C 11.446 11 11 1\
0.554 11 10 C 11\
 9.595683 11.240\
267 9.2535881 11\
.583984 9.095703\
1 C 11.398205 9.\
0390231 11.20481\
 9 11 9 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x03A\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 3 2.99804\
69 L 3 3 L 3 4 L\
 3 19 L 4 19 L 1\
9 19 L 19 18 L 1\
9 7 L 19 6.30078\
12 L 18.992188 6\
.3007812 L 19 6.\
2910156 L 15.707\
031 2.9980469 L \
15.699219 3.0078\
125 L 15.699219 \
2.9980469 L 15 2\
.9980469 L 3 2.9\
980469 z M 4 4 L\
 7 4 L 7 8 L 7 9\
 L 15 9 L 15 8 L\
 15 4 L 15.29296\
9 4 L 18 6.70703\
12 L 18 7 L 18 1\
8 L 16 18 L 16 1\
1 L 15 11 L 7 11\
 L 6 11 L 6 18 L\
 4 18 L 4 4 z M \
8 4 L 11.900391 \
4 L 11.900391 8 \
L 8 8 L 8 4 z M \
7 12 L 15 12 L 1\
5 18 L 7 18 L 7 \
12 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x02\xae\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 id=\x22svg6\x22\
 version=\x221.1\x22 v\
iewBox=\x220 0 24 2\
4\x22 width=\x2224\x22 he\
ight=\x2224\x22>\x0a  <st\
yle id=\x22current-\
color-scheme\x22 ty\
pe=\x22text/css\x22>.C\
olorScheme-Text \
{\x0a            co\
lor:#232629;\x0a   \
     }</style>\x0a \
 <g transform=\x22t\
ranslate(1,1)\x22>\x0a\
    <path id=\x22pa\
th4\x22 class=\x22Colo\
rScheme-Text\x22 d=\
\x22m9.300781 3-3.5\
 3.5 3.5 3.5 0.7\
07031-0.707031-2\
.292969-2.292969\
h3.785154c3.047 \
0 5.5 2.453 5.5 \
5.5s-2.453 5.5-5\
.5 5.5h-1.5v1h1.\
5c3.601 0 6.5-2.\
899 6.5-6.5s-2.8\
99-6.5-6.5-6.5h-\
3.785154l2.29296\
9-2.292969-0.707\
031-0.707031\x22 fi\
ll=\x22currentColor\
\x22/>\x0a    <rect id\
=\x22rect837\x22 class\
=\x22ColorScheme-Te\
xt\x22 x=\x224\x22 y=\x223\x22 \
width=\x221\x22 height\
=\x227\x22 fill=\x22curre\
ntColor\x22 fill-ru\
le=\x22evenodd\x22/>\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x01\xa2\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color\x22 class=\x22Co\
lorScheme-Text\x22 \
d=\x22M 3 7 L 3 9 L\
 13 9 L 13 7 L 3\
 7 z\x22 transform=\
\x22translate(3 3)\x22\
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x02P\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 3 L 3 1\
7 L 7 17 L 7 19 \
L 17 19 L 17 10 \
L 13 6 L 12 6 L \
9 3 L 3 3 Z M 4 \
4 L 8 4 L 8 6 L \
7 6 L 7 16 L 4 1\
6 L 4 4 Z M 8 7 \
L 12 7 L 12 11 L\
 16 11 L 16 18 L\
 8 18 L 8 7 Z\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x02\x80\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
9 L 9 19 L 9 18 \
L 5 18 L 5 4 L 1\
3 4 L 13 8 L 17 \
8 L 17 11 L 18 1\
1 L 18 7 L 14 3 \
L 14 3 L 14 3 L \
5 3 L 4 3 z M 10\
 12 L 10 19 L 18\
 19 L 18 13 L 15\
 13 L 14 12 L 14\
 12 L 14 12 L 10\
 12 z M 13.1 14 \
L 17 14 L 17 18 \
L 11 18 L 11 15 \
L 12 15 L 13.1 1\
4 z \x22 class=\x22Col\
orScheme-Text\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x04\xf2\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22m7.01172 3c\
-.57735 1-.87813\
1 1-.300781 2l3.\
541016 6.140625-\
2.058594 3.52734\
4c-.445257-.4114\
53-1.036498-.667\
969-1.693359-.66\
7969-1.385 0-2.5\
 1.115-2.5 2.5 0\
 1.385 1.115 2.5\
 2.5 2.5 1.385 0\
 2.5-1.115 2.5-2\
.5 0-.167103-.01\
785-.330523-.048\
828-.488281l1.16\
2109-2.01367c.78\
0419-.001.878798\
-.774603 1.33398\
5-.785156l1.6035\
15 2.78125c-.033\
193.163037-.0507\
81.332734-.05078\
1.505859 0 1.385\
 1.115 2.5 2.5 2\
.5 1.385 0 2.5-1\
.115 2.5-2.5 0-1\
.385-1.115-2.5-2\
.5-2.5-.653333 0\
-1.241072.254586\
-1.685547.662109\
l-2.054687-3.521\
484 3.541015-6.1\
40625c.57735-1 .\
276569-1-.300781\
-2l-3.994141 6.8\
47656-3.99414-6.\
847656m3.988281 \
8c.277 0 .5.223.\
5.5 0 .277-.223.\
5-.5.5-.277 0-.5\
-.223-.5-.5 0-.2\
77.223-.5.5-.5zm\
-4.5 4c.831 0 1.\
5.669 1.5 1.5 0 \
.831-.669 1.5-1.\
5 1.5-.831 0-1.5\
-.669-1.5-1.5 0-\
.831.669-1.5 1.5\
-1.5m9 0c.831 0 \
1.5.669 1.5 1.5 \
0 .831-.669 1.5-\
1.5 1.5-.831 0-1\
.5-.669-1.5-1.5 \
0-.831.669-1.5 1\
.5-1.5\x22 class=\x22C\
olorScheme-Text\x22\
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x02y\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 5 \
17 L 5 3 L 4 3 z\
 M 17.566406 3.7\
519531 L 13.6328\
12 10.632812 L 6\
.7519531 14.5664\
06 L 7.2480469 1\
5.433594 L 14.36\
7188 11.367188 L\
 18.433594 4.248\
0469 L 17.566406\
 3.7519531 z \x22 c\
lass=\x22ColorSchem\
e-Text\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x02\xdc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 5 3 L 4 4\
 L 4 5 L 4 5.304\
6875 L 9 12.3671\
88 L 9 16 L 9 16\
.039062 L 12.990\
234 19 L 13 19 L\
 13 12.367188 L \
18 5.3046875 L 1\
8 4 L 17 3 L 5 3\
 z M 5 4 L 17 4 \
L 17 4.9882812 L\
 12.035156 12 L \
12 12 L 12 12.04\
8828 L 12 13 L 1\
2 17.019531 L 10\
 15.535156 L 10 \
13 L 10 12.04882\
8 L 10 12 L 9.96\
48438 12 L 5 4.9\
882812 L 5 4 z M\
 6 5 L 8 8 L 8 6\
 L 10 5 L 6 5 z \
\x22 class=\x22ColorSc\
heme-Text\x22/>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x05\x1f\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 4 3 L 4 9 L\
 4 10 L 4 15 L 4\
 16 L 4 17 L 3 1\
7 L 3 18 L 4 18 \
L 4 19 L 5 19 L \
5 18 L 18.292969\
 18 L 19 18 L 19\
 17.292969 L 19 \
17 L 18.707031 1\
7 L 17.292969 17\
 L 5 17 L 5 15.4\
31641 L 5 15.423\
828 L 5 15 L 5 1\
2.423828 L 5 11.\
423828 L 5 11 L \
5 10 L 5 9 L 5 6\
 L 5 5.9921875 L\
 5 5 L 5 3 L 4 3\
 z M 17 3 L 17 4\
 L 18 4 L 18 3 L\
 17 3 z M 18 4 L\
 18 5 L 19 5 L 1\
9 4 L 18 4 z M 1\
8 5 L 17 5 L 17 \
6 L 18 6 L 18 5 \
z M 17 5 L 17 4 \
L 16 4 L 16 5 L \
17 5 z M 6 4 L 6\
 5 L 7 5 L 7 4 L\
 6 4 z M 8 4 L 8\
 5 L 9 5 L 9 4 L\
 8 4 z M 6 6 L 6\
 7 L 7 7 L 7 6 L\
 6 6 z M 8 6 L 8\
 7 L 9 7 L 9 6 L\
 8 6 z M 11 7 L \
11 8 L 12 8 L 12\
 7 L 11 7 z M 13\
 7 L 13 8 L 14 8\
 L 14 7 L 13 7 z\
 M 11 9 L 11 10 \
L 12 10 L 12 9 L\
 11 9 z M 13 9 L\
 13 10 L 14 10 L\
 14 9 L 13 9 z M\
 7 13 L 7 14 L 8\
 14 L 8 13 L 7 1\
3 z M 8 14 L 8 1\
5 L 9 15 L 9 14 \
L 8 14 z M 8 15 \
L 7 15 L 7 16 L \
8 16 L 8 15 z M \
7 15 L 7 14 L 6 \
14 L 6 15 L 7 15\
 z \x22 class=\x22Colo\
rScheme-Text\x22/>\x0a\
  </g>\x0a</svg>\x0a\
\x00\x00\x02\x8b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 7 3 L 7 5\
 L 5 5 L 4 5 L 4\
 19 L 5 19 L 18 \
19 L 18 18 L 18 \
5 L 17 5 L 15 5 \
L 15 3 L 7 3 z M\
 5 6 L 6 6 L 6 8\
 L 16 8 L 16 6 L\
 17 6 L 17 18 L \
5 18 L 5 6 z M 7\
 9 L 7 10 L 15 1\
0 L 15 9 L 7 9 z\
 M 7 12 L 7 13 L\
 13 13 L 13 12 L\
 7 12 z M 7 15 L\
 7 16 L 10 16 L \
10 15 L 7 15 z \x22\
 class=\x22ColorSch\
eme-Text\x22/>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x02}\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 11 16 L 1\
6.293 16 L 14 18\
.293 L 14.707 19\
 L 18.207 15.5 L\
 14.707 12 L 14 \
12.707 L 16.293 \
15 L 11 15 L 11 \
16 Z M 5 18 L 5 \
4 L 13 4 L 13 8 \
L 17 8 L 17 13 L\
 18 13 L 18 7 L \
14 3 L 4 3 L 4 1\
9 L 13 19 L 13 1\
8 L 5 18 Z\x22/>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x03S\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 4 3 L 4 1\
7 L 3 17 L 3 18 \
L 4 18 L 4 19 L \
5 19 L 5 18 L 19\
 18 L 19 17 L 5 \
17 L 5 3 L 4 3 z\
 M 6.4101562 3.7\
128906 L 5.58984\
38 4.2871094 L 1\
1.0625 12.103516\
 L 6.7519531 14.\
566406 L 7.24804\
69 15.433594 L 1\
1.638672 12.9257\
81 L 12.685547 1\
4.421875 L 18.84\
1797 16.474609 L\
 19.158203 15.52\
5391 L 13.314453\
 13.578125 L 12.\
509766 12.427734\
 L 14.367188 11.\
367188 L 18.4335\
94 4.2480469 L 1\
7.566406 3.75195\
31 L 13.632812 1\
0.632812 L 11.93\
3594 11.603516 L\
 6.4101562 3.712\
8906 z \x22 class=\x22\
ColorScheme-Text\
\x22/>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x02\x81\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 8 3 L 8 9\
 L 9 9 L 9 4 L 1\
3 4 L 13 9 L 14 \
9 L 14 3 L 13 3 \
L 9 3 L 8 3 z M \
5.7929688 10 L 5\
 10.816406 L 11 \
17 L 17 10.81640\
6 L 16.207031 10\
 L 11 15.367188 \
L 5.7929688 10 z\
 M 4 17 L 4 19 L\
 5 19 L 17 19 L \
18 19 L 18 17 L \
17 17 L 17 18 L \
5 18 L 5 17 L 4 \
17 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x02P\
<\
!DOCTYPE svg>\x0a<s\
vg xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 viewBox=\x220\
 0 24 24\x22 versio\
n=\x221.1\x22 width=\x222\
4\x22 height=\x2224\x22>\x0a\
  <defs>\x0a    <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a  <\
/defs>\x0a  <g tran\
sform=\x22translate\
(1,1)\x22>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 3 L 3 1\
7 L 7 17 L 7 19 \
L 17 19 L 17 10 \
L 13 6 L 12 6 L \
9 3 L 3 3 Z M 4 \
4 L 8 4 L 8 6 L \
7 6 L 7 16 L 4 1\
6 L 4 4 Z M 8 7 \
L 12 7 L 12 11 L\
 16 11 L 16 18 L\
 8 18 L 8 7 Z\x22/>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x029\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 version=\x22\
1.1\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24\x22 height=\x2224\x22>\
\x0a  <style id=\x22cu\
rrent-color-sche\
me\x22 type=\x22text/c\
ss\x22>\x0a        .Co\
lorScheme-Text {\
\x0a            col\
or:#232629;\x0a    \
    }\x0a    </styl\
e>\x0a  <g transfor\
m=\x22translate(1,1\
)\x22>\x0a    <path cl\
ass=\x22ColorScheme\
-Text\x22 d=\x22m7.910\
2 3-4.9102 14h1.\
6582l1.625-4.437\
5h5.4336l0.89258\
 2.4375h1.6543l-\
4.1739-12h-2.179\
7zm1.1055 1.9375\
 2.1797 6.3438h-\
4.3906zm10.277 7\
.6758-4.5918 4.5\
918-1.1465-1.146\
5-0.70703 0.7070\
3 1.8594 1.8477 \
5.293-5.293-0.70\
703-0.70703z\x22 st\
yle=\x22fill:curren\
tColor\x22/>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x01\xe6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      <\
/style>\x0a  </defs\
>\x0a  <g transform\
=\x22translate(1,1)\
\x22>\x0a    <path sty\
le=\x22fill:current\
Color;fill-opaci\
ty:1;stroke:none\
\x22 d=\x22M 10 4 L 10\
 11 L 3 11 L 3 1\
2 L 10 12 L 10 1\
9 L 11 19 L 11 1\
2 L 18 12 L 18 1\
1 L 11 11 L 11 4\
 L 10 4 z \x22 clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x05a\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629;\
\x0a      }\x0a      .\
ColorScheme-High\
light {\x0a        \
color:#3daee9;\x0a \
     }\x0a      </s\
tyle>\x0a  </defs>\x0a\
  <g transform=\x22\
translate(1,1)\x22>\
\x0a    <path style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
d=\x22M 4 3 L 4 9 L\
 4 10 L 4 15 L 4\
 16 L 4 17 L 3 1\
7 L 3 18 L 4 18 \
L 4 19 L 5 19 L \
5 18 L 18.292969\
 18 L 19 18 L 19\
 17.292969 L 19 \
17 L 18.707031 1\
7 L 17.292969 17\
 L 5 17 L 5 15.4\
31641 L 5 15.423\
828 L 5 15 L 5 1\
2.423828 L 5 11.\
423828 L 5 11 L \
5 10 L 5 9 L 5 6\
 L 5 5.9921875 L\
 5 5 L 5 3 L 4 3\
 z M 15.048828 4\
.2304688 A 2.218\
6046 2.2186046 0\
 0 0 12.830078 6\
.4492188 A 2.218\
6046 2.2186046 0\
 0 0 15.048828 8\
.6679688 A 2.218\
6046 2.2186046 0\
 0 0 17.267578 6\
.4492188 A 2.218\
6046 2.2186046 0\
 0 0 15.048828 4\
.2304688 z M 7.9\
941406 7.7636719\
 A 0.8063584 0.8\
063584 0 0 0 7.1\
875 8.5703125 A \
0.8063584 0.8063\
584 0 0 0 7.9941\
406 9.3769531 A \
0.8063584 0.8063\
584 0 0 0 8.7988\
281 8.5703125 A \
0.8063584 0.8063\
584 0 0 0 7.9941\
406 7.7636719 z \
M 11.904297 11.1\
69922 A 1.470944\
9 1.4709449 0 0 \
0 10.433594 12.6\
40625 A 1.470944\
9 1.4709449 0 0 \
0 11.904297 14.1\
11328 A 1.470944\
9 1.4709449 0 0 \
0 13.375 12.6406\
25 A 1.4709449 1\
.4709449 0 0 0 1\
1.904297 11.1699\
22 z \x22 class=\x22Co\
lorScheme-Text\x22/\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x01\x98\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224\x22 height=\x2224\
\x22>\x0a  <defs id=\x22d\
efs3051\x22>\x0a    <s\
tyle type=\x22text/\
css\x22 id=\x22current\
-color-scheme\x22>\x0a\
      .ColorSche\
me-Text {\x0a      \
  color:#232629\x0a\
      }\x0a      </\
style>\x0a  </defs>\
\x0a  <g transform=\
\x22translate(1,1)\x22\
>\x0a    <path styl\
e=\x22fill:#da4453\x22\
 d=\x22M 10 4 L 10 \
14 L 12 14 L 12 \
4 L 10 4 z M 10 \
16 L 10 18 L 12 \
18 L 12 16 L 10 \
16 z \x22/>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x04{\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a  <path\
 \x0a        style=\
\x22fill:currentCol\
or;fill-opacity:\
1;stroke:none\x22\x0a \
       d=\x22M 5.5 \
2 C 4.119 2 3 3.\
119 3 4.5 L 3 7.\
5 C 3 8.881 4.11\
9 10 5.5 10 C 6.\
881 10 8 8.881 8\
 7.5 L 8 4.5 C 8\
 3.119 6.881 2 5\
.5 2 z M 11.5 2 \
C 10.119 2 9 3.1\
19 9 4.5 L 9 7.5\
 C 9 8.881 10.11\
9 10 11.5 10 C 1\
2.881 10 14 8.88\
1 14 7.5 L 14 4.\
5 C 14 3.119 12.\
881 2 11.5 2 z M\
 5.5 3 C 6.328 3\
 7 3.672 7 4.5 L\
 7 7.5 C 7 8.328\
 6.328 9 5.5 9 C\
 4.672 9 4 8.328\
 4 7.5 L 4 4.5 C\
 4 3.672 4.672 3\
 5.5 3 z M 11.5 \
3 C 12.328 3 13 \
3.672 13 4.5 L 1\
3 7.5 C 13 8.328\
 12.328 9 11.5 9\
 C 10.672 9 10 8\
.328 10 7.5 L 10\
 4.5 C 10 3.672 \
10.672 3 11.5 3 \
z M 2 9 L 2 10 L\
 3 10 L 3 9 L 2 \
9 z \x22\x0a        cl\
ass=\x22ColorScheme\
-Text\x22\x0a        /\
>\x0a  <path\x0a     s\
tyle=\x22fill:curre\
ntColor;fill-opa\
city:1;stroke:no\
ne\x22\x0a     d=\x22m 11\
,9 0,2 -2,0 0,1 \
2,0 0,2 1,0 0,-2\
 2,0 0,-1 -2,0 0\
,-2 z\x22\x0a     clas\
s=\x22ColorScheme-H\
ighlight\x22\x0a      \
/>\x0a</svg>\x0a\
\x00\x00\x03\x00\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 7 2 C 5.895 2 \
5 2.895 5 4 L 5 \
7 L 3 7 L 3 8 L \
5 8 L 5 14 L 6 1\
4 L 6 8 L 8 8 L \
8 7 L 6 7 L 6 4 \
C 6 3.448 6.448 \
3 7 3 L 9 3 L 9 \
2 L 8 2 L 7 2 z \
M 9.4707031 9.75\
97656 L 8.763671\
9 10.466797 L 10\
.177734 11.88085\
9 L 8.7636719 13\
.294922 L 9.4707\
031 14.001953 L \
10.884766 12.587\
891 L 12.298828 \
14.001953 L 13.0\
05859 13.294922 \
L 11.591797 11.8\
80859 L 13.00585\
9 10.466797 L 12\
.298828 9.759765\
6 L 10.884766 11\
.173828 L 9.4707\
031 9.7597656 z \
\x22\x0a     class=\x22Co\
lorScheme-Text\x22\x0a\
     />\x0a</svg>\x0a\
\x00\x00\x02}\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <d\
efs>\x0a        <st\
yle type=\x22text/c\
ss\x22 id=\x22current-\
color-scheme\x22>\x0a \
           .Colo\
rScheme-Text {\x0a \
               c\
olor:#232629;\x0a  \
          }\x0a    \
    </style>\x0a   \
 </defs>\x0a    <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22\x0a        \
  d=\x22m9.0000002 \
9v3h1.9999998v-1\
h-1v-2zm0.999999\
8-1c-1.6619998 0\
-2.9999998 1.338\
-2.9999998 3s1.3\
38 3 2.9999998 3\
c1.662 0 3-1.338\
 3-3s-1.338-3-3-\
3zm0 1a2 2 0 0 1\
 2 2 2 2 0 0 1-2\
 2 2 2 0 0 1-1.9\
999998-2 2 2 0 0\
 1 1.9999998-2zm\
-7-7v12h4v-1h-3v\
-10h5v3h3v2h1v-3\
l-3-3h-1z\x22\x0a     \
     class=\x22Colo\
rScheme-Text\x22\x0a  \
  />\x0a</svg>\x0a\
\x00\x00\x01\xef\
<\
svg viewBox=\x220 0\
 16 16\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style type=\x22tex\
t/css\x22 id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-Text {\x0a  \
          color:\
#232629;\x0a       \
 }\x0a    </style>\x0a\
    <g class=\x22Co\
lorScheme-Text\x22 \
fill=\x22currentCol\
or\x22 fill-rule=\x22e\
venodd\x22>\x0a       \
 <path d=\x22m8 2a6\
 6 0 0 0 -6 6 6 \
6 0 0 0 6 6 6 6 \
0 0 0 6-6 6 6 0 \
0 0 -6-6zm0 1a5 \
5 0 0 1 5 5 5 5 \
0 0 1 -5 5 5 5 0\
 0 1 -5-5 5 5 0 \
0 1 5-5z\x22/>\x0a    \
    <path d=\x22m7 \
4h2v2h-2z\x22/>\x0a   \
     <path d=\x22m7\
 7h2v5h-2z\x22/>\x0a  \
  </g>\x0a</svg>\x0a\
\x00\x00\x04\xdf\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22m 2,2 0,5.\
9960938 0,1 L 2,\
14 l 12,0 0,-1 -\
11,0 0,-1 3.0058\
59,0 0,-0.0078 0\
.0078,0.0078 2,-\
2 1.591797,0 2,2\
 2.40039,0 0,-1 \
-1.986328,0 -2,-\
2 -1.414062,0 -1\
.00586,0 -2,2 L \
3,11 3,8.9960938\
 l 2,0 0,-0.0078\
1 0.0078,0.00781\
 L 6.003906,8 7,\
8 8,8 8,7 7,7 7,\
6 6,6 6,7.996093\
8 5.296875,7.292\
9688 4.59375,7.9\
960938 3,7.99609\
38 3,2 2,2 Z M 6\
,2 6,3 6,4 7,4 7\
,3 8,3 8,2 6,2 Z\
 m 4,0 0,1 1,0 0\
,1 1,0 0,-2 -1,0\
 -1,0 z M 9,3.58\
98438 7.296875,5\
.2929688 8.00390\
6,6 9,5.0039062 \
9.996094,6 10.70\
3125,5.2929688 9\
,3.5898438 Z M 1\
1,6 l 0,1 -1,0 0\
,1 2,0 0,-1 0,-1\
 -1,0 z m 3,0 -1\
,1 1,0 0,-1 z\x22\x0a \
    class=\x22Color\
Scheme-Text\x22/>\x0a \
<path \x0a     styl\
e=\x22fill:currentC\
olor;fill-opacit\
y:0.5;stroke:non\
e\x22 \x0a     d=\x22M 9 \
5 L 7.0039062 7 \
L 8 7 L 8 8 L 6.\
0058594 8 L 5.00\
78125 9 L 1.9980\
469 9 L 1.998046\
9 13 L 6.9980469\
 13 L 8.9980469 \
12.992188 L 13.9\
98047 13 L 13.99\
8047 7 L 11.9980\
47 7 L 11.998047\
 8 L 9.9980469 8\
 L 9.9980469 7 L\
 10.998047 7 L 9\
 5 z \x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22/>\x0a</svg>\x0a\
\x00\x00\x02r\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-NegativeTex\
t {\x0a        colo\
r:#da4453;\x0a     \
 }\x0a      </style\
>\x0a  </defs>\x0a  <p\
ath\x0a     style=\x22\
fill:currentColo\
r;fill-opacity:1\
;stroke:none\x22 \x0a \
    class=\x22Color\
Scheme-NegativeT\
ext\x22\x0a    d=\x22M 8,\
2 A 6,6 0 0 0 2,\
8 6,6 0 0 0 8,14\
 6,6 0 0 0 14,8 \
6,6 0 0 0 8,2 Z \
M 5.70703,5 8,7.\
29297 10.29297,5\
 11,5.70703 8.70\
703,8 11,10.2929\
7 10.29297,11 8,\
8.70703 5.70703,\
11 5,10.29297 7.\
29297,8 5,5.7070\
3 5.70703,5 Z\x22\x0a \
       />\x0a</svg>\
\x0a\
\x00\x00\x06\x98\
(\
\xb5/\xfd`\xb1#u4\x00\x9aB(\x0c(\xe0N\
\x88\x1e\x1b)l'\x01\x99\xd8O\x8a\xcf\xe0\x02(b\
n|\xc4\x0a\x8a\x85\xa2C\xbb\xe1+b\xc1\x14n0\
\xc3|\x14C\x08\x01\xbe\x00\xb7\x00\xb0\x00\x0b\x12@@\
0\xaf\xbb\xde\xba_J8\xac\xa7NUR\x19G\xd8\
*\x8d\xc5\x17\x01\x9bt\x9e\x13\xa7\x8b!\xbc)\xcd\x85\
\xa2',aJ\x03\xc1\x07\x1e\x0f9\x18\xfd\xb62\xf4\
K\xf5\x19\xd5\xea\xbb\xefb*\x81\x84\x04\xcc\xfei\xbd\
\xf367\xb0^\x0c\x0b\x13\x14A\x10\x0cc\xac)H\
\xddSD+\xd5\x1a\xd3\x18C)u\xf7X\x8f\xc7\xc3\
\xb9\x19\x80\x9e\xf4\x84%\x09\xdbw@\xbb~\xb6Va\
|9\xa3\xf7\xf4\xd2G\xcf\xd8\xcb<\x19\xaf(7\x18\
\x0c\x83`\xec\xbdP\x1a{\x11zJ\x92\x84\xe1q\xe8\
\x04\x83C\x01\x05OJ\xf3\x13\x8e\xea\x9d\xea\xd6\x892\
\xd5\x02\x09\x13\x94\xe6\x99\xa0\x8b\xed\xf4\x89\xc2\x96+\xcd\
\x84!\x9d\xdf\x91D\x12\xa4@\x22\xb26\x17]!\xe1\
\x8d\x1e\xed\xbc~/\x95r\xfa|\xa90o\xaf1\xee\
\xdc\xc2\xf6\xa0\x9c\xcc\xce\xdb\x22\xb4\x969\x0c6w\xfb\
\xb5\xe3\xe0k\x9d;\x19\xb3\xd6-\x00\xa5QJ|\xce\
1\xf0\xd6\x8as\xcdg\xe45W\x9a\x06y=az\
\x10!\xbf\xd6\x1b\x9a&<{z\xe8\xd6\xcc \xd7w\
\x07J)\xf7\xa0\x5c\xd9I\xe5\xa2\x0e&\xee\xb9\x84k\
\xb2\xd7\xc0\x00\x08P\x1a\xa7\x81rD_\xa8\xc9Xt\
\xbed\x12]\xb1\xa4Q\xea\xe2\x5cS\xd9\x99\xbc\xb6\xd8\
\x951\xb5\xf3\x97a\x98\x84\xc3G\x1bb\x12\xe5!\x8a\
\xa0\x1d\x81\x81\xa4\xcf\xcf\x88l&1@\x82\x1cv\x95\
2v\x10\xf6*\xcdn`EM\x18,dL\x01a\
m\xce=O\xfeH\x8d\xd4\x9e>\xe7\xc6\xfd\x0b\x90\x04\
A\xaa\x14\x9d\xcb\x16%|\x91\xe7Xk\x8e.\xa94\
\x10\x0b\xe5z\x12\xc6\x17^G\xd5\xc9\xcf\x03/\xb4\x02\
\xa5\xdb\x8b\x07\xfa\x05\x8bp\xf1P\x13\xf4hJ\xf3\xc0\
\xb7.\xf4_\xa8q\xa1\xfc\xb0\xb7S\xcd\x1f\xe1\xbd\xed\
WP`W\x9a\xc8\x86p\xcc\x7f3V\xfcS\x19\xf7\
\xa5:i\xe7/\x93\x98\x91\xba\xe7\x8dI\x146\x9fk\
\xce\xe7\x05BG\xea#\xaa\xf6\xa3g\xcd\xc5\x97\xf3\x9d\
\xb9\xf9p\xda\xf6.\xdfM\xfb\xde\xa7G\xe8\xf0\xa9\xf4\
F]\xb5N\x94\xce|\x15\xba'\xaf\xa3\x0a\x97MV\
6\xedS&\xa9}\xc5\x8cM2\x85\xbd\xd3\x19\x8cn\
g\x0c\x0e\x8fC3\x89\xc9@\xb6\x87\x05\xd0\x81\x02\xd7\
\x12x{\xb2-\xda\xe62\xd9r\xe9\xd4#\x02\xf9p\
\x00\x12P\xd4\xc5%\xa5\x5c\x9c\xc2\xe5\x9es\xd7\x98/\
\xeejy\xb3\xcd\xe6\x04\x1a\x1a\x02\xca\xde\xc3\x01i\x80\
\xbd\xfc\x9b\xb2'\x17C\xbc\xb9\xdc\xcd\xd5\xe0{\xec=\
L\xe2a\xd2\x06D\x14\xd9\xfascWGnX\x95\
\xf14-,\xbaJ\xa2$\xfa\x12=aKb\x13\xc9\
\xe0\x92H\xe9 B&\x09\xc0\x987\x80\x8a\x01Ev\
Q\xfa\x96\xe9\x04\xfc\xae\x91\x9bqE*\x17\x17W\xa3\
J-\xce\xa5\x8b\xd39U\x1a\x9c\x8c\xcf-\x19\xa9\x82\
\x8e\xb9\xd5\xd4\x22\xa3dl\x91M\xc2\x18\x99\x00\x08\x94\
w\x952v\xf4\xa63\x81\xa0\xa81=D5%\x92\
$\x05\x85\xd2p!\x09!\xceA\xe7r\x1b\x22Q\x12\
\xe2`\x12c\x10\xa3\x881\x84\x18B\x0c5\x82\x22\x81\
\x88\xc8\x08E\x12\xa4\xa4\x0e\x8a\x0d3\xf8\x0e\xce\x83H\
<\xe5Bi\xde\x06PD\x0ed_\x12Q\xacU\x16\
\x94\xa8\xbb\x9dT\xe1t/\x16\xdc\x8d\xb7\xfb\xb1\xc8\xfb\
\x0a\xa6\x1b\xc6\xb1\x1a\xe1\xd2\x22?Fw\xed\x86]\xae\
\xc0c/\x1d\x0d!\xc1\x8d\x921rt\x1c\x95\x84?\
/\x9c\xfb8\xcd\xcd\xbeO\x08:8\xf7{\x96Zq\
\xc7\x074.\xe9\xd1\xec\xf2x\x86\xf6s.\xfd\xd6\xee\
m\xcd?\xde7\xb0\xff\xd0\xbfQ\x01\xb8{\x8cQ\x0c\
\x09\x8e\xdclr\xee\x13\xc54\xc0\x16\xc9\xda\x0bH\xee\
\xb3\x22\xd65F\xbc\xfa\x83Y\xb4\x8f\x10}\xb0\x06D\
\xca\xe9\xa19\x95(\x907\xfc31h\xb3r\x88S\
\xa3\x86%\xad\x99F0\xed`/\xf2t\xe6>\x0c2\
B\x14\x1c\xa2\x80Rv\xf4<\xd9\x02\xd0U\x5ct \
g%\x82|\xfd\x82\xc2\xe1\x82\x03x\xd1\x80\xfd;\xe9\
\xb7\xfb\xa5\x5c\xaa[G\x17\xf21;t\xcbcX\x14\
\xcc\x18a\xa9>X\x02\xe0\xa2\xa9f\xd4Q\xa9\xc1\x00\
!!N\x90EY\xa2*\x05z\x95\x92\x92IaA\
e\x15\xc1J\xe7\xf5J\xf1\x1a*\x82\xe4A\xd2\x1f\xa2\
~I\x8b\xda \xe9J\x8b\x92\xef48\x1a\xf1+\xf9\
%S\x9f\xfb\x1e\xf4\xb5)\x9d\xbf'D>\x881\x10\
5q\x10\xe8tNWy\xe08\x1fB\xc8\xc4\xff\x85\
#!\x7f^G\x97.I\xb59}\x5c\x08\xee9\xf8\
\x83\x83E\xd9\xfaA\xd8\x98\xd4\xb7\x05b\x06\x8b\x03`\
\xae)P\xfc\x01<\xd8\xef\x89\x88\xcc\x91\x9d:l=\
\xdd,/`\x0et\x1f@\x05\x8a\x00q\xee\x8b\x98O\
\x8e\xc0wC=vRDU\xe0\xb3\xd3\xa5}\xe7m\
\x8c\xe3<}w\xac\xb7\xe2\xe9\xfb\xd9\xba0\xe1\xb7\xa3\
\x03\xa6\xbe\xca\xa0\xaa2P\xf7\x9a\x1b\xfd(5\x5c[\
\xd8oa\xc6\xe9\x16\xb9g\xa7\xc5\x1d\x9aNx\x048\
r\xf0Z\xdc\x8dN{\x8f\x87LV`U\xb0G\xb0\
|\xc0Y&\xe5\x5c\x99\x07c\x87\x5c\xf6\x0fA\xe1\xb1\
q\x02\x8bu\x96d\x01wL:<|\xb2\xf4\xda~\
W\xcd\xber\x83\xe0\xd6-}\x80b\x9d%Yn\xb3\
@\x173\xda\xfc\xd5\x9a@\x8f\x92\x0bT(\x04\x94\x0f\
\x16k\x1b6K,\x16\x1aN\x10\x9a\xd2\xf3\xbc\xbat\
\xbf\x8c)\x02\x12FW^\x90\xb6\xf0\xd6H\xa2E\xd6\
D,5\x9f\x07\x94y\x22\xcf\xa1\xad\xdc\x13\xf8\xb1{\
\xfd,\x01\x09\xa1\x02\x0eQ\xa1\xedKv\x94\xc9\x14\x85\
U}\x06\xe5q\xb4M\xecp\x01N\xa9\xa8F\x01=\
\xd2r{\xc80\xea\x22%;kXK7\x92)4\
\x90\x03\xfexF!\xe6x\x19\xdc\xd6,\xa6kI\xd2\
\xbe\xe4\x00-\x06\x8eA=v\xc9\x06`\xe7G\xb5\xce\
\xd3\xb6\x99\xc0\xb2\xa1hX\xa2 \xfbK\xaf\xdc\xe6\x9f\
\x8beP<\xfe\xb5:R}\xfc\x22\xd4\x83\x7f\xe9i\
\xa3[)\x09K6\x0b8l\x1c\x1b5(,\xe3\xe4\
\xb5L\x98\xd2>\xaa\xd7\xd6KM\xc3\xda0\x80\x8d=\
\xaf\xbf\xe0A\xbeR\xc2\xfd@j\xb1X\x1d\x9e\xc4\x5c\
a\xf8!h\x91^\xcd{q\xc4\xc3>A:&1\
\xfd\xc7}P\xad\xeaZ~\xf4\x10\xc5l\xaa>\xffr\
\x80\xe6\x96@=\x1ahh`\xb1-\xd1\xcc\x1aD\x9f\
w\x14f\xf9)\xcb\x08\xfcR\xaf\x9b\x90\xd3\xcf\xb78\
*\xb2@\xbfp0!i4ih\x9f\xfb\x15\x97\x9f\
\x0a1\xff\x9c\xa5\x0a\x91\xc2\xc4;\x0d+\xc7\xae.C\
C\xba\xea\x03]\xb1\x0a\
\x00\x00\x03\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 10 2.5 C 9.0\
680195 2.5 8.284\
4627 3.1373007 8\
.0625 4 L 2 4 L \
2 5 L 8.0625 5 C\
 8.2844627 5.862\
6993 9.0680195 6\
.5 10 6.5 C 10.9\
31981 6.5 11.715\
537 5.8626993 11\
.9375 5 L 14 5 L\
 14 4 L 11.9375 \
4 C 11.715537 3.\
1373007 10.93198\
1 2.5 10 2.5 z M\
 5 9.5 C 4.06801\
91 9.5 3.2844626\
 10.137301 3.062\
5 11 L 2 11 L 2 \
12 L 3.0625 12 C\
 3.2844626 12.86\
2699 4.0680191 1\
3.5 5 13.5 C 5.9\
319809 13.5 6.71\
55374 12.862699 \
6.9375 12 L 7 12\
 L 9 12 L 14 12 \
L 14 11 L 9 11 L\
 7 11 L 6.9375 1\
1 C 6.7155374 10\
.137301 5.931980\
9 9.5 5 9.5 z M \
5 10.5 C 5.55228\
 10.5 6 10.94772\
 6 11.5 C 6 12.0\
5228 5.55228 12.\
5 5 12.5 C 4.447\
72 12.5 4 12.052\
28 4 11.5 C 4 10\
.94772 4.44772 1\
0.5 5 10.5 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02 \
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 8 2 A 6.000001\
9 6.0000148 0 0 \
0 2 8 A 6.000001\
9 6.0000148 0 0 \
0 8 14 A 6.00000\
19 6.0000148 0 0\
 0 14 8 A 6.0000\
019 6.0000148 0 \
0 0 8 2 z M 8 3 \
L 8 8 L 13 8 A 5\
 5 0 0 1 8 13 A \
5 5 0 0 1 3 8 A \
5 5 0 0 1 8 3 z \
\x22\x0a     class=\x22Co\
lorScheme-Text\x22\x0a\
     />\x0a</svg>\x0a\
\x00\x00\x02-\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 4 L 3 \
4 L 3 3 L 13 3 L\
 13 4 L 14 4 L 1\
4 2 L 2 2 z M 8 \
4 L 3 9.1679688 \
L 3.8046875 10 L\
 8 5.6621094 L 1\
2.195312 10 L 13\
 9.1679688 L 8 4\
 z M 6 10 L 6 14\
 L 7 14 L 10 14 \
L 10 10 L 9 10 L\
 9 13 L 7 13 L 7\
 10 L 6 10 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x058\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2.5 2 C 2.2238\
576 2 2 2.223857\
6 2 2.5 C 2 2.77\
61424 2.2238576 \
3 2.5 3 C 2.7761\
424 3 3 2.776142\
4 3 2.5 C 3 2.22\
38576 2.7761424 \
2 2.5 2 z M 5.5 \
2 C 5.2238576 2 \
5 2.2238576 5 2.\
5 C 5 2.7761424 \
5.2238576 3 5.5 \
3 C 5.7761424 3 \
6 2.7761424 6 2.\
5 C 6 2.2238576 \
5.7761424 2 5.5 \
2 z M 13.160156 \
2 L 9.7382812 6.\
3105469 C 9.0627\
65 6.0537156 8.2\
111082 5.9824498\
 7 6 C 5.6442244\
 7.2930815 4.750\
7597 7.7091991 2\
 8 L 2 9 C 4.113\
7135 12.371692 5\
.4745763 14 9 14\
 L 10 14 C 11.07\
3961 12.616195 1\
1.627119 11.6101\
69 12 10 L 12 9 \
C 11.558507 8.00\
93924 11.158004 \
7.334604 10.6738\
28 6.8789062 L 1\
4 2.6601562 L 13\
.160156 2 z M 4 \
4 C 3.4477153 4 \
3 4.4477153 3 5 \
C 3 5.5522847 3.\
4477153 6 4 6 C \
4.5522847 6 5 5.\
5522847 5 5 C 5 \
4.4477153 4.5522\
847 4 4 4 z M 7.\
5292969 7.101562\
5 C 9.6322903 7.\
2655765 10.16858\
5 8.0162663 10.8\
57422 9.6992188 \
C 10.284594 11.2\
4586 10.385403 1\
1.602833 9.27343\
75 12.96875 C 6.\
1355922 12.69491\
5 5.052768 11.54\
0538 3.3261719 8\
.8300781 C 5.122\
354 8.7567482 6.\
1084274 8.104628\
5 7.5292969 7.10\
15625 z \x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x04\xe7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 13.314453 2 L \
2 13.294922 L 2.\
7148438 14 L 14 \
2.6972656 L 13.3\
14453 2 z M 8 3 \
A 8.9999916 9.00\
0003 0 0 0 0.123\
04688 7.6679688 \
C 0.25199187 8.0\
317035 0.4804856\
2 8.3445563 0.77\
929688 8.5761719\
 A 7.9999926 8.0\
000028 0 0 1 8 4\
 A 3.9999993 4.0\
000007 0 0 0 4 8\
 A 3.9999993 4.0\
000007 0 0 0 4.1\
054688 8.8945312\
 L 5 8 A 2.99999\
93 3.0000005 0 0\
 1 8 5 L 8.89257\
81 4.1074219 A 3\
.9999993 4.00000\
07 0 0 0 8.34960\
94 4.0175781 A 7\
.9999926 8.00000\
28 0 0 1 8.92773\
44 4.0722656 L 9\
.8066406 3.19335\
94 A 8.9999916 9\
.000003 0 0 0 8 \
3 z M 13.835938 \
5.1640625 L 13.1\
21094 5.8789062 \
A 7.9999926 8.00\
00028 0 0 1 15.2\
20703 8.5761719 \
C 15.522218 8.34\
24607 15.752612 \
8.0261216 15.880\
859 7.6582031 A \
8.9999916 9.0000\
03 0 0 0 13.8359\
38 5.1640625 z M\
 11.894531 7.105\
4688 L 11 8 A 2.\
9999993 3.000000\
5 0 0 1 8 11 L 7\
.1074219 11.8925\
78 A 3.9999993 4\
.0000007 0 0 0 8\
 12 A 3.9999993 \
4.0000007 0 0 0 \
12 8 A 3.9999993\
 4.0000007 0 0 0\
 11.894531 7.105\
4688 z \x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02\xbe\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 13.281\
25 L 2 14 L 8 14\
 L 8 10 L 7.6562\
5 10.34375 L 6.3\
125 9 L 6.28125 \
9 L 3 12.28125 L\
 3 3 L 13 3 L 13\
 8 L 14 8 L 14 2\
 L 2 2 z M 6 4 C\
 4.8954305 4 4 4\
.8954305 4 6 C 4\
 7.1045695 4.895\
4305 8 6 8 C 7.1\
045695 8 8 7.104\
5695 8 6 C 8 4.8\
954305 7.1045695\
 4 6 4 z M 11 9 \
L 11 11 L 9 11 L\
 9 12 L 11 12 L \
11 14 L 12 14 L \
12 12 L 14 12 L \
14 11 L 12 11 L \
12 9 L 11 9 z \x22\x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x02\x82\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 2 2 L 2 5 L \
3 5 L 3 3 L 5 3 \
L 5 2 L 3 2 L 2 \
2 z M 11 2 L 11 \
3 L 13 3 L 13 5 \
L 14 5 L 14 2 L \
13 2 L 11 2 z M \
4 4 L 4 12 L 12 \
12 L 12 4 L 4 4 \
z M 5 5 L 11 5 L\
 11 11 L 5 11 L \
5 5 z M 2 11 L 2\
 14 L 3 14 L 5 1\
4 L 5 13 L 3 13 \
L 3 11 L 2 11 z \
M 13 11 L 13 13 \
L 11 13 L 11 14 \
L 14 14 L 14 13 \
L 14 11 L 13 11 \
z \x22\x0a     class=\x22\
ColorScheme-Text\
\x22\x0a     />\x0a</svg>\
\x0a\
\x00\x00\x02\x11\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a    <\
path \x0a        st\
yle=\x22fill:curren\
tColor;fill-opac\
ity:1;stroke:non\
e\x22 \x0a          d=\
\x22M 2 2 L 2 12 L \
5 15 L 5 12 L 14\
 12 L 14 2 L 2 2\
 z M 3 3 L 13 3 \
L 13 11 L 3 11 L\
 3 3 z M 7 4 L 7\
 5 L 9 5 L 9 4 L\
 7 4 z M 7 6 L 7\
 10 L 9 10 L 9 6\
 L 7 6 z \x22\x0a     \
     id=\x22rect416\
3\x22 \x0a          cl\
ass=\x22ColorScheme\
-Text\x22/>\x0a</svg>\x0a\
\
\x00\x00\x03\x95\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 14 L 3\
 14 L 4 14 L 7 1\
4 L 7 13 L 6 13 \
L 5 13 L 5 10 L \
6 10 L 7 10 L 8 \
10 L 8 9 L 7 9 L\
 5 9 L 3.96875 9\
 L 3.96875 13 L \
3 13 L 3 3 L 4 3\
 L 5 3 L 5 6 L 5\
 7 L 7 7 L 11 7 \
L 11 6 L 11 3 L \
11.28125 3 L 13 \
4.71875 L 13 5 L\
 13 7 L 14 7 L 1\
4 4.28125 L 11.7\
1875 2 L 11.6875\
 2 L 11 2 L 4 2 \
L 3 2 L 2 2 z M \
6 3 L 7.90625 3 \
L 7.90625 6 L 6 \
6 L 6 3 z M 12 8\
 L 11 9 L 10 10 \
L 8 12 L 8 13 L \
8 14 L 10 14 L 1\
1 13 L 12 12 L 1\
3 11 L 14 10 L 1\
2 8 z M 11.68945\
3 9.6894531 L 12\
.28125 10.28125 \
L 10.59375 11.96\
875 L 10.59375 1\
1.984375 L 9.312\
5 13.28125 L 8.7\
1875 12.6875 L 1\
1.689453 9.68945\
31 z \x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22\x0a     />\x0a</s\
vg>\x0a\
\x00\x00\x04\xa6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629\x0a      }\
\x0a      </style>\x0a\
  </defs>\x0a    <p\
ath\x0a       style\
=\x22fill:currentCo\
lor\x22\x0a       d=\x22M\
 13.996094 3.654\
2969 L 6.9960938\
 3.6582031 L 4.5\
546875 10.349609\
 L 3 7.6542969 L\
 2 7.6542969 L 2\
 8.6542969 L 2.4\
277344 8.6542969\
 L 4.5605469 12.\
347656 L 7.58007\
81 4.6542969 L 1\
4.001953 4.65429\
69 L 13.996094 3\
.6542969 z M 9.9\
960938 5.6542969\
 C 8.3340937 5.6\
542969 6.9960938\
 6.9922969 6.996\
0938 8.6542969 C\
 6.9960938 10.31\
6297 8.3340938 1\
1.654297 9.99609\
38 11.654297 C 1\
0.769094 11.6542\
97 11.465094 11.\
355906 11.996094\
 10.878906 L 11.\
996094 11.654297\
 L 12.996094 11.\
654297 L 12.9960\
94 5.6542969 L 1\
1.996094 5.65429\
69 L 11.996094 6\
.4296875 C 11.46\
5094 5.9526875 1\
0.769094 5.65429\
69 9.9960938 5.6\
542969 z M 9.996\
0938 6.6542969 C\
 11.104094 6.654\
2969 11.996094 7\
.5462969 11.9960\
94 8.6542969 C 1\
1.996094 9.76229\
69 11.104094 10.\
654297 9.9960938\
 10.654297 C 8.8\
880937 10.654297\
 7.9960938 9.762\
2969 7.9960938 8\
.6542969 C 7.996\
0938 7.5462969 8\
.8880937 6.65429\
69 9.9960938 6.6\
542969 z \x22\x0a     \
  class=\x22ColorSc\
heme-Text\x22 />\x0a</\
svg>\x0a\
\x00\x00\x02\xbe\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629\x0a      }\
\x0a      </style>\x0a\
  </defs>\x0a    <p\
ath\x0a       style\
=\x22fill:currentCo\
lor\x22\x0a       d=\x22M\
 8 2 A 6 2 0 0 0\
 2 4 L 2 12 A 6 \
2 0 0 0 8 14 A 6\
 2 0 0 0 14 12 L\
 14 4 A 6 2 0 0 \
0 8 2 z M 8 3 A \
5 1 0 0 1 13 4 A\
 5 1 0 0 1 8 5 A\
 5 1 0 0 1 3 4 A\
 5 1 0 0 1 8 3 z\
 M 3 5.1015625 A\
 6 2 0 0 0 8 6 A\
 6 2 0 0 0 13 5.\
1035156 L 13 8 A\
 5 1 0 0 1 8 9 A\
 5 1 0 0 1 3 8 L\
 3 5.1015625 z M\
 3 9.1015625 A 6\
 2 0 0 0 8 10 A \
6 2 0 0 0 13 9.1\
035156 L 13 12 A\
 5 1 0 0 1 8 13 \
A 5 1 0 0 1 3 12\
 L 3 9.1015625 z\
 \x22\x0a       class=\
\x22ColorScheme-Tex\
t\x22 />\x0a</svg>\x0a\
\x00\x00\x01\xd7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22m 2,2 0,11 0,1\
 1,0 11,0 0,-1 -\
1,0 0,-1 -1,0 0,\
-1 0,-1 -1,0 0,1\
 -1,0 0,-1 L 9,1\
0 9,6 8,6 8,3 7,\
3 7,2 6,2 6,4 5,\
4 5,6 4,6 4,9 3,\
9 3,2 Z\x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02\x13\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 2 2 L 2 14 L\
 3 14 L 14 14 L \
14 13 L 13 13 L \
13 11 L 13 8 L 1\
2 8 L 12 6 L 11 \
6 L 11 9 L 10 9 \
L 10 7 L 9 7 L 9\
 5 L 8 5 L 8 2 L\
 7 2 L 7 4 L 6 4\
 L 6 6 L 5 6 L 5\
 7 L 4 7 L 4 8 L\
 3 8 L 3 2 L 2 2\
 z \x22\x0a     class=\
\x22ColorScheme-Tex\
t\x22\x0a     />\x0a</svg\
>\x0a\
\x00\x00\x05\xa7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a  <g\x0a\
     transform=\x22\
translate(-421.7\
1429,-531.79074)\
\x22>\x0a    <g\x0a      \
 transform=\x22matr\
ix(0.75,0,0,0.74\
999813,421.46429\
,-241.22897)\x22>\x0a \
     <path\x0a     \
    style=\x22fill:\
currentColor;fil\
l-opacity:1;stro\
ke:none\x22 \x0a      \
   d=\x22M 8 3 A 8.\
9999925 9.000002\
3 0 0 0 0.123046\
88 7.6679688 C 0\
.2519919 8.03171\
78 0.48048563 8.\
3445725 0.779296\
88 8.5761719 A 7\
.9999935 8.00000\
21 0 0 1 8 4 A 3\
.9999996 4.00000\
04 0 0 0 4 8 A 3\
.9999996 4.00000\
04 0 0 0 8 12 A \
3.9999996 4.0000\
004 0 0 0 12 8 A\
 3.9999996 4.000\
0004 0 0 0 8.349\
6094 4.0175781 A\
 7.9999935 8.000\
0021 0 0 1 15.22\
0703 8.5761719 C\
 15.522218 8.342\
4725 15.752612 8\
.0260772 15.8808\
59 7.6582031 A 8\
.9999925 9.00000\
23 0 0 0 8 3 z M\
 8 5 A 2.9999996\
 3.0000002 0 0 1\
 11 8 A 2.999999\
6 3.0000002 0 0 \
1 8 11 A 2.99999\
96 3.0000002 0 0\
 1 5 8 A 2.99999\
96 3.0000002 0 0\
 1 8 5 z M 8 6 A\
 1.9999999 2.000\
0003 0 0 0 6 8 A\
 1.9999999 2.000\
0003 0 0 0 8 10 \
A 1.9999999 2.00\
00003 0 0 0 10 8\
 A 1.9999999 2.0\
000003 0 0 0 9.9\
101562 7.4121094\
 A 0.9999999 1 0\
 0 1 9 8 A 0.999\
9999 1 0 0 1 8 7\
 A 0.9999999 1 0\
 0 1 8.5898438 6\
.0898438 A 1.999\
9999 2.0000003 0\
 0 0 8 6 z \x22\x0a   \
      transform=\
\x22matrix(1.333333\
3,0,0,1.3333367,\
0.33333333,1030.\
6955)\x22\x0a     clas\
s=\x22ColorScheme-T\
ext\x22\x0a         id\
=\x22rect4170\x22 />\x0a \
   </g>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x02\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 14 L 3\
 14 L 4 14 L 10 \
14 L 11 14 L 12 \
14 L 14 14 L 14 \
4.28125 L 11.718\
75 2 L 11.6875 2\
 L 11 2 L 4 2 L \
3 2 L 2 2 z M 3 \
3 L 4 3 L 5 3 L \
5 6 L 5 7 L 11 7\
 L 11 6 L 11 3 L\
 11.28125 3 L 13\
 4.71875 L 13 5 \
L 13 13 L 12 13 \
L 12 9 L 11 9 L \
5 9 L 3.96875 9 \
L 3.96875 13 L 3\
 13 L 3 3 z M 6 \
3 L 7.90625 3 L \
7.90625 6 L 6 6 \
L 6 3 z M 5 10 L\
 6 10 L 10 10 L \
11 10 L 11 13 L \
10 13 L 6 13 L 5\
 13 L 5 10 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02y\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 16 16\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <style i\
d=\x22current-color\
-scheme\x22 type=\x22t\
ext/css\x22>.ColorS\
cheme-Text {\x0a   \
         color:#\
232629;\x0a        \
}</style>\x0a    <p\
ath id=\x22path4\x22 c\
lass=\x22ColorSchem\
e-Text\x22 d=\x22m7.5 \
2-3.5 3.5 3.5 3.\
5 0.71875-0.7187\
5-2.3125-2.28125\
h3.59375c1.93299\
8 0 3.5 1.566998\
4 3.5 3.5 0 1.93\
3002-1.567002 3.\
5-3.5 3.5h-1.5v1\
h1.5c2.485283 0 \
4.5-2.014748 4.5\
-4.5 0-2.4852521\
-2.014717-4.5-4.\
5-4.5h-3.59375l2\
.3125-2.28125z\x22 \
fill=\x22currentCol\
or\x22/>\x0a    <rect \
id=\x22rect837\x22 cla\
ss=\x22ColorScheme-\
Text\x22 x=\x222\x22 y=\x222\
\x22 width=\x221\x22 heig\
ht=\x227\x22 fill=\x22cur\
rentColor\x22 fill-\
rule=\x22evenodd\x22/>\
\x0a</svg>\x0a\
\x00\x00\x01i\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 3,7 3,9 13,9 1\
3,7 3,7 Z\x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02\x16\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
2 L 6 12 L 6 14 \
L 14 14 L 14 7 L\
 11 4 L 10 4 L 8\
 2 L 3 2 Z M 4 3\
 L 7 3 L 7 4 L 6\
 4 L 6 11 L 4 11\
 L 4 3 Z M 7 5 L\
 10 5 L 10 8 L 1\
3 8 L 13 13 L 7 \
13 L 7 5 Z\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\x0e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a     style=\x22f\
ill:currentColor\
;fill-opacity:1;\
stroke:none\x22 \x0a  \
   d=\x22M 3 2 L 3 \
14 L 6 14 L 6 13\
 L 4 13 L 4 3 L \
9 3 L 9 6 L 12 6\
 L 12 8 L 13 8 L\
 13 5 L 10 2 L 9\
 2 L 3 2 z M 7 8\
 L 7 14 L 13 14 \
L 13 9 L 11 9 L \
10 8 L 7 8 z M 8\
 10 L 12 10 L 12\
 13 L 8 13 L 8 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22/>\x0a</svg>\x0a\
\x00\x00\x06\xa9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 5 2 C 4.567 2.\
75 4.34825 2.75 \
4.78125 3.5 L 7.\
40625 8 L 5.9062\
5 10.21875 C 5.6\
3425 10.08075 5.\
325 10 5 10 C 3.\
895 10 3 10.895 \
3 12 C 3 13.105 \
3.895 14 5 14 C \
6.105 14 7 13.10\
5 7 12 C 7 11.59\
5 6.86325 11.221\
25 6.65625 10.90\
625 C 6.65125 10\
.89825 6.66125 1\
0.882 6.65625 10\
.875 L 7.09375 1\
0.25 C 7.89575 1\
0.225 8.008 9.65\
725 8.5 9.65625 \
C 8.511 9.65625 \
8.52025 9.65525 \
8.53125 9.65625 \
L 8.5625 9.71875\
 L 9.34375 10.87\
5 L 9.34375 10.9\
0625 C 9.13775 1\
1.22125 8.998046\
9 11.595 8.99804\
69 12 C 8.998046\
9 13.105 9.89304\
69 14 10.998047 \
14 C 12.103047 1\
4 12.998047 13.1\
05 12.998047 12 \
C 12.998047 10.8\
95 12.103047 10 \
10.998047 10 C 1\
0.673047 10 10.3\
6475 10.08075 10\
.09375 10.21875 \
L 8.59375 8 C 8.\
59375 8 11.22875\
 3.492 11.21875 \
3.5 C 11.65175 2\
.75 11.431047 2.\
75 10.998047 2 L\
 7.9980469 7.125\
 L 5 2 z M 7.998\
0469 8 L 8 8 C 8\
.276 8 8.5 8.224\
 8.5 8.5 C 8.5 8\
.754 8.3075 8.96\
8 8.0625 9 L 7.9\
375 9 C 7.6925 8\
.968 7.4980469 8\
.754 7.4980469 8\
.5 C 7.4980469 8\
.224 7.7220469 8\
 7.9980469 8 z M\
 4.9980469 11 C \
5.5500469 11 5.9\
980469 11.448 5.\
9980469 12 C 5.9\
980469 12.552 5.\
5500469 13 4.998\
0469 13 C 4.4460\
469 13 3.9980469\
 12.552 3.998046\
9 12 C 3.9980469\
 11.448 4.446046\
9 11 4.9980469 1\
1 z M 10.998047 \
11 C 11.550047 1\
1 11.998047 11.4\
48 11.998047 12 \
C 11.998047 12.5\
52 11.550047 13 \
10.998047 13 C 1\
0.446047 13 9.99\
80469 12.552 9.9\
980469 12 C 9.99\
80469 11.448 10.\
446047 11 10.998\
047 11 z \x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02?\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 3 2 L 2 3 L \
2 4 L 2 4.3125 L\
 6 9.96875 L 6 1\
0 L 6 12 L 10 14\
 L 10 10 L 10 9.\
96875 L 14 4.312\
5 L 14 3 L 13 2 \
L 9 2 L 7.25 2 L\
 3 2 z M 3 3 L 7\
.25 3 L 9 3 L 13\
 3 L 13 4 L 9 9.\
625 L 9 10 L 9 1\
1 L 9 12 L 7 11 \
L 7 10 L 7 9.625\
 L 3 4 L 3 3 z \x22\
\x0a     class=\x22Col\
orScheme-Text\x22\x0a \
    />\x0a</svg>\x0a\
\x00\x00\x03\xc7\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 13 L 2\
 14 L 3 14 L 14 \
14 L 14 13 L 3 1\
3 L 3 2 L 2 2 z \
M 4 2 L 4 3 L 5 \
3 L 5 2 L 4 2 z \
M 6 2 L 6 3 L 7 \
3 L 7 2 L 6 2 z \
M 12 3 L 12 4 L \
13 4 L 13 3 L 12\
 3 z M 13 4 L 13\
 5 L 14 5 L 14 4\
 L 13 4 z M 13 5\
 L 12 5 L 12 6 L\
 13 6 L 13 5 z M\
 12 5 L 12 4 L 1\
1 4 L 11 5 L 12 \
5 z M 4 4 L 4 5 \
L 5 5 L 5 4 L 4 \
4 z M 6 4 L 6 5 \
L 7 5 L 7 4 L 6 \
4 z M 9 7 L 9 8 \
L 10 8 L 10 7 L \
9 7 z M 11 7 L 1\
1 8 L 12 8 L 12 \
7 L 11 7 z M 5 9\
 L 5 10 L 6 10 L\
 6 9 L 5 9 z M 6\
 10 L 6 11 L 7 1\
1 L 7 10 L 6 10 \
z M 6 11 L 5 11 \
L 5 12 L 6 12 L \
6 11 z M 5 11 L \
5 10 L 4 10 L 4 \
11 L 5 11 z M 9 \
9 L 9 10 L 10 10\
 L 10 9 L 9 9 z \
M 11 9 L 11 10 L\
 12 10 L 12 9 L \
11 9 z \x22\x0a     cl\
ass=\x22ColorScheme\
-Text\x22\x0a     />\x0a<\
/svg>\x0a\
\x00\x00\x02d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 5 2 L 5 3 L \
3 3 L 3 14 L 7 1\
4 L 8 14 L 12 14\
 L 13 14 L 13 13\
 L 13 9 L 13 3 L\
 11 3 L 11 2 L 5\
 2 z M 4 4 L 5 4\
 L 5 5 L 11 5 L \
11 4 L 12 4 L 12\
 6 L 12 12 L 12 \
13 L 8 13 L 7 13\
 L 4 13 L 4 12 L\
 4 6 L 4 4 z M 5\
 7 L 5 8 L 10 8 \
L 10 7 L 5 7 z M\
 5 10 L 5 11 L 8\
 11 L 8 10 L 5 1\
0 z \x22\x0a     class\
=\x22ColorScheme-Te\
xt\x22\x0a     />\x0a</sv\
g>\x0a\
\x00\x00\x02S\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 7 12 L 11\
.0859 12 L 9.464\
84 13.6211 L 10.\
1719 14.3281 L 1\
3 11.5 L 10.1719\
 8.67187 L 9.464\
84 9.37891 L 11.\
0859 11 L 7 11 L\
 7 12 Z M 4 13 L\
 4 3 L 9 3 L 9 6\
 L 12 6 L 12 9 L\
 13 9 L 13 5 L 1\
0 2 L 3 2 L 3 14\
 L 8 14 L 8 13 L\
 4 13 Z\x22/>\x0a</svg\
>\x0a\
\x00\x00\x02]\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 6 2 L 6 3 L 6 \
6 L 7 6 L 7 3 L \
9 3 L 9 6 L 10 6\
 L 10 3 L 10 2 L\
 9 2 L 7 2 L 6 2\
 z M 3.8046875 6\
 L 3 6.8320312 L\
 8 12 L 13 6.832\
0312 L 12.195312\
 6 L 8 10.337891\
 L 3.8046875 6 z\
 M 2 12 L 2 14 L\
 3 14 L 13 14 L \
14 14 L 14 13 L \
14 12 L 13 12 L \
13 13 L 3 13 L 3\
 12 L 2 12 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02\x16\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
2 L 6 12 L 6 14 \
L 14 14 L 14 7 L\
 11 4 L 10 4 L 8\
 2 L 3 2 Z M 4 3\
 L 7 3 L 7 4 L 6\
 4 L 6 11 L 4 11\
 L 4 3 Z M 7 5 L\
 10 5 L 10 8 L 1\
3 8 L 13 13 L 7 \
13 L 7 5 Z\x22/>\x0a</\
svg>\x0a\
\x00\x00\x01\xee\
<\
svg version=\x221.1\
\x22 viewBox=\x220 0 1\
6 16\x22 xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a    <s\
tyle id=\x22current\
-color-scheme\x22 t\
ype=\x22text/css\x22>\x0a\
        .ColorSc\
heme-Text {\x0a    \
        color:#2\
32629;\x0a        }\
\x0a    </style>\x0a  \
  <path class=\x22C\
olorScheme-Text\x22\
 d=\x22m6.3828 2-4.\
3828 11h1.3574l1\
.1895-3h6.3262l-\
3.1875-8h-1.3027\
zm0.62305 1.3281\
 2.1211 5.6719h-\
4.1855l2.0645-5.\
6719zm7.6836 5.4\
355-3.3574 3.779\
3-1.625-1.625-0.\
70703 0.70703 2.\
375 2.375 4.0234\
-4.5273-0.70898-\
0.70898z\x22 style=\
\x22fill:currentCol\
or\x22/>\x0a</svg>\x0a\
\x00\x00\x01\xea\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 7 3.0058594 L \
7 8 L 2 8 L 2 8.\
9980469 L 7 8.99\
80469 L 7 14.007\
812 L 8 14.00781\
2 L 8 8.9980469 \
L 13 8.9980469 L\
 13 8 L 8 8 L 8 \
3.0058594 L 7 3.\
0058594 z \x22\x0a    \
 class=\x22ColorSch\
eme-Text\x22\x0a     /\
>\x0a</svg>\x0a\
\x00\x00\x01R\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a       style=\
\x22fill:#da4453\x22\x0a \
      d=\x22m 7,2 0\
,8 2,0 0,-8 -2,0\
 z m 0,10 0,2 2,\
0 0,-2 -2,0 z\x22 \x0a\
       />\x0a</svg>\
\x0a\
\x00\x00\x0a(\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a\x0a<!-- Crea\
ted with Inkscap\
e (http://www.in\
kscape.org/) -->\
\x0a<svg width=\x2232\x22\
 version=\x221.1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 height=\x2232\x22 xm\
lns:xlink=\x22http:\
//www.w3.org/199\
9/xlink\x22 xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22>\x0a <defs id\
=\x22defs5455\x22>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4143\x22\
>\x0a   <stop style\
=\x22stop-color:#19\
7cf1\x22 id=\x22stop41\
45\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-color:#20b\
cfa\x22 id=\x22stop414\
7\x22/>\x0a  </linearG\
radient>\x0a  <line\
arGradient inksc\
ape:collect=\x22alw\
ays\x22 xlink:href=\
\x22#linearGradient\
4143\x22 id=\x22linear\
Gradient4149\x22 y1\
=\x22545.79797\x22 y2=\
\x22517.79797\x22 x2=\x22\
0\x22 gradientUnits\
=\x22userSpaceOnUse\
\x22 gradientTransf\
orm=\x22matrix(0.92\
857108 0 0 0.928\
57057 28.612354 \
37.986142)\x22/>\x0a  \
<linearGradient \
inkscape:collect\
=\x22always\x22 id=\x22li\
nearGradient4290\
\x22>\x0a   <stop styl\
e=\x22stop-color:#7\
cbaf8\x22 id=\x22stop4\
292\x22/>\x0a   <stop \
offset=\x221\x22 style\
=\x22stop-color:#f4\
fcff\x22 id=\x22stop42\
94\x22/>\x0a  </linear\
Gradient>\x0a  <lin\
earGradient inks\
cape:collect=\x22al\
ways\x22 xlink:href\
=\x22#linearGradien\
t4290\x22 id=\x22linea\
rGradient4144\x22 y\
1=\x2229.999973\x22 y2\
=\x222\x22 x2=\x220\x22 grad\
ientUnits=\x22userS\
paceOnUse\x22/>\x0a  <\
linearGradient i\
nkscape:collect=\
\x22always\x22 id=\x22lin\
earGradient4227\x22\
>\x0a   <stop style\
=\x22stop-color:#29\
2c2f\x22 id=\x22stop42\
29\x22/>\x0a   <stop o\
ffset=\x221\x22 style=\
\x22stop-opacity:0\x22\
 id=\x22stop4231\x22/>\
\x0a  </linearGradi\
ent>\x0a  <linearGr\
adient inkscape:\
collect=\x22always\x22\
 xlink:href=\x22#li\
nearGradient4227\
\x22 id=\x22linearGrad\
ient4191\x22 y1=\x229\x22\
 x1=\x229.00001\x22 y2\
=\x2223\x22 x2=\x2223.000\
04\x22 gradientUnit\
s=\x22userSpaceOnUs\
e\x22/>\x0a </defs>\x0a <\
metadata id=\x22met\
adata5458\x22/>\x0a <g\
 inkscape:label=\
\x22Capa 1\x22 inkscap\
e:groupmode=\x22lay\
er\x22 id=\x22layer1\x22 \
transform=\x22matri\
x(1 0 0 1 -384.5\
7143 -515.798)\x22>\
\x0a  <rect width=\x22\
26\x22 x=\x22387.57144\
\x22 y=\x22518.79797\x22 \
rx=\x2212.999993\x22 h\
eight=\x2226\x22 style\
=\x22fill:url(#line\
arGradient4149)\x22\
 id=\x22rect4130\x22/>\
\x0a  <path style=\x22\
fill:url(#linear\
Gradient4191);op\
acity:0.2;fill-r\
ule:evenodd\x22 id=\
\x22path4184\x22 d=\x22M \
17 9 L 15 11 L 1\
7 13 L 15 23 L 2\
3 31 L 26 31 L 2\
9 31 L 31 31 L 3\
1 27 L 31 23 L 1\
7 9 z \x22 transfor\
m=\x22matrix(1 0 0 \
1 384.57143 515.\
798)\x22/>\x0a  <path \
inkscape:connect\
or-curvature=\x220\x22\
 style=\x22fill:url\
(#linearGradient\
4144)\x22 id=\x22rect4\
133\x22 d=\x22M 16,2 C\
 8.4128491,2 2.2\
891329,7.9794391\
 2.0253906,15.5 \
2.0195214,15.667\
36 2,15.831158 2\
,16 c 0,7.756003\
 6.2439968,14 14\
,14 7.756003,0 1\
4,-6.243997 14,-\
14 0,-0.168842 -\
0.01952,-0.33264\
 -0.02539,-0.5 C\
 29.710867,7.979\
4391 23.587151,2\
 16,2 Z m 0,1 C \
23.201993,3 29,8\
.7980074 29,16 2\
9,23.201993 23.2\
01993,29 16,29 8\
.7980074,29 3,23\
.201993 3,16 3,8\
.7980074 8.79800\
74,3 16,3 Z m -1\
,6 0,2 2,0 0,-2 \
z m 0,4 0,10 2,0\
 0,-10 z\x22 transf\
orm=\x22matrix(1 0 \
0 1 384.57143 51\
5.798)\x22/>\x0a </g>\x0a\
</svg>\x0a\
\x00\x00\x02&\
<\
svg viewBox=\x220 0\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style\x0a        t\
ype=\x22text/css\x22\x0a \
       id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-NegativeT\
ext {\x0a          \
  color:#da4453;\
\x0a        }\x0a    <\
/style>\x0a    <pat\
h d=\x22M16 4A12 12\
 0 0 0 4 16a12 1\
2 0 0 0 12 12 12\
 12 0 0 0 12-12A\
12 12 0 0 0 16 4\
m-5.293 6L16 15.\
293 21.293 10s.7\
27.716.707.707L1\
6.707 16 22 21.2\
93s-.701.706-.70\
7.707L16 16.707 \
10.707 22c.001-.\
005-.707-.707-.7\
07-.707L15.293 1\
6 10 10.707c.02.\
001.707-.707.707\
-.707\x22 class=\x22Co\
lorScheme-Negati\
veText\x22 fill=\x22cu\
rrentColor\x22/>\x0a</\
svg>\x0a\
\x00\x00\x05k\
(\
\xb5/\xfd`=\x1f\x0d+\x00f\xb7\xa2#\x00q\xf4\
\x95\x5c\xa8x\xe8\x81\x85\xb0\xf6\xa0\x1e7;\xca\xf9\x87\
U(\xa4i\x9a\xdc\xc9\xbbg\xe1L\xfa\xff\xab?\xbc\
\xa3\x00\x99\x00\x8e\x00wBM\x8f\x03g\xe6l\x8d\x09\
\xe3.\x80\x0cj\xbap`\xec\xc00\xe1\xf0\xbf\xfb\xe6\
\xbb\xf5\xe4q\xc0\x1e\x5c\xbe\x9c9\x96I\xa1\xa2\xa1\xc7\
\x9c\x0c}\x86\x04E\x16G\xe3\xee\xafY\xee\x96.U\
k\xef5\xcf\x1bk\xed\xc3\x8a\xabT*O\xa6\x02*\
\xa9\x92\xa6\xc9d\xc2z\x03\xdaWS\x18\xb3\xe6\xdd7\
\xd5\x96\xf4DG\xba\xc1\xb9\x89P\x93\x8b(\x0dJ\xd3\
8({K\x98\x83\xb3\xa3\x92\xd6Z\x00\x91\x8d\xea\x01\
p\x80\xc0&\x899Z\x9a\xa2\x9b\xa5\xbb\xab\xc5js\
\xa8\xb0`ND\x82\xf2\x84%\xbd\x98\xbbg\x8e4A\
\x15\xa57V4\xb1 <\x02\xb2f\xfcd\xf6\x1e:\
g\xce\xd6\xd5\xf3L\x11Bw\x8c\x1f\x070\x87\x9a\xa2\
\x097\xca\xb4+\xa6+\x0bIB\xe3K\xa1\xa0tU\
mH\xb2\x88T\x7fT\xba\xf8\xa2\xc5\xc2W\x1d|\x92\
9\x7f\x81[\xd2P\xbe\xd4\x03uuk-\xe2\xdb7\
_\xb8Z\xea,\x94\x0b\xc6\xa7\xd2U\x8f\x10\xb81_\
2\xbf\xbaO\xf8\x8e\xae\xf9\xcd\xd7\xb3\x16\xce\xeaj\xc3\
u\xc5\x07A\xe0\x01\x03\xccy$\xfbRj\xf5\xe8\xdc\
4\xcd\xe3@G\x1bj\x16\x83D\x11\xb4)\x1ah\x82\
\xb3\xc6\x94\xc6TiJS.\xbby\x14\xe8\xc8\x9d@\
\x07;\x0c\x85\xb3B\xe7\xccV\x08#\xef\xab\x8b\xd0~\
c\x1e\x94N}\xba\xd8\x18i\x9f32>\x84\xb4\xba\
\x1f\xb0@\xd4\xbe\x13\xe6T\xd2\xa5v\xa4ztn\x1e\
u~\xb4\xf0=\x9a\x9282\xbcFH\xfd\xc1\xa9e\
\xd5\xef\xb0j\xf8\xf4S\xfd\x15Gm\xe9O\xf9R?\
\x0b\x7f\xe2'>5^\x09\x1f\xcd\xd0b<uz\xbd\
bm\xeb\xb4XcP\x7frb\xe0\x5c\xdf!\xae\xf4\
\xbe\x9f\x8fAe\x9eV\xe2\x9a?SIi\xfd\xaa_\
|\xde<\x22|,\xdf\xbf\xea\xb8fI]\xfa3\x03\
\x00\x07\x91\x8d\xaay\xd0\xf7P\x1d \xb0!\xe2\x1f\x83\
}\xfa\x9c}\x95\xa9\xee\x9e~\x84N\xa9\x00\x81/\xa7\
\xa3\x942o\xa5\x83\xb1\xb5f\xa1\xc1\xff\xf3g\xfe\x1b\
\x13\xeb\xabOB\x8f\x0b\x06\x04\x8f*@dB\x84G\
K\xe9\xed1V\xf7\xb0\xba'\xbfEF\x9d;.\x1b\
\xc2\x972El\x85P\xca\xf8\xf2\xb6\xa25\x9f\x99\xbf\
\x9cYxQ\x97\xcc\x9a8\x98\xa3\xa3\x8b\x9c\x11\xce\xda\
\xc8T8\xa0\xf7\x8dd\xa3@\x11\x86\xb8Hv\x86*\
L\xc0]\x12\x81\xb4\xe4m\x9dnZ\xca\xc0\xe9\x9em\
\x8d\x81\x12\xfa;\x0f\x81K\xa8\xf1Dh\x10\x95\x88\x04\
\x91$I!\xc3\x01!\x11A\x8c9\xe8\xae\x03\xf2X\
\x0e\xc20\x8ae \x88A\x18\x84\x08\x88\xc5\x14A\x02\
E\x04\x22\x222\x12\x8e\xa4\xd6\x01\x9a\x02\xfe\x89\x97\xdc\
y\x10}\xb3\xf7\xb6}`U^2\x17o\x16}6\
k\xe5\xd2\xea\xaf\x9c#\xfc\xf7\xc0)\xe2\xd9-\xc5'\
Y\x92)f\x81)\x83%k\x9c\x13\xdc\x06]\x1d\xa4\
\xc7\xf4/\xc2\x19\xf8[\xfcu\xaby'\xf8\x01\x92\xe0\
\xc36}\xd3`\xf3V1F\x5cO\xce\xe5\x82l\xcc\
\x06\xef\xac\x1c\x1fX\xc9\x0c\x96\xd3\xd7^\x83\x9c\x9dg\
E\x90\xa3\x19Q\xaay2lJ\xc6\xb5\x1c\x877\x87\
\x8e(\xda\x0e{^\x01\xefPF[n\x8f\x99\xae\xb9\
>gl\x07\x1e\xeaVu\x194\xe0\x100V`\x83\
\x03\xc4\xf1\x06\xd2G3\xba.\xad\xd6\xe2t\x5cW\x18\
\x1e\xc2\x04\xaa$L\x04\xa3-\xeaQ\xaf\xc1\x9dp\x81\
o\xa3\x95mv\xb4(\xa5}\xe4mv\xf0\x00rf\
\x8d\x04\x13\xbc\x96\xfe\x01\x89gG\xc3F\xd6\xf6b\x05\
\xf9\xfaf\xdb\xe3\x972\x80W\x1fi,+\x83\xc5\x0a\
\xbfD\xa0|J\xfe\xe8\x10\x8a'\xb2\xa5\x8ai\x0d\x19\
\xa7\xbc\xc2<\xa3NyN\x92\xdf\x90\xb3\x9c\xb9\x95b\
\xc4\xea:\x83\xebR`8\x052Y\x92\xc6\x98\x98s\
\x0a\x81\x19q\xa5\x19\xecP\xab\xcbC\x8f(\x10\xf9\xe8\
,gKar\xfa\x95\xc5\xc9S\x8bU\x04\x05\x81d\
\xba\xe0\xb0\x0a\x22\x01L\x1c\x09\xe5e\xc9\xb4\xb1\x05\xf7\
\xe3\x09\x80WQ_Z\xcaW\xd6>\xa4\xd1\xd3\xf1\x0c\
\xf0}xH\xe4\x8a\xdfg\xdb%hx\xb6\x0c\x0f7\
\x11\x17\x97_\xe5L\xa2\xe8\xe1$\xb4\xaaP\xb5\x85\x84\
\x16<\xc7\xec\xb4k\x0a\xd8\xe1\xa3H\xc9\x90\xcf\x97\xa3\
\xfb\x92\xaa\x8bN\x89l\xdb\xd2a\xb70\x02S\xe9T\
\xa6\xc4\xf50\xa8\xb4F\xb9,\xb7Uu\x88\x84^\xce\
\x99\xc2\x94Ss6+\xa8\xbe\xe4\x92\xdctA\xc0T\
\x16\x84\xa5v\xd7\xbcE\xf8\x8c4\xf7N)\xdb'Y\
\x96\x98\xde\xa72r\xa7\xceN\x1a\xc3\xd2\xf1\x0b\xd7\x83\
\x08\xdai\xcb\x12\xd7\xc8K1\x08\x12Gi\xa21\xd1\
\xef_\x1bW\x0d>$\xb4\xf9\xe7\x02.\x0cR\xf3V\
MP\x86\xca\xf0U6\x08\x9e&\x9a\xa4I/7\xa3\
\xc3\xee\xc3\xea\x00\x9b\x84\x85m\xe6\x1a\x9cR\xd3x\xe6\
J\xcf\x1f^}\x8c{\xe1*\xab\x18<\x7f\xa2\xdc\x0e\
\x06)\x8b\xcc\x83b\xa3\x91\xea#\x0e\x04\xdb\x90=\xbd\
\x07t\x1aJ\xe7\x92C\x0d\xferc\x917Jm\x5c\
\xdd\xb8g\xd5L4r\x1dT\x9b\xe9\x5c]\xddv\x04\
k\xe6\xde\x8a\x91O\x04\xb07\xc0\x0b\x12\xdcv\xa7\xa6\
\xca\xd3\x05\x8c\xad\x1b~f\xe7\x05eP\x90\xa8#3\
\x0a%\xca\x8e89\xd4)\x10\x9f\x9e\x8a\xb6/>\xd3\
\x04\x9d\x9e\x0b\xbe\xcc,\x0f\x8c\x14t,\xf5\xc2\xdfw\
wd>H\xb8\xfa@\x91\xa9\x02\
\x00\x00\x02\xd8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M18.5 6A3.5 \
3.5 0 0 0 15.041\
02 9H4V10H15.04A\
3.5 3.5 0 0 0 18\
.5 13 3.5 3.5 0 \
0 0 21.958984 10\
H28V9H21.961A3.5\
 3.5 0 0 0 18.5 \
6M7.5 19A3.5 3.5\
 0 0 0 4 22.5 3.\
5 3.5 0 0 0 7.5 \
26 3.5 3.5 0 0 0\
 10.960938 23H28\
V22H10.959A3.5 3\
.5 0 0 0 7.5 19m\
0 1A2.5 2.5 0 0 \
1 10 22.5 2.5 2.\
5 0 0 1 7.5 25 2\
.5 2.5 0 0 1 5 2\
2.5 2.5 2.5 0 0 \
1 7.5 20\x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x09\xce\
<\
svg viewBox=\x220 0\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22 xmlns\
:xlink=\x22http://w\
ww.w3.org/1999/x\
link\x22><radialGra\
dient id=\x22a\x22 cx=\
\x229.875001\x22 cy=\x221\
5.125\x22 gradientT\
ransform=\x22matrix\
(0 2.1428571 -2.\
1428571 0 42.410\
717 -11.160717)\x22\
 gradientUnits=\x22\
userSpaceOnUse\x22 \
r=\x2214\x22><stop off\
set=\x220\x22 stop-col\
or=\x22#fc9\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#feb01b\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22b\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410717\
 -11.160717)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#f9917f\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#fa3033\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22c\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410717\
 -11.160717)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#7dd89b\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#0ddb6e\x22\
/></radialGradie\
nt><radialGradie\
nt id=\x22d\x22 cx=\x229.\
875001\x22 cy=\x2215.1\
25\x22 gradientTran\
sform=\x22matrix(0 \
2.1428571 -2.142\
8571 0 42.410716\
 -10.160716)\x22 gr\
adientUnits=\x22use\
rSpaceOnUse\x22 r=\x22\
14\x22><stop offset\
=\x220\x22 stop-color=\
\x22#81c6d6\x22/><stop\
 offset=\x221\x22 stop\
-color=\x22#279dd8\x22\
/></radialGradie\
nt><g stroke-lin\
ejoin=\x22round\x22 tr\
ansform=\x22matrix(\
1 0 0 .97753584 \
0 .35179)\x22><path\
 d=\x22m16 2c-7.731\
9865 0-14 6.2680\
135-14 14 .00046\
75 5.001251 2.66\
87898 9.622422 7\
 12.123047l7.000\
25-11.123495 7-1\
2.123047-.00025-\
.999552c-2.12814\
2-1.229214-4.542\
368-1.8765552-7-\
1.876953z\x22 fill=\
\x22url(#c)\x22/><path\
 d=\x22m3.8769531 9\
c-1.229214 2.128\
142-1.8765552 4.\
542368-1.8769531\
 7 0 7.731986 6.\
2680135 14 14 14\
 4.727485-.00044\
2 9.115362-2.384\
659 11.693622-6.\
303849.0184-.036\
29-.02708-.95997\
7-.02708-.959977\
z\x22 fill=\x22url(#b)\
\x22/><path d=\x22m12.\
376953 2.4785156\
a14 14 0 0 0 -10\
.376953 13.52148\
44 14 14 0 0 0 1\
4 14 14 14 0 0 0\
 3.623047-.47851\
6z\x22 fill=\x22url(#a\
)\x22/><path d=\x22m24\
.660156 5-5.9296\
87 10.269531v1l1\
0.267578 5.92773\
5c.661413-1.6529\
54 1.001473-3.41\
6895 1.001953-5.\
197266v-1c-.0000\
24-4.291269-1.96\
8109-8.345496-5.\
339844-11z\x22 fill\
=\x22url(#d)\x22/><pat\
h d=\x22m23 3.87695\
31-7 12.1230469.\
433594.25 6.5664\
06-11.3730469zm-\
4.269531 11.3925\
779v1l10.267578 \
5.927735c.661413\
-1.652954 1.0014\
73-3.416895 1.00\
1953-5.197266-.0\
00001-.153617-.0\
2037-.304075-.02\
539-.457031-.062\
49 1.594793-.382\
645 3.170022-.97\
6562 4.654297zm-\
16.710938.261719\
c-.00605.16139-.\
0093.322872-.009\
77.484375 0 7.73\
1986 6.2680128 1\
4 14.000001 14 5\
.187498 0 9.5315\
54-2.900934 11.7\
0226-6.355763l-.\
0184.03629-.0270\
8-.959977c-2.521\
952 3.714717-6.8\
47794 6.278974-1\
1.656776 6.27945\
-7.5312342-.0001\
44-13.712857-5.9\
58252-13.990235-\
13.484375z\x22 fill\
-opacity=\x22.14902\
\x22/></g></svg>\
\x00\x00\x02b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h \x0a    style=\x22fi\
ll:currentColor;\
fill-opacity:1;s\
troke:none\x22 \x0a\x09d=\
\x22M 4 4 L 4 8 L 5\
 8 L 5 5 L 8 5 L\
 8 4 L 4 4 z M 2\
4 4 L 24 5 L 27 \
5 L 27 8 L 28 8 \
L 28 4 L 24 4 z \
M 6 6 L 6 26 L 2\
6 26 L 26 6 L 6 \
6 z M 7 7 L 25 7\
 L 25 25 L 7 25 \
L 7 7 z M 4 24 L\
 4 28 L 8 28 L 8\
 27 L 5 27 L 5 2\
4 L 4 24 z M 27 \
24 L 27 27 L 24 \
27 L 24 28 L 28 \
28 L 28 24 L 27 \
24 z \x22\x0a\x09class=\x22C\
olorScheme-Text\x22\
\x0a    />  \x0a</svg>\
\x0a\
\x00\x00\x04^\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 4 4 L\
 4 28 L 15 28 L \
15 27 L 10 27 L \
10 20 L 18 20 L \
18 19 L 9 19 L 9\
 27 L 5 27 L 5 5\
 L 10 5 L 10 13 \
L 21 13 L 21 5 L\
 21.585938 5 L 2\
7 10.414062 L 27\
 16 L 28 16 L 28\
 10 L 22 4 L 10 \
4 L 4 4 z M 11 5\
 L 17 5 L 17 12 \
L 11 12 L 11 5 z\
 M 24.398438 16 \
L 19.287109 21.1\
11328 L 16 24.39\
8438 L 16 28 L 1\
9.601562 28 L 28\
 19.601562 L 24.\
398438 16 z M 22\
.349609 19.49023\
4 L 24.509766 21\
.650391 L 21.335\
938 24.824219 L \
21.335938 24.150\
391 L 20.322266 \
24.173828 L 19.2\
87109 24.173828 \
L 19.287109 23.1\
36719 L 19.28710\
9 22.552734 L 22\
.349609 19.49023\
4 z M 18.273438 \
23.564453 L 18.2\
73438 25.185547 \
L 20.300781 25.1\
85547 L 20.32226\
6 25.839844 L 19\
.240234 26.91992\
2 L 17.800781 26\
.919922 L 17.080\
078 26.199219 L \
17.080078 24.757\
812 L 18.273438 \
23.564453 z \x22\x0a  \
   id=\x22path76\x22 \x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x05\x9d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     class=\x22\
ColorScheme-High\
light\x22\x0a     />\x0a \
<path \x0a     styl\
e=\x22fill-opacity:\
0.33;fill-rule:e\
venodd\x22\x0a     d=\x22\
m 2,3 0,7 9,0 L \
13,8 30,8 30,5 1\
6,5 14,3 2,3 Z\x22\x0a\
     />\x0a <path \x0a\
     style=\x22fill\
:#ffffff;fill-op\
acity:0.2;fill-r\
ule:evenodd\x22\x0a   \
  d=\x22M 14 3 L 15\
 6 L 30 6 L 30 5\
 L 16 5 L 14 3 z\
 M 13 8 L 11 10 \
L 1 10 L 1 11 L \
12 11 L 13 8 z \x22\
\x0a     />\x0a <path \
\x0a     style=\x22fil\
l-opacity:0.2;fi\
ll-rule:evenodd\x22\
\x0a     d=\x22M 13 8 \
L 11 9 L 2 9 L 2\
 10 L 11 10 L 13\
 8 z M 1 28 L 1 \
29 L 31 29 L 31 \
28 L 1 28 z \x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a <path \x0a    \
 style=\x22fill:cur\
rentColor;fill-o\
pacity:0.6;strok\
e:none\x22 \x0a     d=\
\x22M 22,14 15,14.0\
04 12.559,20.695\
 11.004,18 h -1 \
v 1 h 0.428 l 2.\
133,3.693 3.02,-\
7.693 h 6.42 z m\
 -4,2 c -1.662,0\
 -3,1.338 -3,3 0\
,1.662 1.338,3 3\
,3 0.773,0 1.469\
,-0.298 2,-0.775\
 V 22 h 1 v -6 h\
 -1 v 0.775 C 19\
.469,16.298 18.7\
73,16 18,16 m 0,\
1 c 1.108,0 2,0.\
892 2,2 0,1.108 \
-0.892,2 -2,2 -1\
.108,0 -2,-0.892\
 -2,-2 0,-1.108 \
0.892,-2 2,-2\x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x05\xac\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:currentColor;f\
ill-opacity:1;st\
roke:none\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     class=\x22\
ColorScheme-High\
light\x22\x0a     />\x0a \
<path \x0a     styl\
e=\x22fill-opacity:\
0.33;fill-rule:e\
venodd\x22\x0a     d=\x22\
m 2,3 0,7 9,0 L \
13,8 30,8 30,5 1\
6,5 14,3 2,3 Z\x22\x0a\
     />\x0a <path \x0a\
     style=\x22fill\
:#ffffff;fill-op\
acity:0.2;fill-r\
ule:evenodd\x22\x0a   \
  d=\x22M 14 3 L 15\
 6 L 30 6 L 30 5\
 L 16 5 L 14 3 z\
 M 13 8 L 11 10 \
L 1 10 L 1 11 L \
12 11 L 13 8 z \x22\
\x0a     />\x0a <path \
\x0a     style=\x22fil\
l-opacity:0.2;fi\
ll-rule:evenodd\x22\
\x0a     d=\x22M 13 8 \
L 11 9 L 2 9 L 2\
 10 L 11 10 L 13\
 8 z M 1 28 L 1 \
29 L 31 29 L 31 \
28 L 1 28 z \x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a <path \x0a    \
 style=\x22fill:cur\
rentColor;fill-o\
pacity:0.6;strok\
e:none\x22 \x0a     d=\
\x22m 16.00143,12 a\
 6,2 0 0 0 -6,2 \
v 8 a 6,2 0 0 0 \
6,2 6,2 0 0 0 6,\
-2 v -8 a 6,2 0 \
0 0 -6,-2 m 0,1 \
a 5,1 0 0 1 5,1 \
5,1 0 0 1 -5,1 5\
,1 0 0 1 -5,-1 5\
,1 0 0 1 5,-1 m \
-5,2.10156 a 6,2\
 0 0 0 5,0.89844\
 6,2 0 0 0 5,-0.\
89648 v 2.896 a \
5,1 0 0 1 -5,1 5\
,1 0 0 1 -5,-1 z\
 m 0,4 a 6,2 0 0\
 0 5,0.89844 6,2\
 0 0 0 5,-0.8964\
8 v 2.896 a 5,1 \
0 0 1 -5,1 5,1 0\
 0 1 -5,-1 z\x22\x0a  \
   class=\x22ColorS\
cheme-Text\x22\x0a    \
 />\x0a</svg>\x0a\
\x00\x00\x02\x99\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 4 4 L\
 4 28 L 9 28 L 2\
3 28 L 28 28 L 2\
8 10 L 27 9 L 23\
 5 L 22 4 L 21 4\
 L 10 4 L 4 4 z \
M 5 5 L 10 5 L 1\
0 13 L 21 13 L 2\
1 5 L 21.585938 \
5 L 27 10.414062\
 L 27 27 L 23 27\
 L 23 19 L 9 19 \
L 9 27 L 5 27 L \
5 5 z M 11 5 L 1\
7 5 L 17 12 L 11\
 12 L 11 5 z M 1\
0 20 L 22 20 L 2\
2 27 L 10 27 L 1\
0 20 z \x22\x0a     id\
=\x22path60\x22 \x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a</svg>\x0a\
\x00\x00\x02\xc6\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 32 32\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <style i\
d=\x22current-color\
-scheme\x22 type=\x22t\
ext/css\x22>.ColorS\
cheme-Text {\x0a   \
         color:#\
232629;\x0a        \
}</style>\x0a    <r\
ect id=\x22rect837\x22\
 class=\x22ColorSch\
eme-Text\x22 x=\x225\x22 \
y=\x224\x22 width=\x221\x22 \
height=\x229\x22 fill=\
\x22currentColor\x22 f\
ill-rule=\x22evenod\
d\x22/>\x0a    <path i\
d=\x22path840\x22 clas\
s=\x22ColorScheme-T\
ext\x22 d=\x22m11.5 3.\
7929688-0.353516\
 0.3535156-4.353\
5152 4.3535156 4\
.3535152 4.35351\
6 0.353516 0.353\
515 0.707031-0.7\
07031-0.353515-0\
.353516-3.146484\
8-3.146484h8.292\
9688c4.986 0 9 4\
.014 9 9s-4.014 \
9-9 9h-1v1h1c5.5\
4 0 10-4.46 10-1\
0s-4.46-10-10-10\
h-8.2929688l3.14\
64848-3.1464844 \
0.353515-0.35351\
56-0.707031-0.70\
70312z\x22 fill=\x22cu\
rrentColor\x22/>\x0a</\
svg>\x0a\
\x00\x00\x02\xc1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 6 4 L 6 28 L 1\
3 28 L 13 27 L 7\
 27 L 7 5 L 18 5\
 L 18 12 L 25 12\
 L 25 16 L 26 16\
 L 26 11 L 19 4 \
L 18 4 L 6 4 z M\
 14 16 L 14 17 L\
 14 20 L 14 21 L\
 14 27 L 14 28 L\
 26 28 L 26 27 L\
 26 20 L 26 19 L\
 26 18 L 21 18 L\
 19 16 L 19 16 L\
 19 16 L 15 16 L\
 14 16 z M 15 17\
 L 18.6 17 L 19.\
6 18 L 19 18 L 1\
9 18 L 19 18 L 1\
7 20 L 15 20 L 1\
5 17 z M 15 21 L\
 25 21 L 25 27 L\
 15 27 L 15 21 z\
 \x22\x0a     class=\x22C\
olorScheme-Text\x22\
\x0a     />\x0a</svg>\x0a\
\
\x00\x00\x034\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs\x0a     id=\x22def\
s3051\x22>\x0a    <sty\
le\x0a       type=\x22\
text/css\x22\x0a      \
 id=\x22current-col\
or-scheme\x22>\x0a    \
  .ColorScheme-T\
ext {\x0a        co\
lor:#232629;\x0a   \
   }\x0a      </sty\
le>\x0a  </defs>\x0a  \
<path\x0a     style\
=\x22fill:currentCo\
lor;fill-opacity\
:1;stroke:none\x22 \
\x0a     d=\x22M 6.292\
9688 4 L 5 5.292\
9688 L 5 7.83203\
12 C 5.055 7.872\
0313 13 18.5 13 \
18.5 L 13 23.509\
766 L 19 28.0117\
19 L 19 18.50195\
3 L 27 7.8339844\
 L 27 5.2949219 \
L 25.707031 4.00\
19531 L 6.292968\
8 4 z M 6.707031\
2 5 L 25.292969 \
5 L 26 5.7070312\
 L 26 7.5019531 \
L 18 18.167969 L\
 18 26.009766 C \
16.84 25.142766 \
15.285 23.975766\
 14 23.009766 L \
14 18.167969 L 6\
 7.5019531 L 6 5\
.7070312 L 6.707\
0312 5 z M 7 6 L\
 12 12.5 C 11.98\
5 12.505 12 9 12\
 9 L 15 6 L 7 6 \
z \x22\x0a     id=\x22pat\
h64\x22 \x0a     class\
=\x22ColorScheme-Te\
xt\x22\x0a     />\x0a</sv\
g>\x0a\
\x00\x00\x02]\
<\
!DOCTYPE svg>\x0a<s\
vg version=\x221.1\x22\
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22 viewBox=\x220 0\
 32 32\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 7 5 L 18 \
5 L 18 12 L 25 1\
2 L 25 19 L 26 1\
9 L 26 11 L 19 4\
 L 6 4 L 6 28 L \
19 28 L 19 27 L \
7 27 L 7 5 Z M 1\
6.9961 22.5 L 16\
.9961 23.5 L 25.\
0859 23.5 L 21.2\
93 27.293 L 22 2\
8 L 27 23 L 22 1\
8 L 21.293 18.70\
7 L 25.0859 22.5\
 L 16.9961 22.5 \
Z\x22/>\x0a</svg>\x0a\
\x00\x00\x04\xca\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 32 32\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#31363b;\x0a      \
}\x0a      .ColorSc\
heme-Highlight {\
\x0a        color:#\
3daee9;\x0a      }\x0a\
      </style>\x0a \
 </defs>\x0a <path \
\x0a     style=\x22fil\
l:#eb0a42\x22 \x0a    \
 d=\x22M 2 3 L 2 10\
 L 1 10 L 1 29 L\
 12 29 L 13 29 L\
 31 29 L 31 8 L \
30 8 L 30 5 L 16\
 5 L 14 3 L 2 3 \
z \x22\x0a     />\x0a <pa\
th \x0a     style=\x22\
fill-opacity:0.3\
3;fill-rule:even\
odd\x22\x0a     d=\x22m 2\
,3 0,7 9,0 L 13,\
8 30,8 30,5 16,5\
 14,3 2,3 Z\x22\x0a   \
  />\x0a <path \x0a   \
  style=\x22fill:#f\
fffff;fill-opaci\
ty:0.2;fill-rule\
:evenodd\x22\x0a     d\
=\x22M 14 3 L 15 6 \
L 30 6 L 30 5 L \
16 5 L 14 3 z M \
13 8 L 11 10 L 1\
 10 L 1 11 L 12 \
11 L 13 8 z \x22\x0a  \
   />\x0a <path \x0a  \
   style=\x22fill-o\
pacity:0.2;fill-\
rule:evenodd\x22\x0a  \
   d=\x22M 13 8 L 1\
1 9 L 2 9 L 2 10\
 L 11 10 L 13 8 \
z M 1 28 L 1 29 \
L 31 29 L 31 28 \
L 1 28 z \x22\x0a     \
class=\x22ColorSche\
me-Text\x22\x0a     />\
\x0a <path \x0a     st\
yle=\x22fill:curren\
tColor;fill-opac\
ity:0.6;stroke:n\
one\x22 \x0a     d=\x22M \
16 13 C 15.4 13 \
15 13.4 15 14 C \
15 14.5 15.4 20 \
16 20 C 16.5 20 \
17 14.5 17 14 C \
17 13.4 16.5 13 \
16 13 z M 16 21 \
A 1 1 0 0 0 15 2\
2 A 1 1 0 0 0 16\
 23 A 1 1 0 0 0 \
17 22 A 1 1 0 0 \
0 16 21 z \x22\x0a    \
 class=\x22ColorSch\
eme-Text\x22\x0a     /\
>\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00zi|\
\x00s\
\x00p\x00c\x00a\x00l\
\x00\x07\
\x06\x9bfR\
\x003\
\x002\x00x\x003\x002\x00@\x002\
\x00\x05\
\x004\xdbF\
\x001\
\x006\x00x\x001\x006\
\x00\x05\
\x005\xbbT\
\x002\
\x004\x00x\x002\x004\
\x00\x07\
\x04\xdbJR\
\x001\
\x006\x00x\x001\x006\x00@\x002\
\x00\x05\
\x006\x9bb\
\x003\
\x002\x00x\x003\x002\
\x00\x0b\
\x0b\xba\x81\xb5\
\x00i\
\x00n\x00d\x00e\x00x\x00.\x00t\x00h\x00e\x00m\x00e\
\x00\x07\
\x05\xbbXR\
\x002\
\x004\x00x\x002\x004\x00@\x002\
\x00\x19\
\x0f#W\x87\
\x00f\
\x00o\x00r\x00m\x00a\x00t\x00-\x00p\x00r\x00e\x00c\x00i\x00s\x00i\x00o\x00n\x00-\
\x00m\x00o\x00r\x00e\x00.\x00s\x00v\x00g\
\x00\x1a\
\x04\x9e\xca\x87\
\x00i\
\x00n\x00s\x00e\x00r\x00t\x00-\x00m\x00a\x00t\x00h\x00-\x00e\x00x\x00p\x00r\x00e\
\x00s\x00s\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x18\
\x00\x8c5\xa7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00o\x00p\x00e\x00n\x00-\x00r\x00e\x00c\
\x00e\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0e\xa1.G\
\x00h\
\x00e\x00l\x00p\x00-\x00a\x00b\x00o\x00u\x00t\x00.\x00s\x00v\x00g\
\x00%\
\x01\x93x\xa7\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00a\x00r\x00e\x00a\
\x00-\x00f\x00o\x00c\x00u\x00s\x00-\x00p\x00e\x00a\x00k\x00-\x00n\x00o\x00d\x00e\
\x00.\x00s\x00v\x00g\
\x00\x10\
\x00G\xaf\x87\
\x00w\
\x00i\x00n\x00d\x00o\x00w\x00-\x00c\x00l\x00o\x00s\x00e\x00.\x00s\x00v\x00g\
\x00\x14\
\x04\x01oG\
\x00c\
\x00o\x00l\x00o\x00r\x00-\x00m\x00a\x00n\x00a\x00g\x00e\x00m\x00e\x00n\x00t\x00.\
\x00s\x00v\x00g\
\x00\x0d\
\x08Q\xc4\xa7\
\x00c\
\x00o\x00n\x00f\x00i\x00g\x00u\x00r\x00e\x00.\x00s\x00v\x00g\
\x00\x14\
\x06\x1b\x1eG\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00p\x00i\x00e\x00.\
\x00s\x00v\x00g\
\x00\x10\
\x03\x84Y\x07\
\x00c\
\x00l\x00o\x00u\x00d\x00-\x00u\x00p\x00l\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x16\
\x00;9\x87\
\x00e\
\x00d\x00i\x00t\x00-\x00c\x00l\x00e\x00a\x00r\x00-\x00h\x00i\x00s\x00t\x00o\x00r\
\x00y\x00.\x00s\x00v\x00g\
\x00\x0f\
\x04\x07vg\
\x00v\
\x00i\x00e\x00w\x00-\x00h\x00i\x00d\x00d\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x10\
\x0e\xe64\xc7\
\x00i\
\x00n\x00s\x00e\x00r\x00t\x00-\x00i\x00m\x00a\x00g\x00e\x00.\x00s\x00v\x00g\
\x00\x11\
\x0e\xab>\xc7\
\x00z\
\x00o\x00o\x00m\x00-\x00o\x00r\x00i\x00g\x00i\x00n\x00a\x00l\x00.\x00s\x00v\x00g\
\
\x00\x16\
\x0b\xee\xa6\xa7\
\x00d\
\x00i\x00a\x00l\x00o\x00g\x00-\x00i\x00n\x00f\x00o\x00r\x00m\x00a\x00t\x00i\x00o\
\x00n\x00.\x00s\x00v\x00g\
\x00\x14\
\x0b\xa9\xa6\xa7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00s\x00a\x00v\x00e\x00-\x00a\x00s\x00.\
\x00s\x00v\x00g\
\x00\x14\
\x02\x0a \xc7\
\x00f\
\x00o\x00l\x00d\x00e\x00r\x00-\x00c\x00a\x00l\x00c\x00u\x00l\x00a\x00t\x00e\x00.\
\x00s\x00v\x00g\
\x00\x13\
\x0aO\xa7\xe7\
\x00f\
\x00o\x00l\x00d\x00e\x00r\x00-\x00d\x00a\x00t\x00a\x00b\x00a\x00s\x00e\x00.\x00s\
\x00v\x00g\
\x00 \
\x0f\xe7G'\
\x00v\
\x00i\x00e\x00w\x00-\x00o\x00b\x00j\x00e\x00c\x00t\x00-\x00h\x00i\x00s\x00t\x00o\
\x00g\x00r\x00a\x00m\x00-\x00l\x00i\x00n\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00%\
\x0el\x0a\xe7\
\x00v\
\x00i\x00e\x00w\x00-\x00o\x00b\x00j\x00e\x00c\x00t\x00-\x00h\x00i\x00s\x00t\x00o\
\x00g\x00r\x00a\x00m\x00-\x00l\x00o\x00g\x00a\x00r\x00i\x00t\x00h\x00m\x00i\x00c\
\x00.\x00s\x00v\x00g\
\x00\x10\
\x0d\xa5v\x07\
\x00v\
\x00i\x00e\x00w\x00-\x00v\x00i\x00s\x00i\x00b\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x11\
\x0f\xe3\xd8\xe7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00s\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\
\x00\x0e\
\x0f\xc9\xd1\xa7\
\x00e\
\x00d\x00i\x00t\x00-\x00r\x00e\x00s\x00e\x00t\x00.\x00s\x00v\x00g\
\x00\x0f\
\x020\x86g\
\x00l\
\x00i\x00s\x00t\x00-\x00r\x00e\x00m\x00o\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x0d\
\x01\x1c\xbc'\
\x00e\
\x00d\x00i\x00t\x00-\x00c\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x11\
\x01\xa6\xc9\x07\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00o\x00p\x00e\x00n\x00.\x00s\x00v\x00g\
\
\x00\x0c\
\x07\xb1T\xa7\
\x00e\
\x00d\x00i\x00t\x00-\x00c\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x1d\
\x0e.\x06g\
\x00l\
\x00a\x00b\x00p\x00l\x00o\x00t\x00-\x00x\x00y\x00-\x00c\x00u\x00r\x00v\x00e\x00-\
\x00s\x00e\x00g\x00m\x00e\x00n\x00t\x00s\x00.\x00s\x00v\x00g\
\x00\x0f\
\x03\x83)G\
\x00v\
\x00i\x00e\x00w\x00-\x00f\x00i\x00l\x00t\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x18\
\x0eW\xb5'\
\x00o\
\x00f\x00f\x00i\x00c\x00e\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00s\x00c\x00a\x00t\
\x00t\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0c\xaa\xcd'\
\x00e\
\x00d\x00i\x00t\x00-\x00p\x00a\x00s\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x13\
\x01\x1b\xcag\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00e\x00x\x00p\x00o\x00r\x00t\x00.\x00s\
\x00v\x00g\
\x00\x14\
\x0el\xcf\xa7\
\x00l\
\x00a\x00b\x00p\x00l\x00o\x00t\x00-\x00x\x00y\x00-\x00c\x00u\x00r\x00v\x00e\x00.\
\x00s\x00v\x00g\
\x00\x12\
\x08\x97=G\
\x00c\
\x00l\x00o\x00u\x00d\x00-\x00d\x00o\x00w\x00n\x00l\x00o\x00a\x00d\x00.\x00s\x00v\
\x00g\
\x00\x15\
\x04\xbac\xe7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00-\x00m\x00u\x00l\x00t\x00i\x00p\x00l\x00e\
\x00.\x00s\x00v\x00g\
\x00\x0f\
\x03\xc3g\xa7\
\x00f\
\x00o\x00n\x00t\x00-\x00e\x00n\x00a\x00b\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09\xc6\x14\xa7\
\x00l\
\x00i\x00s\x00t\x00-\x00a\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x14\
\x0dQ*\xe7\
\x00s\
\x00k\x00g\x00-\x00c\x00h\x00a\x00r\x00t\x00-\x00b\x00u\x00b\x00b\x00l\x00e\x00.\
\x00s\x00v\x00g\
\x00\x14\
\x00r\xab\xe7\
\x00f\
\x00o\x00l\x00d\x00e\x00r\x00-\x00i\x00m\x00p\x00o\x00r\x00t\x00a\x00n\x00t\x00.\
\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x07\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x004\x00\x02\x00\x00\x00$\x00\x00\x00\x9a\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00D\x00\x02\x00\x00\x00'\x00\x00\x00s\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00h\x00\x02\x00\x00\x00\x0f\x00\x00\x00d\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00T\x00\x02\x00\x00\x00$\x00\x00\x00@\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x94\x00\x02\x00\x00\x00'\x00\x00\x00\x19\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00 \x00\x02\x00\x00\x00\x0f\x00\x00\x00\x0a\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00x\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x89\xcf\x0d\x07\xbc\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x02$n\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x02X\x93\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x02V2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x02P5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x02?}\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x02R\xfa\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x02&\x98\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x02.\xe3\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x02,\x07\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x02E\x1e\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x02;\x1b\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x02\x1aB\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x028\xb5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x02Mk\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x02J\xce\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x8a\x00\x00\x00\x00\x00\x01\x00\x00#\x04\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x00\x15\x1c\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x00|*\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x00\x09D\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x00g\xed\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x00Q\x10\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01r\x00\x00\x00\x00\x00\x01\x00\x00\x0e\x9d\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x00Sd\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x009\xbf\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xee\x00\x00\x00\x00\x00\x01\x00\x00Oj\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x00][\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x00 \x88\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xe8\x00\x00\x00\x00\x00\x01\x00\x00r\x9e\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x00\x174\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00'\xd4\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xe0\x00\x00\x00\x00\x00\x01\x00\x00\x068\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xb8\x00\x00\x00\x00\x00\x01\x00\x00pJ\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x00\x1e=\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05Z\x00\x00\x00\x00\x00\x01\x00\x00U\xe8\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x00\x1a\x80\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x8e\x00\x00\x00\x00\x00\x01\x00\x00m\xc5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07\x0c\x00\x00\x00\x00\x00\x01\x00\x00t\xdb\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x00=\x0d\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x004\xf3\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x002\xea\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x12\x00\x00\x00\x00\x00\x01\x00\x00e^\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07*\x00\x00\x00\x00\x00\x01\x00\x00v\xc5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04~\x00\x00\x00\x00\x00\x01\x00\x00E\x19\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05x\x00\x00\x00\x00\x00\x01\x00\x00Z\xde\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xdc\x00\x00\x00\x00\x00\x01\x00\x00`;\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x00B}\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06`\x00\x00\x00\x00\x00\x01\x00\x00jn\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x00\x0b\xee\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x0000\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xe0\x00\x00\x00\x00\x00\x01\x00\x00-2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xa8\x00\x00\x00\x00\x00\x01\x00\x00\x01=\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x00L\xb8\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x00Is\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xe8\x00\x00\x00\x00\x00\x01\x00\x00?\xec\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x8a\x00\x00\x00\x00\x00\x01\x00\x00\xe3\x07\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x00\xd1\xbf\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x01-\xf9\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x00\xc8h\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x01#G\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x01\x0f\xf8\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01r\x00\x00\x00\x00\x00\x01\x00\x00\xcc\xdc\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x01\x12\x12\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x00\xf8$\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xee\x00\x00\x00\x00\x00\x01\x00\x01\x0e\x8b\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x01\x1a\xd1\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x00\xe0\xd6\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xe8\x00\x00\x00\x00\x00\x01\x00\x01*\x19\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x00\xd45\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00\xe8C\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xe0\x00\x00\x00\x00\x00\x01\x00\x00\xc5d\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xb8\x00\x00\x00\x00\x00\x01\x00\x01'\xff\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x00\xde\xb2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05Z\x00\x00\x00\x00\x00\x01\x00\x01\x14$\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x00\xda\xd1\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x8e\x00\x00\x00\x00\x00\x01\x00\x01%\x9e\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07\x0c\x00\x00\x00\x00\x00\x01\x00\x01,\x0b\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x00\xfc\xce\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x00\xf4\x8b\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x00\xf2v\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x12\x00\x00\x00\x00\x00\x01\x00\x01 \xdf\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04~\x00\x00\x00\x00\x00\x01\x00\x01\x03\x82\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xdc\x00\x00\x00\x00\x00\x01\x00\x01\x1d\x14\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x01\x01k\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x00\xca\xe9\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x00\xef\xf0\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xe0\x00\x00\x00\x00\x00\x01\x00\x00\xed.\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xa8\x00\x00\x00\x00\x00\x01\x00\x00\xc0\xe5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x01\x0c\x0e\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x01\x09-\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xe8\x00\x00\x00\x00\x00\x01\x00\x00\xff\x90\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x00\x87\xf2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x00\xbc\x17\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x00\xb9\xb6\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x00\xb3\xb9\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x00\xa3\x01\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x00\xb6~\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x00\x8a\x1c\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x00\x92g\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x00\x8f\x8b\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x00\xa8\xa2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x00\x9e\x9f\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x00}\xc6\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x00\x9c9\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x00\xb0\xef\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x00\xaeR\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x8a\x00\x00\x00\x00\x00\x01\x00\x01Q\x16\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x01C.\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x01\xaa<\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x017V\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x01\x95\xff\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x01\x7f\x22\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01r\x00\x00\x00\x00\x00\x01\x00\x01<\xaf\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x01\x81v\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x01g\xd1\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xee\x00\x00\x00\x00\x00\x01\x00\x01}|\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x01\x8bm\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x01N\x9a\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xe8\x00\x00\x00\x00\x00\x01\x00\x01\xa0\xb0\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x01EF\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x01U\xe6\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xe0\x00\x00\x00\x00\x00\x01\x00\x014J\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xb8\x00\x00\x00\x00\x00\x01\x00\x01\x9e\x5c\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x01LO\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05Z\x00\x00\x00\x00\x00\x01\x00\x01\x83\xfa\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x01H\x92\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x8e\x00\x00\x00\x00\x00\x01\x00\x01\x9b\xd7\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07\x0c\x00\x00\x00\x00\x00\x01\x00\x01\xa2\xed\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x01k\x1f\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x01c\x05\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x01`\xfc\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x12\x00\x00\x00\x00\x00\x01\x00\x01\x93p\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07*\x00\x00\x00\x00\x00\x01\x00\x01\xa4\xd7\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04~\x00\x00\x00\x00\x00\x01\x00\x01s+\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05x\x00\x00\x00\x00\x00\x01\x00\x01\x88\xf0\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xdc\x00\x00\x00\x00\x00\x01\x00\x01\x8eM\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x01p\x8f\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06`\x00\x00\x00\x00\x00\x01\x00\x01\x98\x80\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x01:\x00\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x01^B\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xe0\x00\x00\x00\x00\x00\x01\x00\x01[D\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xa8\x00\x00\x00\x00\x00\x01\x00\x01/O\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x01z\xca\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x01w\x85\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xe8\x00\x00\x00\x00\x00\x01\x00\x01m\xfe\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x8a\x00\x00\x00\x00\x00\x01\x00\x01\xcd\xfa\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x01\xbc\xb2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07X\x00\x00\x00\x00\x00\x01\x00\x02\x18\xec\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\x1a\x00\x00\x00\x00\x00\x01\x00\x01\xb3[\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x064\x00\x00\x00\x00\x00\x01\x00\x02\x0e:\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x01\xfa\xeb\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01r\x00\x00\x00\x00\x00\x01\x00\x01\xb7\xcf\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x052\x00\x00\x00\x00\x00\x01\x00\x01\xfd\x05\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x8e\x00\x00\x00\x00\x00\x01\x00\x01\xe3\x17\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xee\x00\x00\x00\x00\x00\x01\x00\x01\xf9~\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xb8\x00\x00\x00\x00\x00\x01\x00\x02\x05\xc4\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x01\xcb\xc9\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xe8\x00\x00\x00\x00\x00\x01\x00\x02\x15\x0c\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01\xe8\x00\x04\x00\x00\x00\x01\x00\x01\xbf(\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x01\xd36\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xe0\x00\x00\x00\x00\x00\x01\x00\x01\xb0W\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\xb8\x00\x00\x00\x00\x00\x01\x00\x02\x12\xf2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x026\x00\x00\x00\x00\x00\x01\x00\x01\xc9\xa5\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05Z\x00\x00\x00\x00\x00\x01\x00\x01\xff\x17\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\x16\x00\x00\x00\x00\x00\x01\x00\x01\xc5\xc4\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x8e\x00\x00\x00\x00\x00\x01\x00\x02\x10\x91\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x07\x0c\x00\x00\x00\x00\x00\x01\x00\x02\x16\xfe\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xbc\x00\x00\x00\x00\x00\x01\x00\x01\xe7\xc1\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03`\x00\x00\x00\x00\x00\x01\x00\x01\xdf~\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03.\x00\x00\x00\x00\x00\x01\x00\x01\xddi\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x06\x12\x00\x00\x00\x00\x00\x01\x00\x02\x0b\xd2\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04~\x00\x00\x00\x00\x00\x01\x00\x01\xeeu\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x05\xdc\x00\x00\x00\x00\x00\x01\x00\x02\x08\x07\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x01\xec^\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x01\xb5\xdc\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\x06\x00\x00\x00\x00\x00\x01\x00\x01\xda\xe3\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x02\xe0\x00\x00\x00\x00\x00\x01\x00\x01\xd8!\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x00\xa8\x00\x00\x00\x00\x00\x01\x00\x01\xab\xd8\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xcc\x00\x00\x00\x00\x00\x01\x00\x01\xf7\x01\
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x04\xa4\x00\x00\x00\x00\x00\x01\x00\x01\xf4 \
\x00\x00\x01\x897z\xa9\x88\
\x00\x00\x03\xe8\x00\x00\x00\x00\x00\x01\x00\x01\xea\x83\
\x00\x00\x01\x897z\xa9\x88\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
